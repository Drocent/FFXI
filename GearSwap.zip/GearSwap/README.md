PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

You will be either ignored or blacklisted if you message multiple times.

Feel free to send me a way to contact you outside of game,and I'm happy to help, my preferred way of being contacted is Discord, my Stream discord is here: https://discord.gg/ug6xtvQ

Setting up my Gearswaps and Github updating.

0.) DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME.

1.) Create a Github account if you don't already have one: https://github.com/join

2.) Download Github Desktop if you don't already have it : https://desktop.github.com/

3.) If you don't have Gearswap installed, do so from Windower addons.

4.) Take your existing Gearswap folder from inside Windower\Addons and move it to your desktop.
    ~~https://www.dropbox.com/s/ib1vvdv5x8g1jql/Move.png?dl=0~~

5.) If you're transitioning to my gearswaps from other gearswaps remove the Gearswap\Data folder
    from the old folder, and place it somewhere you can find to help you edit my gearswaps later,
   ~~https://www.dropbox.com/s/wquioii9r16oho2/MoveData.png?dl=0~~
    if you're setting up gearswap for the first time you can delete the old Gearswap\Data folder
    
6.) Open Github Desktop and login. (As Admin if your Gearswap Folder is located in Program Files)
    ~~https://www.dropbox.com/s/ietq7dpe0obqcor/Github%20As%20Admin.png?dl=0~~

7.) Click File, Clone Repository, click the URL tab, in the Repository box put: Headtatt/GearSwap
    in the Local Path box put the location your Gearswap directory was, for example
    C:\Program Files\Windower\Addons\Gearswap           then click Clone.
    
    
8.) Move your old Gearswap folder on the desktop to the same directory as the new one to merge them.
   ~~https://www.dropbox.com/s/vd5tqw7mw6t9xa6/Merge%201.png?dl=0~~
    ~~https://www.dropbox.com/s/i602azszzv2fl25/Merge%202.png?dl=0~~ Yes here.
    ~~https://www.dropbox.com/s/gtt59xw556l04kd/Merge%203.png?dl=0~~ Yes for all.
    ~~https://www.dropbox.com/s/n1myd584muntey3/Merge%204.png?dl=0~~ Skip these files.
    Make sure not to overwrite any files, choose skip or "do not replace" for any common files.

9.) Inside your Gearswap\Data\   folder, first copy, then rename the "Selindrile" folder once
    for each of your characters' names. ~~https://www.dropbox.com/s/wquioii9r16oho2/MoveData.png?dl=0~~
    Rename all the files inside that folder as well, you can use Rename.bat (If it doesn't work
    you will have to rename these files manually.
    ~~https://www.dropbox.com/s/lpz3t8va77mvh17/Charactername.png?dl=0~~
    
10.) For full functionality my gearswap and init files do depend on a few other addons that can
    be found in your launcher, I'll list them here: Addons: Shortcuts, Cancel, Itemizer. Plugins: Timers, Run    

11.) To update my gearswaps in the future open up Github Desktop and click the third button (Fetch Origin, then
    push the same button again. ~~https://www.dropbox.com/s/zroxiy1e6r3y3cb/Fetch.png?dl=0~~
	
12.) Optional: If you're new to editing files like this I highly reccomend Notepad++, https://notepad-plus-plus.org/
    and using File: Open Folder as Workspace, and adding your Gearswap\Data folder there.
  
13.) Optional: Obtain Init file (Goes in Windower\Script folder) from:
    ~~https://www.dropbox.com/sh/20vy32liub3glxz/AAAiIVHAasFdwCK1SZdZz7d_a?dl=0~~
    https://github.com/Headtatt/Gearswap/blob/main/init.txt
	and place it in your Windower\Scripts folder (Rename and keep your
	original just in case)
    
14.) Read the Cheat Sheet in your Data Folder, feel free to contact me if there's anything you don't understand but again:

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME

PLEASE DO NOT MESSAGE ME ABOUT ANYTHING THIRD PARTY IN GAME
