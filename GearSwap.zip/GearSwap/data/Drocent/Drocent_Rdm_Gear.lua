function user_job_setup()
	-- Options: Override default values
    state.OffenseMode:options('Normal','Acc','FullAcc')
    state.HybridMode:options('Normal','DT')
	state.WeaponskillMode:options('Match','Proc')
	state.AutoBuffMode:options('Off','Auto','AutoMelee')
	state.CastingMode:options('Normal','Resistant', 'Fodder', 'Proc')
    state.IdleMode:options('Normal','PDT','MDT','DTHippo')
    state.PhysicalDefenseMode:options('PDT','NukeLock')
	state.MagicalDefenseMode:options('MDT')
	state.ResistDefenseMode:options('MEVA')
	--state.Weapons:options('None','Naegling','DualWeapons','DualWeaponsAcc','DualEvisceration','DualClubs','DualAeolian','DualProcDaggers','EnspellOnly','EnspellDW')
	--state.Weapons:options('None','Naegling','DualNaegling','Vitiation','DualVitiation','Dagger','DualDagger')
	state.Weapons:options('None', 'Vitiation', 'DualVitiation')
	
	gear.stp_jse_back = {name="Sucellos's Cape", augments={'DEX+20','Accuracy+20 Attack+20','Accuracy+10','"Store TP"+10',}}
	gear.nuke_jse_back = {name="Sucellos's Cape",augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','INT+10','"Mag.Atk.Bns."+10','Phys. dmg. taken-10%',}}
	gear.wsd_jse_back = {name="Sucellos's Cape",augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}}
	gear.mabws_jse_back = {name="Sucellos's Cape", augments={'MND+20','Mag. Acc+20 /Mag. Dmg.+20','Weapon skill damage +10%',}}
	gear.dw_jse_back = { name="Sucellos's Cape", augments={'DEX+20','Accuracy+20 Attack+20','"Dual Wield"+10','Phys. dmg. taken-10%',}},

		-- Additional local binds
	send_command('bind ^` gs c cycle ElementalMode')
	send_command('bind @` gs c cycle MagicBurstMode')
	send_command('bind ^@!` input /ja "Accession" <me>')
	send_command('bind ^backspace input /ja "Saboteur" <me>')
	send_command('bind !backspace input /ja "Spontaneity" <t>')
	send_command('bind @backspace input /ja "Composure" <me>')
	send_command('bind @f8 gs c toggle AutoNukeMode')
	send_command('bind != input /ja "Penury" <me>')
	send_command('bind @= input /ja "Parsimony" <me>')
	send_command('bind ^delete input /ja "Dark Arts" <me>')
	send_command('bind !delete input /ja "Addendum: Black" <me>')
	send_command('bind @delete input /ja "Manifestation" <me>')
	send_command('bind ^\\\\ input /ma "Protect V" <t>')
	send_command('bind @\\\\ input /ma "Shell V" <t>')
	send_command('bind !\\\\ input /ma "Reraise" <me>')
	send_command('bind @f10 gs c cycle RecoverMode')
	send_command('bind ^r gs c set skipprocweapons true;gs c reset weaponskillmode;gs c weapons Default;gs c set unlockweapons false')
	send_command('bind ^q gs c set weapons enspellonly;gs c set unlockweapons true')
	--send_command('bind !r gs c set skipprocweapons true;gs c reset weaponskillmode;gs c set weapons none')
	send_command('bind !q gs c set skipprocweapons false;gs c set weapons DualProcDaggers;gs c set weaponskillmode proc')
	
	select_default_macro_book()
end

function init_gear_sets()
	--------------------------------------
	-- Start defining the sets
	--------------------------------------
	
	-- Precast Sets
	
	-- Precast sets to enhance JAs
	sets.precast.JA['Chainspell'] = {body="Viti. Tabard +3"}
	

	-- Waltz set (chr and vit)
	sets.precast.Waltz = {}
		
	-- Don't need any special gear for Healing Waltz.
	sets.precast.Waltz['Healing Waltz'] = {}

	-- Fast cast sets for spells
	
	sets.precast.FC = { --38 From Attributes (95 Total)
		main="Vitiation Sword", --15
		sub="Ammurapi Shield",
		head="Merlinic Hood",  --8
		neck="Dls. Torque +1",
		body="Merlinic Jubbah", --6
		hands="Gendewitha Gages",
		ear1="Malignance Earring", --4
		ring1="Weatherspoon Ring", --5
		ring2="Kishar Ring", --4
		back="Ghostfyre Cape",
		waist="Embla Sash",
		legs="Ayanmo Cosciales +2", --6
		feet="Merlinic Crackows" --13
	}
		
	sets.precast.FC.Impact = set_combine(sets.precast.FC, {head=empty,body="Twilight Cloak"})
	sets.precast.FC.Dispelga = set_combine(sets.precast.FC, {main="Daybreak",sub="Ammurapi Shield"})
       
	-- Weaponskill sets
	-- Default set for any weaponskill that isn't any more specifically defined
	sets.precast.WS = {range=empty,ammo="Pemphredo Tathlum",
		head="Lethargy Chappel +2",neck="Republican Platinum Medal",ear1="Sherida Earring",ear2="Moonshade Earring",
		body="Lethargy Sayon +3",hands="Jhakri Cuffs +2",ring1="Petrov Ring",ring2="Weatherspoon Ring",
		back=gear.mabws_jse_back,waist="Sailfi Belt +1",legs="Lethargy Fuseau +2",feet="Lethargy Houseaux +3"}
		
	sets.precast.WS.Proc = 	{}
	
	-- Specific weaponskill sets.  Uses the base set if an appropriate WSMod version isn't found.
	--sets.precast.WS['Requiescat'] = {}
	
	--sets.precast.WS['Chant Du Cygne'] = {}
		
	--sets.precast.WS['Evisceration'] = sets.precast.WS['Chant Du Cygne']

	sets.precast.WS['Savage Blade'] = {range=empty,ammo="Pemphredo Tathlum",
		head="Lethargy Chappel +2",neck="Republican Platinum Medal",ear1="Sherida Earring",ear2="Moonshade Earring",
		body="Lethargy Sayon +3",hands="Jhakri Cuffs +2",ring1="Petrov Ring",ring2="Weatherspoon Ring",
		back=gear.mabws_jse_back,waist="Sailfi Belt +1",legs="Lethargy Fuseau +2",feet="Lethargy Houseaux +3"}
		
	sets.precast.WS['Sanguine Blade'] = {range=empty,ammo="Pemphredo Tathlum",
		head="Lethargy Chappel +2",neck="Sibyl Scarf",ear1="Malignance Earring",ear2="Moonshade Earring",
		body="Lethargy Sayon +3",hands="Jhakri Cuffs +2",ring1="Petrov Ring",ring2="Weatherspoon Ring",
		back=gear.mabws_jse_back,waist="Sailfi Belt +1",legs="Lethargy Fuseau +2",feet="Lethargy Houseaux +3"}
		
	sets.precast.WS['Seraph Blade'] = {range=empty,ammo="Pemphredo Tathlum",
		head="Lethargy Chappel +2",neck="Sibyl Scarf",ear1="Malignance Earring",ear2="Moonshade Earring",
		body="Lethargy Sayon +3",hands="Jhakri Cuffs +2",ring1="Petrov Ring",ring2="Weatherspoon Ring",
		back=gear.mabws_jse_back,waist="Sailfi Belt +1",legs="Lethargy Fuseau +2",feet="Lethargy Houseaux +3"}
		
	sets.precast.WS['Aeolian Edge'] = { range=empty,ammo="Pemphredo Tathlum",
		head="Lethargy Chappel +2",neck="Sibyl Scarf",ear1="Malignance Earring",ear2="Moonshade Earring",
		body="Lethargy Sayon +3",hands="Jhakri Cuffs +2",ring1="Petrov Ring",ring2="Weatherspoon Ring",
		back=gear.mabws_jse_back,waist="Sailfi Belt +1",legs="Lethargy Fuseau +2",feet="Lethargy Houseaux +3"}

	-- Midcast Sets

	sets.TreasureHunter = set_combine(sets.TreasureHunter, {feet=gear.chironic_treasure_feet})
	
	-- Gear that converts elemental damage done to recover MP.	
	sets.RecoverMP = {}
	
	-- Gear for Magic Burst mode.
    sets.MagicBurst = {}
	
	sets.midcast.FastRecast = {
		main="Vitiation Sword", --15
		sub="Ammurapi Shield",
		head="Merlinic Hood",  --8
		neck="Dls. Torque +1",
		body="Merlinic Jubbah", --6
		hands="Gendewitha Gages",
		ear1="Malignance Earring", --4
		ring1="Weatherspoon Ring", --5
		ring2="Kishar Ring", --4
		back="Ghostfyre Cape",
		waist="Embla Sash",
		legs="Ayanmo Cosciales +2", --6
		feet="Merlinic Crackows" --13
	}

    sets.midcast.Cure = {
		main="Daybreak",
		sub="Thuellaic Ecu +1",
		ammo="Staunch Tathlum",
		head="Vanya Hood",
		body="Annointed Kalasiris",
		hands="Telchine Gloves",
		legs="Vanya Slops",
		feet="Vanya Clogs",
		neck="Loricate Torque +1",
		waist="Austerity Belt",
		left_ear="Calamitous Earring",
		right_ear="Mendi. Earring",
		left_ring="Ephedra Ring",
		right_ring="Ephedra Ring",
		back="Ghostfyre Cape",
		
	}
		
    sets.midcast.LightWeatherCure = sets.midcast.Cure
		
		--Cureset for if it's not light weather but is light day.
    sets.midcast.LightDayCure = sets.midcast.Cure
		
	sets.midcast.Cursna = {
        neck="Malison Medallion",
        ring1="Ephedra Ring",
		ring2="Ephedra Ring",
        back="Oretan. Cape +1",
		feet="Vanya Clogs"}

	sets.midcast.StatusRemoval = set_combine(sets.midcast.FastRecast, {main=gear.grioavolr_fc_staff,sub="Clemency Grip"})
		
	sets.midcast.Curaga = sets.midcast.Cure
	sets.Self_Healing = {}
	sets.Cure_Received = {}
	sets.Self_Refresh = {}

	sets.midcast['Enhancing Magic'] = {
		main="Vitiation Sword",
		sub="Ammurapi Shield",
		head="Lethargy Chappel +1",
		neck="Dls. Torque +1",
		body="Lethargy Sayon +1",
		hands="Lethargy Gantherots +1",
		ear2="Lethargy Earring +1",
		ring1="Stikini Ring",
		ring2="Stikini Ring",
		back="Ghostfyre Cape",
		waist="Embla Sash",
		legs="Lethargy Fuseau +1",
		feet="Lethargy Houseaux +1"
		}

	--Atrophy Gloves are better than Lethargy for me despite the set bonus for duration on others.		
	sets.buff.ComposureOther = {
		main="Vitiation Sword",
		sub="Ammurapi Shield",
		head="Lethargy Chappel +1",
		neck="Dls. Torque +1",
		body="Lethargy Sayon +1",
		hands="Lethargy Gantherots +1",
		ear2="Lethargy Earring +1",
		ring1="Stikini Ring",
		ring2="Stikini Ring",
		back="Ghostfyre Cape",
		waist="Embla Sash",
		legs="Lethargy Fuseau +1",
		feet="Lethargy Houseaux +1"
	}
		
	--Red Mage enhancing sets are handled in a different way from most, layered on due to the way Composure works
	--Don't set combine a full set with these spells, they should layer on Enhancing Set > Composure (If Applicable) > Spell
	sets.EnhancingSkill = {}
	sets.midcast.Refresh = {}
	sets.midcast.Aquaveil = {}
	sets.midcast.BarElement = {}
	sets.midcast.Temper = sets.EnhancingSkill
	sets.midcast.Temper.DW = set_combine(sets.midcast.Temper, {})
	sets.midcast.Enspell = sets.midcast.Temper
	sets.midcast.Enspell.DW = set_combine(sets.midcast.Enspell, {})
	sets.midcast.BoostStat = {}
	sets.midcast.Stoneskin = {}
	sets.midcast.Protect = {ring2="Sheltered Ring"}
	sets.midcast.Shell = {ring2="Sheltered Ring"}
	
	sets.midcast['Enfeebling Magic'] = {
		ammo="Regal Gem",
		main="Vitiation Sword",
		sub="Ammurapi Shield",
		head="Ea Hat",
		neck="Duelist's Torque +1",
		body="Lethargy Sayon +1",
		hands="Ea Cuffs",
		waist="Null Belt",
		legs="Chironic Hose",
		feet="Ayanmo Gambieras +2",
		left_ear="Snotra Earring",
		right_ear="Lethargy Earring +1",
		left_ring="Sangoma Ring",
		right_ring="Ayanmo Ring",
		back="Sucellos's Cape",
	}
		
	sets.midcast['Enfeebling Magic'].Resistant = sets.midcast['Enfeebling Magic']
		
	sets.midcast.DurationOnlyEnfeebling = set_combine(sets.midcast['Enfeebling Magic'], {})
		
	sets.midcast.Silence = sets.midcast.DurationOnlyEnfeebling
	sets.midcast.Silence.Resistant = sets.midcast['Enfeebling Magic'].Resistant
	sets.midcast.Sleep = set_combine(sets.midcast.DurationOnlyEnfeebling,{waist="Acuity Belt +1"})
	sets.midcast.Sleep.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant,{waist="Acuity Belt +1"})
	sets.midcast.Bind = set_combine(sets.midcast.DurationOnlyEnfeebling,{})
	sets.midcast.Bind.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant,{waist="Acuity Belt +1"})
	sets.midcast.Break = set_combine(sets.midcast.DurationOnlyEnfeebling,{waist="Acuity Belt +1"})
	sets.midcast.Break.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant,{waist="Acuity Belt +1"})
	
	sets.midcast.Dispel = sets.midcast['Enfeebling Magic'].Resistant
	
	sets.midcast.SkillBasedEnfeebling = set_combine(sets.midcast['Enfeebling Magic'], {})
	
	sets.midcast['Frazzle II'] = sets.midcast['Enfeebling Magic'].Resistant
	sets.midcast['Frazzle III'] = sets.midcast.SkillBasedEnfeebling
	sets.midcast['Frazzle III'].Resistant = sets.midcast['Enfeebling Magic'].Resistant
	
	sets.midcast['Distract III'] = sets.midcast.SkillBasedEnfeebling
	sets.midcast['Distract III'].Resistant = sets.midcast['Enfeebling Magic'].Resistant
	
	sets.midcast['Divine Magic'] = set_combine(sets.midcast['Enfeebling Magic'].Resistant, {})

	sets.midcast.Dia = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast.Diaga = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
		
	sets.midcast.Bio = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)

    sets.midcast['Elemental Magic'] = {
		main="Eminent Wand",
		sub="Culminus",
		ammo="Ghastly Tathlum",
		head="Ea Hat",
		body="Ea Houppelande",
		hands="Ea Cuffs",
		legs="Ea Slops",
		feet="Ea Pigaches",
		neck="Deviant Necklace",
		waist="Austerity Belt",
		left_ear="Hearty Earring",
		right_ear="Leth. Earring +1",
		left_ring="Locus Ring",
		right_ring="Mujin Band",
		back="Ghostfyre Cape",
	}
		
    sets.midcast['Elemental Magic'].Resistant = {}
		
    sets.midcast['Elemental Magic'].Fodder = {}

    sets.midcast['Elemental Magic'].Proc = {}
		
	sets.midcast['Elemental Magic'].HighTierNuke = set_combine(sets.midcast['Elemental Magic'], {})
	sets.midcast['Elemental Magic'].HighTierNuke.Resistant = set_combine(sets.midcast['Elemental Magic'].Resistant, {})
	sets.midcast['Elemental Magic'].HighTierNuke.Fodder = set_combine(sets.midcast['Elemental Magic'].Fodder, {})
		
	sets.midcast.Impact = {
		ammo="Regal Gem",
		main="Bunzi's Rod",
		sub="Ammurapi Shield",
		head=empty,
		neck="Duelist's Torque +1",
		body="Twilight Cloak",
		hands="Lethargy Gantherots +2",
		waist="Luminary Sash",
		legs="Chironic Hose",
		feet="Lethargy Houseaux +3",
		ledt_ear="Malignance Earring",
		right_ear="Lethargy Earring +1",
		left_ring="Weatherspoon Ring",
		right_ring="Kishar Ring",
		back=gear.mabws_jse_back,
	}

	sets.midcast['Dark Magic'] = {
		ammo="Regal Gem",
		main="Bunzi's Rod",
		sub="Ammurapi Shield",
		head="Lethargy Chappel +2",
		neck="Duelist's Torque +1",
		body="Lethargy Sayon +3",
		hands="Lethargy Gantherots +2",
		waist="Luminary Sash",
		legs="Chironic Hose",
		feet="Lethargy Houseaux +3",
		ledt_ear="Malignance Earring",
		right_ear="Lethargy Earring +1",
		left_ring="Weatherspoon Ring",
		right_ring="Kishar Ring",
		back=gear.mabws_jse_back,
	}

    sets.midcast.Drain = {
		ammo="Regal Gem",
		main="Bunzi's Rod",
		sub="Ammurapi Shield",
		head="Lethargy Chappel +2",
		neck="Duelist's Torque +1",
		body="Lethargy Sayon +3",
		hands="Lethargy Gantherots +2",
		waist="Luminary Sash",
		legs="Chironic Hose",
		feet="Lethargy Houseaux +3",
		ledt_ear="Malignance Earring",
		right_ear="Lethargy Earring +1",
		left_ring="Weatherspoon Ring",
		right_ring="Kishar Ring",
		back=gear.mabws_jse_back,
	}

	sets.midcast.Aspir = sets.midcast.Drain
		
	sets.midcast.Stun = {
		ammo="Regal Gem",
		main="Bunzi's Rod",
		sub="Ammurapi Shield",
		head="Lethargy Chappel +2",
		neck="Duelist's Torque +1",
		body="Lethargy Sayon +3",
		hands="Lethargy Gantherots +2",
		waist="Luminary Sash",
		legs="Chironic Hose",
		feet="Lethargy Houseaux +3",
		ledt_ear="Malignance Earring",
		right_ear="Lethargy Earring +1",
		left_ring="Weatherspoon Ring",
		right_ring="Kishar Ring",
		back=gear.mabws_jse_back,
	}
		
	sets.midcast.Stun.Resistant = {}

	-- Sets for special buff conditions on spells.
		
	sets.buff.Saboteur = {hands="Leth. Gantherots +2"}
	
	sets.HPDown = {}
		
    sets.HPCure = {}
	
	sets.buff.Doom = set_combine(sets.buff.Doom, {})

	-- Sets to return to when not performing an action.
	
	-- Resting sets
	sets.resting = {}
	

	-- Idle sets
	sets.idle = {
		main="Mafic Cudgel",
		sub="Ammurapi Shield",
		ammo="Staunch Tathlum",
		head="Chironic Hat",
		body="Shamash Robe",
		hands="Chironic Gloves",
		legs="Ayanmo Cosciales +2",
		feet="Chironic Slippers",
		neck="Loricate Torque +1",
		waist="Carrier's Sash",
		left_ear="Hearty Earring",
		right_ear="Lethargy Earring +1",
		left_ring="Defending Ring",
		right_ring="Ayanmo Ring",
		back="Null Shawl",
	}
		
	
	sets.idle.Damage = set_combine(sets.idle, {main="Mafic Cudgel"})
	
	sets.idle.PDT = {}
		
	sets.idle.MDT = {}
		
	sets.idle.Weak = {}
	
	sets.idle.DTHippo = set_combine(sets.idle.PDT, {})
	
	-- Defense sets
	sets.defense.PDT = {}

	sets.defense.NukeLock = sets.midcast['Elemental Magic']
		
	sets.defense.MDT = {}
		
    sets.defense.MEVA = {}
		
	sets.Kiting = {ring2="Shneddick Ring"}
	sets.latent_refresh = {waist="Fucho-no-obi"}
	sets.latent_refresh_grip = {sub="Oneiros Grip"}
	sets.TPEat = {neck="Chrys. Torque"}
	sets.DayIdle = {}
	sets.NightIdle = {}
	
	-- Weapons sets
	sets.weapons.Naegling = {main="Naegling",sub="Genmei Shield"}
	sets.weapons.DualNaegling = {main="Naegling",sub="Daybreak"}
	sets.weapons.Vitiation = {main="Vitiation Sword",sub="Ammurapi Shield"}
	sets.weapons.DualVitiation = {main="Vitiation Sword",sub="Daybreak"}
	sets.weapons.Dagger = {main="Kaja Knife",sub="Genmei Shield"}
	sets.weapons.DualDagger = {main="Kaja Knife",sub="Maxentius"}
	sets.weapons.Temp = {main="Vitiation Sword",sub="Xiutleato"}
	
	
	sets.weapons.DualWeaponsAcc = {main="Naegling",sub="Almace",range=empty}
	sets.weapons.DualEvisceration = {main="Tauret",sub="Almace",range=empty}
	sets.weapons.DualAeolian = {main="Tauret",sub="Bunzi's Rod",range=empty}
	sets.weapons.DualProcDaggers = {main="Blurred Knife +1",sub="Atoyac",range=empty}
	sets.weapons.EnspellOnly = {main="Norgish Dagger",sub="Aern Dagger",range="Kaja Bow",ammo="Beetle Arrow"}
	sets.weapons.EnspellDW = {main="Blurred Knife +1",sub="Atoyac",range="Kaja Bow",ammo="Beetle Arrow"}
	sets.weapons.DualClubs = {main="Maxentius",sub="Thibron",range=empty}
	sets.weapons.DualAlmace = {main="Almace",sub="Sequence",range=empty}
	sets.weapons.DualBow = {main="Naegling",sub="Tauret",range="Kaja Bow"}
	sets.weapons.BowMacc = {main="Naegling",sub="Tauret",range="Kaja Bow",ammo=empty}
	sets.weapons.OneHand = {main="Eminent Scimitar",sub="Sors Shield"}
	sets.weapons.TwoHand = {main="Eminent Scimitar",sub="Xiutleato"}
	
	
    sets.buff.Sublimation = {waist="Embla Sash"}
    sets.buff.DTSublimation = {waist="Embla Sash"}

	-- Engaged sets

	-- Variations for TP weapon and (optional) offense/defense modes.  Code will fall back on previous
	-- sets if more refined versions aren't defined.
	-- If you create a set with both offense and defense modes, the offense mode should be first.
	-- EG: sets.Dagger.Accuracy.Evasion
	
	-- Normal melee group
--	sets.engaged = {ammo="Aurgelmir Orb +1",
--		head="Aya. Zucchetto +2",neck="Asperity Necklace",ear1="Cessance Earring",ear2="Brutal Earring",
--		body="Ayanmo Corazza +2",hands="Aya. Manopolas +2",ring1="Petrov Ring",ring2="Ilabrat Ring",
--		back=gear.stp_jse_back,waist="Windbuffet Belt +1",legs="Carmine Cuisses +1",feet="Carmine Greaves +1"}

	sets.engaged = {
		ammo="Ginsen",
		head="Aya. Zucchetto +2",
		body="Ayanmo Corazza +2",
		hands="Aya. Manopolas +2",
		legs="Aya. Cosciales +2",
		feet="Aya. Gambieras +2",
		neck="Null Loop",
		waist="Cetl Belt",
		left_ear="Hearty Earring",
		right_ear={ name="Leth. Earring +1", augments={'System: 1 ID: 1676 Val: 0','Accuracy+11','Mag. Acc.+11','"Dbl.Atk."+3',}},
		left_ring="Defending Ring",
		right_ring="Ayanmo Ring",
		back="Null Shawl",
	}
		
	sets.engaged.EnspellOnly = {
		head="Malignance Chapeau",neck="Dls. Torque +2",ear1="Suppanomimi",ear2="Digni. Earring",
		body="Ayanmo Corazza +2",hands="Aya. Manopolas +2",ring1="Metamor. Ring +1",ring2="Ramuh Ring +1",
		back="Ghostfyre Cape",waist="Windbuffet Belt +1",legs="Carmine Cuisses +1",feet="Malignance Boots"}

	sets.engaged.Acc = {
		head="Malignance Chapeau",neck="Asperity Necklace",ear1="Cessance Earring",ear2="Sherida Earring",
		body="Ayanmo Corazza +2",hands="Malignance Gloves",ring1="Petrov Ring",ring2="Ilabrat Ring",
		back=gear.stp_jse_back,waist="Windbuffet Belt +1",legs="Malignance Tights",feet="Carmine Greaves +1"}	
		
	sets.engaged.FullAcc = {ammo="Aurgelmir Orb +1",
		head="Malignance Chapeau",neck="Asperity Necklace",ear1="Cessance Earring",ear2="Sherida Earring",
		body="Ayanmo Corazza +2",hands="Malignance Gloves",ring1="Petrov Ring",ring2="Ilabrat Ring",
		back=gear.stp_jse_back,waist="Windbuffet Belt +1",legs="Malignance Tights",feet="Carmine Greaves +1"}

	sets.engaged.DT = {ammo="Aurgelmir Orb +1",
		head="Malignance Chapeau",neck="Loricate Torque +1",ear1="Cessance Earring",ear2="Sherida Earring",
		body="Malignance Tabard",hands="Nyame Gauntlets",ring1="Defending Ring",ring2="Dark Ring",
		back="Moonlight Cape",waist="Windbuffet Belt +1",legs="Malignance Tights",feet="Battlecast Gaiters"}
		
	sets.engaged.Acc.DT = {ammo="Aurgelmir Orb +1",
		head="Malignance Chapeau",neck="Loricate Torque +1",ear1="Cessance Earring",ear2="Sherida Earring",
		body="Malignance Tabard",hands="Nyame Gauntlets",ring1="Defending Ring",ring2="Dark Ring",
		back="Moonlight Cape",waist="Flume Belt +1",legs="Malignance Tights",feet="Battlecast Gaiters"}
		
	sets.engaged.FullAcc.DT = {ammo="Aurgelmir Orb +1",
		head="Malignance Chapeau",neck="Loricate Torque +1",ear1="Cessance Earring",ear2="Sherida Earring",
		body="Malignance Tabard",hands="Nyame Gauntlets",ring1="Defending Ring",ring2="Dark Ring",
		back="Moonlight Cape",waist="Flume Belt +1",legs="Malignance Tights",feet="Battlecast Gaiters"}
		
	sets.engaged.DW = {
		ammo="Ginsen",
		head="Aya. Zucchetto +2",
		body="Ayanmo Corazza +2",
		hands="Aya. Manopolas +2",
		legs="Aya. Cosciales +2",
		feet="Aya. Gambieras +2",
		neck="Null Loop",
		waist="Cetl Belt",
		left_ear="Hearty Earring",
		right_ear={ name="Leth. Earring +1", augments={'System: 1 ID: 1676 Val: 0','Accuracy+11','Mag. Acc.+11','"Dbl.Atk."+3',}},
		left_ring="Defending Ring",
		right_ring="Ayanmo Ring",
		back="Null Shawl",	
	}
		
	sets.engaged.DW.Acc = {ammo="Aurgelmir Orb +1",
		head="Malignance Chapeau",neck="Combatant's Torque",ear1="Suppanomimi",ear2="Sherida Earring",
		body="Malignance Tabard",hands="Malignance Gloves",ring1="Ramuh Ring +1",ring2="Ilabrat Ring",
		back=gear.stp_jse_back,waist="Olseni Belt",legs="Carmine Cuisses +1",feet="Malignance Boots"}
		
	sets.engaged.DW.FullAcc = {ammo="Aurgelmir Orb +1",
		head="Malignance Chapeau",neck="Combatant's Torque",ear1="Suppanomimi",ear2="Telos Earring",
		body="Malignance Tabard",hands="Malignance Gloves",ring1="Ramuh Ring +1",ring2="Ramuh Ring +1",
		back=gear.stp_jse_back,waist="Olseni Belt",legs="Carmine Cuisses +1",feet="Malignance Boots"}
		
	sets.engaged.DW.DT = {ammo="Aurgelmir Orb +1",
		head="Malignance Chapeau",neck="Loricate Torque +1",ear1="Suppanomimi",ear2="Sherida Earring",
		body="Malignance Tabard",hands="Malignance Gloves",ring1="Defending Ring",ring2="Ilabrat Ring",
		back="Moonlight Cape",waist="Reiki Yotai",legs="Malignance Tights",feet="Malignance Boots"}
		
	sets.engaged.DW.Acc.DT = {ammo="Aurgelmir Orb +1",
		head="Malignance Chapeau",neck="Loricate Torque +1",ear1="Suppanomimi",ear2="Sherida Earring",
		body="Malignance Tabard",hands="Malignance Gloves",ring1="Defending Ring",ring2="Ilabrat Ring",
		back="Moonlight Cape",waist="Reiki Yotai",legs="Malignance Tights",feet="Malignance Boots"}
		
	sets.engaged.DW.FullAcc.DT = {ammo="Aurgelmir Orb +1",
		head="Malignance Chapeau",neck="Loricate Torque +1",ear1="Suppanomimi",ear2="Telos Earring",
		body="Malignance Tabard",hands="Malignance Gloves",ring1="Defending Ring",ring2="Ramuh Ring +1",
		back="Moonlight Cape",waist="Reiki Yotai",legs="Malignance Tights",feet="Malignance Boots"}
end

-- Select default macro book on initial load or subjob change.
-- Default macro set/book
function select_default_macro_book()
	if player.sub_job == 'DNC' then
		set_macro_page(1, 2)
	elseif player.sub_job == 'NIN' then
		set_macro_page(1, 2)
	elseif player.sub_job == 'SCH' then
		set_macro_page(1, 2)
	else
		set_macro_page(1, 2)
	end
end

--Job Specific Trust Overwrite
function check_trust()
	if not moving then
		if state.AutoTrustMode.value and not data.areas.cities:contains(world.area) and (buffactive['Elvorseal'] or buffactive['Reive Mark'] or not player.in_combat) then
			local party = windower.ffxi.get_party()
			if party.p5 == nil then
				local spell_recasts = windower.ffxi.get_spell_recasts()

				if spell_recasts[980] < spell_latency and not have_trust("Yoran-Oran") then
					windower.chat.input('/ma "Yoran-Oran (UC)" <me>')
					tickdelay = os.clock() + 3
					return true
				elseif spell_recasts[984] < spell_latency and not have_trust("August") then
					windower.chat.input('/ma "August" <me>')
					tickdelay = os.clock() + 3
					return true
				elseif spell_recasts[967] < spell_latency and not have_trust("Qultada") then
					windower.chat.input('/ma "Qultada" <me>')
					tickdelay = os.clock() + 3
					return true
				elseif spell_recasts[914] < spell_latency and not have_trust("Ulmia") then
					windower.chat.input('/ma "Ulmia" <me>')
					tickdelay = os.clock() + 3
					return true
				elseif spell_recasts[979] < spell_latency and not have_trust("Selh'teus") then
					windower.chat.input('/ma "Selh\'teus" <me>')
					tickdelay = os.clock() + 3
					return true
				else
					return false
				end
			end
		end
	end
	return false
end

function user_job_buff_change(buff, gain)
	if buff:startswith('Addendum: ') or buff:endswith(' Arts') then
		style_lock = true
	end
end

function user_job_lockstyle()
	if player.sub_job == 'NIN' or player.sub_job == 'DNC' then
		if player.equipment.main == nil or player.equipment.main == 'empty' then
			windower.chat.input('/lockstyleset 2')
		elseif res.items[item_name_to_id(player.equipment.main)].skill == 3 then --Sword in main hand.
			if res.items[item_name_to_id(player.equipment.sub)].skill == 3 then --Sword/Sword.
				windower.chat.input('/lockstyleset 2')
			elseif res.items[item_name_to_id(player.equipment.sub)].skill == 2 then --Sword/Dagger.
				windower.chat.input('/lockstyleset 2')
			elseif res.items[item_name_to_id(player.equipment.sub)].skill == 11 then --Sword/Club.
				windower.chat.input('/lockstyleset 2')
			else
				windower.chat.input('/lockstyleset 2') --Catchall
			end
		elseif res.items[item_name_to_id(player.equipment.main)].skill == 2 then --Dagger in main hand.
			if res.items[item_name_to_id(player.equipment.sub)].skill == 3 then --Dagger/Sword.
				windower.chat.input('/lockstyleset 2')
			elseif res.items[item_name_to_id(player.equipment.sub)].skill == 2 then --Dagger/Dagger.
				windower.chat.input('/lockstyleset 2')
			elseif res.items[item_name_to_id(player.equipment.sub)].skill == 11 then --Dagger/Club.
				windower.chat.input('/lockstyleset 2')
			else
				windower.chat.input('/lockstyleset 2') --Catchall
			end
		elseif res.items[item_name_to_id(player.equipment.main)].skill == 11 then --Club in main hand.
			if res.items[item_name_to_id(player.equipment.sub)].skill == 3 then --Club/Sword.
				windower.chat.input('/lockstyleset 2')
			elseif res.items[item_name_to_id(player.equipment.sub)].skill == 2 then --Club/Dagger.
				windower.chat.input('/lockstyleset 2')
			elseif res.items[item_name_to_id(player.equipment.sub)].skill == 11 then --Club/Club.
				windower.chat.input('/lockstyleset 2')
			else
				windower.chat.input('/lockstyleset 2') --Catchall
			end
		end
	elseif player.sub_job == 'WHM' or state.Buff['Light Arts'] or state.Buff['Addendum: White'] then
		windower.chat.input('/lockstyleset 2')
	elseif player.sub_job == 'BLM' or state.Buff['Dark Arts'] or state.Buff['Addendum: Black'] then
		windower.chat.input('/lockstyleset 2')
	else
		windower.chat.input('/lockstyleset 2')
	end
end

autows_list = {['Naegling']='Savage Blade',['DualNaegling']='Savage Blade',['Vitiation']='Seraph Blade',['DualVitiation']='Seraph Blade',['Dagger']='Aeolian Edge',['DualDagger']='Aeolian Edge',['EnspellDW']='Sanguine Blade'}