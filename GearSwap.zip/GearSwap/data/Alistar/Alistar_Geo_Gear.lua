function user_job_setup()

	-- Options: Override default values
    state.OffenseMode:options('Normal')
	state.CastingMode:options('Normal', 'Resistant', 'Fodder', 'Proc')
    state.IdleMode:options('Normal','PDT')
	state.PhysicalDefenseMode:options('PDT', 'NukeLock', 'GeoLock', 'PetPDT')
	state.MagicalDefenseMode:options('MDT', 'NukeLock')
	state.ResistDefenseMode:options('MEVA')
	state.Weapons:options('None','Maxentius','DualWeapons')

	gear.nuke_jse_back = {name="Nantosuelta's Cape",augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','"Mag.Atk.Bns."+10'}}
	gear.pet_jse_back = {name="Nantosuelta's Cape",augments={'HP+60','Eva.+20 /Mag. Eva.+20','Pet: "Regen"+10','Pet: "Regen"+5',}}
	gear.idle_jse_back = {name="Nantosuelta's Cape",augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Phys. dmg. taken-10%',}}
	
	gear.obi_cure_back = "Tempered Cape +1"
	gear.obi_cure_waist = "Witful Belt"

	gear.obi_low_nuke_back = gear.nuke_jse_back
	gear.obi_low_nuke_waist = "Sekhmet Corset"

	gear.obi_high_nuke_back = gear.nuke_jse_back
	gear.obi_high_nuke_waist = "Refoccilation Stone"
	
	autoindi = "Fury"
	autogeo = "Frailty"
	
	-- Additional local binds
	send_command('bind ^` gs c cycle ElementalMode')
	send_command('bind !` input /ja "Full Circle" <me>')
	send_command('bind @f8 gs c toggle AutoNukeMode')
	send_command('bind @` gs c cycle MagicBurstMode')
	send_command('bind @f10 gs c cycle RecoverMode')
	send_command('bind ^backspace input /ja "Entrust" <me>')
	send_command('bind !backspace input /ja "Life Cycle" <me>')
	send_command('bind @backspace input /ma "Sleep II" <t>')
	send_command('bind ^delete input /ma "Aspir III" <t>')
	send_command('bind @delete input /ma "Sleep" <t>')
	
	send_command('bind @1 input /ma "Geo-Haste" <t>')
	send_command('bind @2 input /ma "Geo-Fury" <t>')
	send_command('bind @3 input /ma "Geo-Barrier" <t>')
	send_command('bind @4 input /ma "Geo-Precision" <t>')
	send_command('bind @5 input /ma "Geo-Acumen" <t>')
	send_command('bind @6 input /ma "Geo-Focus" <t>')
	send_command('bind @7 input /ma "Geo-Attunement" <t>')
	
	
	indi_duration = 290
	
	select_default_macro_book()
end

function init_gear_sets()
	
	--------------------------------------
	-- Precast sets
	--------------------------------------

	-- Precast sets to enhance JAs
	sets.precast.JA.Bolster = {body="Bagua Tunic"}
	sets.precast.JA['Life Cycle'] = {body="Geo. Tunic",back=gear.idle_jse_back}
	sets.precast.JA['Radial Arcana'] = {feet="Bagua Sandals +3"}
	sets.precast.JA['Mending Halation'] = {legs="Bagua Pants +1"}
	sets.precast.JA['Full Circle'] = {head="Azimuth Hood +2"}
	
	-- Indi Duration in slots that would normally have skill here to make entrust more efficient.
	sets.buff.Entrust = {}
	
	-- Relic hat for Blaze of Glory HP increase.
	sets.buff['Blaze of Glory'] = {}
	
	-- Fast cast sets for spells

	sets.precast.FC = {
		head="Merlinic Hood",neck="Voltsurge Torque",ear1="Loquac. Earring",ear2="Malignance Earring",
		body="Agwu's Robe",hands="Agwu's Gages",ring1="Kishar Ring",ring2="Prolix Ring",
		back="Lifestream Cape",waist="Embla Sash",legs="Agwu's Slops",feet="Merlinic Crackows"}

	sets.precast.FC.Geomancy = set_combine(sets.precast.FC, {main="Idris", range="Dunna",ammo=empty, neck="Bagua Charm +1"})
	
    sets.precast.FC['Elemental Magic'] = set_combine(sets.precast.FC, {hands="Bagua Mitaines"})

	sets.precast.FC.Cure = set_combine(sets.precast.FC, {main="Daybreak"})
		
	sets.precast.FC.Curaga = sets.precast.FC.Cure
	
	sets.Self_Healing = {}
	sets.Cure_Received = {}
	sets.Self_Refresh = {}
	
    sets.precast.FC['Enhancing Magic'] = set_combine(sets.precast.FC, {})

    sets.precast.FC.Stoneskin = set_combine(sets.precast.FC['Enhancing Magic'], {})

	sets.precast.FC.Impact = set_combine(sets.precast.FC, {head=empty,body="Twilight Cloak", hands="Bagua Mitaines"})
	
	
		
	sets.precast.FC.Dispelga = set_combine(sets.precast.FC, {main="Daybreak",sub="Genmei Shield"})
	
	-- Weaponskill sets
	-- Default set for any weaponskill that isn't any more specifically defined
	sets.precast.WS = {
		head="Nyame Helm",neck="Fotia Gorget",ear1="Ishvara Earring",ear2="Moonshade Earring",
		body="Nyame Mail",hands="Nyame Gauntlets",ring1="Epaminondas's Ring",ring2="Cornelia's Ring",
		back="Null Shawl",waist="Fotia Belt",legs="Nyame Flanchard",feet="Nyame Sollerets"}


	--------------------------------------
	-- Midcast sets
	--------------------------------------

    sets.midcast.FastRecast = {}

	sets.midcast.Geomancy = {main="Idris",sub="Genmei Shield",range="Dunna",
		head="Azimuth Hood +2",neck="Bagua Charm +1",ear1="Hearty Earring",ear2="Azimuth Earring",
		body="Vedic Coat",hands="Geo. Mitaines +3",ring1="Stikini Ring",ring2="Stikini Ring",
		back="Lifestream Cape",waist="Austerity Belt",legs="Bagua Pants +1",feet="Azimuth Gaiters +2"}


	--Extra Indi duration as long as you can keep your 900 skill cap.
	sets.midcast.Geomancy.Indi = set_combine(sets.midcast.Geomancy, {})
		
    sets.midcast.Cure = {main="Daybreak",sub="Genmei Shield",range="Dunna",
        head="Vanya Hood",neck="Bagua Charm +1",ear1="Hearty Earring",ear2="Malignance Earring",
        body="Nyame Mail",hands="Telchine Gloves",ring1="Ephedra Ring",ring2="Ephedra Ring",
        back="Oretania's Cape +1",waist="Austerity Belt",legs="Nyame Flanchard",feet="Vanya Clogs"}
		
    sets.midcast.LightWeatherCure = set_combine(sets.midcast.Cure, {main="Daybreak",waist="Hachirin-no-obi", back="Twilight Cape"})
		
		--Cureset for if it's not light weather but is light day.
    sets.midcast.LightDayCure = set_combine(sets.midcast.Cure, {main="Daybreak",waist="Hachirin-no-obi", back="Twilight Cape"})

    sets.midcast.Curaga = set_combine(sets.midcast.Cure, {main="Daybreak"})

	sets.midcast.Cursna =  set_combine(sets.midcast.Cure, {neck="Malison Medallion",
		back="Oretan. Cape +1",ring1="Ephedra Ring",ring2="Ephedra Ring",feet="Vanya Clogs"})
	
	sets.midcast.StatusRemoval = set_combine(sets.midcast.FastRecast, {})
	
    sets.midcast['Elemental Magic'] = {main="Bunzi's Rod",sub="Ammurapi Shield",ammo="Ghastly Tathlum +1",
        head="Azimuth Hood +2",neck="Mizukage-no-Kubikazari",ear1="Regal Earring",ear2="Malignance Earring",
        body="Azimuth Coat +2",hands="Agwu's Gages",ring1="Freke Ring",ring2="Mujin Band",
        back="Seshaw Cape",waist="Orpheus's Sash",legs="Azimuth Tights +2",feet="Azimuth Gaiters +2"}

    sets.midcast['Elemental Magic'].Resistant = set_combine(sets.midcast['Elemental Magic'], {})
	sets.midcast['Elemental Magic'].Proc = set_combine(sets.midcast['Elemental Magic'], {})	
    sets.midcast['Elemental Magic'].Fodder = set_combine(sets.midcast['Elemental Magic'], {})	
    sets.midcast['Elemental Magic'].HighTierNuke = set_combine(sets.midcast['Elemental Magic'], {})	
    sets.midcast['Elemental Magic'].HighTierNuke.Resistant = set_combine(sets.midcast['Elemental Magic'], {})
	sets.midcast['Elemental Magic'].HighTierNuke.Fodder = set_combine(sets.midcast['Elemental Magic'], {})
		
    sets.midcast['Dark Magic'] = set_combine(sets.midcast['Elemental Magic'], {})
		
    sets.midcast.Drain = set_combine(sets.midcast['Elemental Magic'], {head="Pixie Hairpin +1", ring1="Freke Ring", ring2="Archon Ring"})
    
    sets.midcast.Aspir = sets.midcast.Drain
		
	sets.midcast['Enfeebling Magic'] = {main="Bunzi's Rod",sub="Ammurapi Shield",range="Dunna",
		head="Azimuth Hood +2",neck="Bagua Charm +1",ear1="Regal Earring",ear2="Malignance Earring",
		body="Azimuth Coat +2",hands="Azimuth Gloves +2",ring1="Kishar Ring",ring2="Stikini Ring",
		back="Null Shawl",waist="Null Belt",legs="Azimuth Tights +2",feet="Azimuth Gaiters +2"}
	
	sets.midcast['Enfeebling Magic'].Resistant = set_combine(sets.midcast['Enfeebling Magic'], {})
	
	sets.midcast.Stun = set_combine(sets.midcast['Enfeebling Magic'], {ring1="Stikini Ring"})
		
	sets.midcast.Stun.Resistant = set_combine(sets.midcast.Stun, {})
		
	sets.midcast.Impact = set_combine(sets.midcast['Enfeebling Magic'], {head=empty, body="Twilight Cloak", waist="Austerity Belt"})
		
	sets.midcast.Dispel =  set_combine(sets.midcast['Enfeebling Magic'], {main="Daybreak", sub="Ammurapi Shield ", ring1="Stikini Ring"})

	sets.midcast.Dispelga = set_combine(sets.midcast.Dispel, {main="Daybreak",sub="Ammurapi Shield"})
		
    sets.midcast.ElementalEnfeeble = set_combine(sets.midcast['Enfeebling Magic'], {})
    sets.midcast.ElementalEnfeeble.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant, {})
	
	sets.midcast.IntEnfeebles = set_combine(sets.midcast['Enfeebling Magic'], {})
	sets.midcast.IntEnfeebles.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant, {})
	
	sets.midcast.MndEnfeebles = set_combine(sets.midcast['Enfeebling Magic'], {})
	sets.midcast.MndEnfeebles.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant, {})
	
	sets.midcast.Dia = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Dia II'] = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	
	sets.midcast.Bio = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Bio II'] = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	
	sets.midcast['Divine Magic'] = set_combine(sets.midcast['Enfeebling Magic'], {})
		
	sets.midcast['Enhancing Magic'] = {main="Gada",sub="Ammurapi Shield",range="Dunna",
		head="Telchine Cap",neck="Colossus's Torque",ear1="Mimir Earring",ear2="Gifted Earring",
		body="Telchine Chas.",hands="Telchine Gloves",ring1="Stikini Ring",ring2="Stikini Ring",
		back="Perimede Cape",waist="Embla Sash",legs="Telchine Braconi",feet="Telchine Pigaches"}
		
	sets.midcast.Stoneskin = set_combine(sets.midcast['Enhancing Magic'], {})
	
	sets.midcast.Refresh = set_combine(sets.midcast['Enhancing Magic'], {})
	
	sets.midcast.Aquaveil = set_combine(sets.midcast['Enhancing Magic'], {})
	
	sets.midcast.BarElement = set_combine(sets.precast.FC['Enhancing Magic'], {})
	
	sets.midcast.Protect = set_combine(sets.midcast['Enhancing Magic'], {})
	sets.midcast.Protectra = set_combine(sets.midcast['Enhancing Magic'], {})
	sets.midcast.Shell = set_combine(sets.midcast['Enhancing Magic'], {})
	sets.midcast.Shellra = set_combine(sets.midcast['Enhancing Magic'], {})

	--------------------------------------
	-- Idle/resting/defense/etc sets
	--------------------------------------

	-- Resting sets
	sets.resting = {}

	-- Idle sets

	sets.idle = {main="Idris",sub="Genmei Shield",range="Dunna",
		head="Null Masque",neck="Loricate Torque +1",ear1="Hearty Earring",ear2="Lugalbanda Earring",
		body="Azimuth Coat +2",hands="Nyame Gauntlets",ring1="Defending Ring",ring2="Vocane Ring",
		back=gear.idle_jse_back,waist="Carrier's Sash",legs="Assid. Pants +1",feet="Azimuth Gaiters +2"}
		
	sets.idle.PDT = {main="Daybreak",sub="Genmei Shield",range="Dunna",
		head="Befouled Crown",neck="Loricate Torque +1",ear1="Hearty Earring",ear2="Lugalbanda Earring",
		body="Annointed Kalasiris",hands="Nyame Gauntlets",ring1="Defending Ring",ring2="Vocane Ring",
		back=gear.idle_jse_back,waist="Carrier's Sash",legs="Assid. Pants +1",feet="Azimuth Gaiters +2"}

	-- .Pet sets are for when Luopan is present.
	sets.idle.Pet = {main="Idris",sub="Genmei Shield",range="Dunna",
		head="Azimuth Hood +2",neck="Bagua Charm +1",ear1="Hearty Earring",ear2="Azimuth Earring",
		body="Azimuth Coat +2",hands="Geo. Mitaines +3",ring1="Defending Ring",ring2="Vocane Ring",
		back=gear.pet_jse_back,waist="Carrier's Sash",legs="Nyame Flanchard",feet="Bagua Sandals +3"}

	sets.idle.PDT.Pet = set_combine(sets.idle.Pet, {})

	-- .Indi sets are for when an Indi-spell is active.
	sets.idle.Indi = set_combine(sets.idle, {})
	sets.idle.Pet.Indi = set_combine(sets.idle.Pet, {}) 
	sets.idle.PDT.Indi = set_combine(sets.idle.PDT, {}) 
	sets.idle.PDT.Pet.Indi = set_combine(sets.idle.PDT.Pet, {})

	sets.idle.Weak = set_combine(sets.idle, {body="Annointed Kalasiris"})

	-- Defense sets
	
	sets.defense.PDT = set_combine(sets.idle, {})

	sets.defense.MDT = set_combine(sets.idle, {})
		
    sets.defense.MEVA = set_combine(sets.idle, {})
		
	sets.defense.PetPDT = sets.idle.PDT.Pet
		
	sets.defense.NukeLock = sets.midcast['Elemental Magic']
	
	sets.defense.GeoLock = sets.midcast.Geomancy.Indi

	sets.Kiting = {feet="Geomancy Sandals +3"}
	sets.latent_refresh = {waist="Fucho-no-obi"}
	sets.latent_refresh_grip = {sub="Oneiros Grip"}
	sets.TPEat = {neck="Chrys. Torque"}
	sets.DayIdle = {}
	sets.NightIdle = {}
	sets.TreasureHunter = set_combine(sets.TreasureHunter, {feet=gear.merlinic_treasure_feet})
	
	sets.HPDown = set_combine(sets.idle, {})
	
	sets.buff.Doom = set_combine(sets.buff.Doom, {})

	--------------------------------------
	-- Engaged sets
	--------------------------------------

	-- Variations for TP weapon and (optional) offense/defense modes.  Code will fall back on previous
	-- sets if more refined versions aren't defined.
	-- If you create a set with both offense and defense modes, the offense mode should be first.
	-- EG: sets.engaged.Dagger.Accuracy.Evasion

	-- Normal melee group
	sets.engaged = {range="Dunna",
		head="Nyame Helm",neck="Bagua Charm +1",ear1="Telos Earring",ear2="Crep. Earring",
		body="Nyame Mail",hands="Geomancy Mitaines +3",ring1="Chirich Ring",ring2="Chirich Ring",
		back="Null Shawl",waist="Null Belt",legs="Nyame Flanchard",feet="Nyame Sollerets"}
		
	sets.engaged.DW = set_combine(sets.engaged, {ear2="Suppanomimi"})

	--------------------------------------
	-- Custom buff sets
	--------------------------------------
	
	-- Gear that converts elemental damage done to recover MP.	
	sets.RecoverMP = {}
	
	-- Gear for Magic Burst mode.
    sets.MagicBurst = {}
	sets.ResistantMagicBurst = {}
	
	sets.buff.Sublimation = {waist="Embla Sash"}
    sets.buff.DTSublimation = {waist="Embla Sash"}
	
	-- Weapons sets
	sets.weapons.Maxentius = {main='Maxentius',sub='Genmei Shield'}
	sets.weapons.DualWeapons = {main='Maxentius',sub='Nehushtan'}
end

-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
	set_macro_page(1, 12)
end

function user_job_lockstyle()
	windower.chat.input('/lockstyleset 07')
end

