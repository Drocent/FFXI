-- Setup vars that are user-dependent.  Can override this function in a sidecar file.
function user_job_setup()
    state.OffenseMode:options('Normal','Acc')
    state.RangedMode:options('Normal', 'Acc')
    state.WeaponskillMode:options('Match','Normal', 'Acc','Proc')
    state.CastingMode:options('Normal', 'Resistant')
    --state.IdleMode:options('OnehandSword', 'DWSword', 'OnehandRange', 'DWRAngAcc', 'OnehandDaggerTP', 'Dyna')
	state.IdleMode:options('Default', 'Ranged', 'Magic', 'Melee', 'Hybrid')
	state.HybridMode:options('Normal','DT')
	state.ExtraMeleeMode = M{['description']='Extra Melee Mode', 'None', 'DWMax'}
	state.Weapons:options('None','Fomalhaut','DeathPenalty','Anarchy')
	--state.Weapons:options('Default','Ranged','Savage','Evisceration','DualWeapons','DualSavageWeapons','DualEvisceration','DualLeadenRanged','DualLeadenMelee','DualAeolian','DualLeadenMeleeAcc','DualRanged','DualProcWeapons','None')
	state.CompensatorMode:options('Always','300','1000','Never')

    --gear.RAbullet = "Decimating Bullet"
    gear.RAbullet = "Chrono Bullet"
	gear.WSbullet = "Chrono Bullet"
    gear.MAbullet = "Living Bullet" --For MAB WS, do not put single-use bullets here.
    gear.QDbullet = "Animikii Bullet"
    options.ammo_warning_limit = 15
    --Ikenga_vest_bonus = 190  -- It is 190 at R20. Uncomment if you need to manually adjust because you are using below R20

	gear.tp_ranger_jse_back = {name="Camulus's Mantle",augments={'AGI+20','Rng.Acc.+20 Rng.Atk.+20','AGI+10','Weapon skill damage +10%',}}
	gear.snapshot_jse_back = {name="Camulus's Mantle",augments={'"Snapshot"+10',}}
	gear.tp_jse_back = {name="Camulus's Mantle",augments={'DEX+20','Accuracy+20 Attack+20','"Dbl.Atk."+10','Phys. dmg. taken-10%',}}
	gear.ranger_wsd_jse_back = {name="Camulus's Mantle",augments={'AGI+20','Rng.Acc.+20 Rng.Atk.+20','AGI+10','Weapon skill damage +10%',}}
	gear.magic_wsd_jse_back = {name="Camulus's Mantle",augments={'AGI+20','Mag. Acc+20 /Mag. Dmg.+20','AGI+10','Weapon skill damage +10%',}}
	gear.str_wsd_jse_back = {name="Camulus's Mantle",augments={'STR+20','Accuracy+20 Attack+20','Weapon skill damage +10%',}}

    -- Additional local binds
	send_command('bind ^` gs c cycle ElementalMode')
	send_command('bind !` gs c elemental quickdraw')
	
	send_command('bind ^backspace input /ja "Double-up" <me>')
	send_command('bind @backspace input /ja "Snake Eye" <me>')
	send_command('bind !backspace input /ja "Fold" <me>')
	send_command('bind ^@!backspace input /ja "Crooked Cards" <me>')
	
	send_command('bind ^\\\\ input /ja "Random Deal" <me>')
    send_command('bind !\\\\ input /ja "Bolter\'s Roll" <me>')
	send_command('bind ^@!\\\\ gs c toggle LuzafRing')
	send_command('bind @f7 gs c toggle RngHelper')

	--send_command('bind !r gs c weapons DualSavageWeapons;gs c update')
	send_command('bind ^q gs c weapons DualAeolian;gs c update')
	send_command('bind !q gs c weapons DualLeadenRanged;gs c update')
	send_command('bind @pause roller roll')

    select_default_macro_book()
end

-- Define sets and vars used by this job file.
function init_gear_sets()
    --------------------------------------
    -- Start defining the sets
    --------------------------------------

    -- Precast Sets

    -- Precast sets to enhance JAs

	sets.precast.JA['Triple Shot'] = {body="Chasseur's Frac +1"}
    sets.precast.JA['Snake Eye'] = {legs="Lanun Trews"}
    sets.precast.JA['Wild Card'] = {feet="Lanun Bottes +3"}
    sets.precast.JA['Random Deal'] = {body="Lanun Frac"}
    sets.precast.FoldDoubleBust = {hands="Lanun Gants"}

    sets.precast.CorsairRoll = {
		main="Rostam",
		range="Compensator",
        head="Lanun Tricorne",
		neck="Regal Necklace",
        body="Lanun Frac +3",
		hands="Chasseur's Gants +3",
        back=gear.tp_jse_back,
		legs="Desultor Tassets",
		ring2="Luzaf's Ring",
		}

    sets.precast.LuzafRing = {ring2="Luzaf's Ring"}
    
    sets.precast.CorsairRoll["Caster's Roll"] = set_combine(sets.precast.CorsairRoll, {legs="Chas. Culottes +1"})
    sets.precast.CorsairRoll["Courser's Roll"] = set_combine(sets.precast.CorsairRoll, {feet="Chass. Bottes +2"})
    sets.precast.CorsairRoll["Blitzer's Roll"] = set_combine(sets.precast.CorsairRoll, {head="Chass. Tricorne +2"})
    sets.precast.CorsairRoll["Tactician's Roll"] = set_combine(sets.precast.CorsairRoll, {body="Chasseur's Frac +1"})
    sets.precast.CorsairRoll["Allies' Roll"] = set_combine(sets.precast.CorsairRoll, {hands="Chasseur's Gants +3"})
    
    sets.precast.CorsairShot = {
		ammo=gear.QDbullet,
        head="Nyame Helm",
		neck="Commodore Charm +1",
		ear1="Friomisi Earring",
		ear2="Hecate's Earring",
        body="Nyame Mail",
		hands="Nyame Gauntlets",
		ring1="Dingir Ring",
		ring2="Acumen Ring",
        back=gear.magic_wsd_jse_back,
		waist="Eschan Stone",
		legs="Nyame Flanchard",
		feet="Chasseur's Bottes +2"}
	
	sets.precast.CorsairShot.Damage = set_combine(sets.precast.CorsairShot, {head="Malignance Tabard",})
	
	sets.precast.CorsairShot.Proc = set_combine(sets.precast.CorsairShot, {"Malignance Tabard",})
	
    sets.precast.CorsairShot['Light Shot'] = {
		ammo=gear.QDbullet,
		head="Chasseur's Tricorne +2",
		neck="Commodore Charm +1",
		ear1="Dedition Earring",
		ear2="Telos Earring",
        body="Malignance Tabard",
		hands="Malignance Gloves",
		ring1="Dingir Ring",
		ring2="Acumen Ring",
        back=gear.magic_wsd_jse_back,
		waist="Reiki Yotai",
		legs="Malignance Tights",
		feet="Chasseur's Bottes +2"
	}

    sets.precast.CorsairShot['Dark Shot'] = set_combine(sets.precast.CorsairShot['Light Shot'], {feet="Chass. Bottes +1"})

    -- Waltz set (chr and vit)
    sets.precast.Waltz = {}
		
	sets.Self_Waltz = {}
        
    -- Don't need any special gear for Healing Waltz.
    sets.precast.Waltz['Healing Waltz'] = {}

    -- Fast cast sets for spells
    
    sets.precast.FC = {}

    sets.precast.FC.Utsusemi = set_combine(sets.precast.FC, {})
	
	sets.precast.FC.Cure = set_combine(sets.precast.FC, {})

    sets.precast.RA = {
		ammo=gear.RAbullet,
		head="Chasseur's Tricorne +2", -- 16 Rapid Shot
        neck="Commodore Charm +1", -- 3 Snapshot
		body="Oshosi Vest", -- 12 Snapshot
		hands="Carmine Finger Gauntlets", -- 7 Snapshot, 10 Rapid Shot
		legs="Adhemar Kecks", -- 9 Snapshot, 10 Rapid Shot
        back=gear.snapshot_jse_back, -- 10 Snapshot
		feet="Meg. Jam. +2", -- 10 Snapshot
		--
		}
		
	sets.precast.RA.Flurry = set_combine(sets.precast.RA, {waist="Yemaya Belt"})
	sets.precast.RA.Flurry2 = set_combine(sets.precast.RA, {waist="Yemaya Belt"})

       
    -- Weaponskill sets
    -- Default set for any weaponskill that isn't any more specifically defined
    sets.precast.WS = {ammo=gear.WSbullet,
        head="Nyame Helm",neck="Commodore Charm +1",ear1="Ishvara Earring",ear2="Moonshade Earring",
        body="Nyame Mail",hands="Nyame Gauntlets",ring1="Regal Ring",ring2="Cornelia's Ring",
        back=gear.str_wsd_jse_back,waist="Fotia Belt",legs="Nyame Flanchard",feet="Nyame Sollerets"}
		
    sets.precast.WS.ACC = set_combine(sets.precast.WS, {})
		
    sets.precast.WS.Proc = set_combine(sets.precast.WS, {})
		
    -- Specific weaponskill sets.  Uses the base set if an appropriate WSMod version isn't found.

    sets.precast.WS['Requiescat'] = set_combine(sets.precast.WS, {})

	sets.precast.WS['Evisceration'] = set_combine(sets.precast.WS, {
		neck="Fotia Gorget",
		waist="Fotia Belt",
	})

	sets.precast.WS['Savage Blade'] = set_combine(sets.precast.WS, {
		hands="Chasseur's Gants +3",
		neck="Fotia Gorget",
		waist="Sailfi Belt +1",
	})

	sets.precast.WS['Last Stand'] = set_combine(sets.precast.WS, {
		body="Ikenga's Vest",
		hands="Chasseur's Gants +3",
		feet="Lanun Bottes +3",
		neck="Commodore Charm +1",
		waist="Fotia Belt",
		back=gear.ranger_wsd_jse_back,
	})
    	
    sets.precast.WS['Detonator'] = sets.precast.WS['Last Stand']
    sets.precast.WS['Detonator'].Acc = sets.precast.WS['Last Stand'].Acc
    sets.precast.WS['Slug Shot'] = sets.precast.WS['Last Stand']
    sets.precast.WS['Slug Shot'].Acc = sets.precast.WS['Last Stand'].Acc
    sets.precast.WS['Numbing Shot'] = sets.precast.WS['Last Stand']
    sets.precast.WS['Numbing Shot'].Acc = sets.precast.WS['Last Stand'].Acc
    sets.precast.WS['Sniper Shot'] = sets.precast.WS['Last Stand']
    sets.precast.WS['Sniper Shot'].Acc = sets.precast.WS['Last Stand'].Acc
    sets.precast.WS['Split Shot'] = sets.precast.WS['Last Stand']
    sets.precast.WS['Split Shot'].Acc = sets.precast.WS['Last Stand'].Acc
	
    sets.precast.WS['Leaden Salute'] = set_combine(sets.precast.WS, {
		ammo=gear.MAbullet,
		head="Pixie Hairpin +1",
		body="Lanun Frac +3",
		neck="Commodore Charm +1",
		ear1="Friomisi Earring",
		waist="Fotia Belt",
		feet="Lanun Bottes +3",
		ring1="Archon Ring",
		ring2="Dingir Ring",
		back=gear.magic_wsd_jse_back,
	})
	
    sets.precast.WS['Aeolian Edge'] = set_combine(sets.precast.WS, {
		ammo=gear.MAbullet,
		body="Lanun Frac +3",
		feet="Lanun Bottes +3",
		neck="Fotia Gorget",
		ear1="Friomisi Earring",
		waist="Fotia Belt",
		ring1="Dingir Ring",
	})
	
	 sets.precast.WS['Wildfire'] = set_combine(sets.precast.WS, {
		ammo=gear.MAbullet,
		body="Lanun Frac +3",
		feet="Lanun Bottes +3",
		neck="Fotia Gorget",
		ear1="Friomisi Earring",
		waist="Eschan Stone",
		ring1="Dingir Ring",
		back=gear.magic_wsd_jse_back,
	})
		
     sets.precast.WS['Hot Shot'] = set_combine(sets.precast.WS, {
		ammo=gear.MAbullet,
		body="Lanun Frac +3",
		hands="Chasseur's Gants +3",
		feet="Lanun Bottes +3",
		neck="Commodore Charm +1",
		ear1="Friomisi Earring",
		waist="Eschan Stone",
		ring1="Dingir Ring",
		back=gear.magic_wsd_jse_back,
	})
		
		--Because omen skillchains.
    sets.precast.WS['Burning Blade'] = {}

	-- Swap to these on Moonshade using WS if at 3000 TP
	sets.MaxTP = {}
	sets.AccMaxTP = {}
        
    -- Midcast Sets
    sets.midcast.FastRecast = {}
        
    -- Specific spells

	sets.midcast.Cure = {}
	
	sets.Self_Healing = {}
	sets.Cure_Received = {}
	sets.Self_Refresh = {}
	
    sets.midcast.Utsusemi = sets.midcast.FastRecast

    -- Ranged gear
    sets.midcast.RA = {ammo=gear.RAbullet,
        head="Ikenga's Hat",neck="Iskur Gorget",ear1="Telos Earring",ear2="Chasseur's Earring +2",
        body="Ikenga's Vest",hands="Ikenga's Gloves",ring1="Ilabrat Ring",ring2="Dingir Ring",
        back=gear.tp_ranger_jse_back,waist="Reiki Yotai",legs="Ikenga's Trousers",feet="Ikenga's Clogs"}

    sets.midcast.RA.Acc = {ammo=gear.RAbullet,
		head="Malignance Chapeau",neck="Iskur Gorget",ear1="Enervating Earring",ear2="Telos Earring",
        body="Malignance Tabard",hands="Malignance Gloves",ring1="Rajas Ring",ring2="Petrov Ring",
        back=gear.tp_ranger_jse_back,waist="Reiki Yotai",legs="Malignance Tights",feet="Malignance Boots"}
		
	sets.buff['Triple Shot'] = {}
    
    -- Sets to return to when not performing an action.
	
	sets.DayIdle = {}
	sets.NightIdle = {}
	
	sets.buff.Doom = set_combine(sets.buff.Doom, {})
    
    -- Resting sets
    sets.resting = {}
	sets.BulletPouch = {waist="Chr. Bul. Pouch"}

    -- Idle sets
    sets.idle = {main="Naegling", Sub="Nusku Shield", range= "Fomalhaut", ammo=gear.RAbullet,
		head="Malignance Chapeau",neck="Warder's charm +1",ear1="Hearty Earring",ear2="Chasseur's Earring +2",
        body="Malignance Tabard",hands="Malignance Gloves",ring1="Defending Ring",ring2="Vocane Ring",
        back=gear.tp_jse_back,waist="Carrier's Sash",legs="Malignance Tights",feet="Malignance Boots"}
		
    sets.idle.OnehandSword = set_combine(sets.idle, {Main="Naegling", sub="Nusku Shield", range= "Fomalhaut", ammo=gear.RAbullet,})
	sets.idle.DWSword = set_combine(sets.idle, {Main="Naegling", sub="Gleti's Knife", range= "Fomalhaut", ammo=gear.RAbullet,})
	sets.idle.OnehandRange = set_combine(sets.idle, {Main={ name="Lanun Knife", augments={'Path: A',}}, sub="Nusku Shield", range= "Fomalhaut", ammo=gear.RAbullet,})
	sets.idle.DWRange = set_combine(sets.idle, {Main={ name="Lanun Knife", augments={'Path: A',}}, sub="Gleti's Knife", range= "Fomalhaut", ammo=gear.RAbullet,})
	sets.idle.DWRAngAcc = set_combine(sets.idle, {Main={ name="Lanun Knife", augments={'Path: A',}}, sub="Kustawi +1", range= "Fomalhaut", ammo=gear.RAbullet,})
	sets.idle.OnehandDaggerTP = set_combine(sets.idle, {Main="Tauret", sub="Nusku Shield", range= "Fomalhaut", ammo=gear.RAbullet,})
	
	sets.idle.Default = set_combine(sets.idle, {Main="Rostam", sub="Nusku Shield", range= "Death Penalty", ammo=gear.RAbullet,})
	sets.idle.Ranged = set_combine(sets.idle, {main={ name="Lanun Knife", augments={'Path: A',}}, Sub="Kustawi +1", range= "Fomalhaut", ammo=gear.RAbullet,})
	sets.idle.Magic = set_combine(sets.idle, {Main="Naegling", sub="Tauret", range= "Death Penalty", ammo=gear.RAbullet,})
	sets.idle.Melee = set_combine(sets.idle, {Main="Naegling", sub="Gleti's Knife", range= "Anarchy +2", ammo=gear.RAbullet,})
	sets.idle.Hybrid = set_combine(sets.idle, {Main={ name="Lanun Knife", augments={'Path: A',}}, sub="Tauret", range= "Death Penalty", ammo=gear.RAbullet,})
	
	sets.idle.Ranged2 = {main={ name="Lanun Knife", augments={'Path: A',}}, Sub="Kustawi +1", range= "Fomalhaut", ammo=gear.RAbullet,
		head="Malignance Chapeau",neck="Warder's charm +1",ear1="Dedition Earring",ear2="Telos Earring",
        body="Malignance Tabard",hands="Malignance Gloves",ring1="Defending Ring",ring2="Vocane Ring",
        back=gear.tp_jse_back,waist="Carrier's Sash",legs="Malignance Tights",feet="Malignance Boots"}
	
	sets.idle.Melee2 = {main="Naegling", Sub="Gleti's Knife", range= "Anarchy +2", ammo=gear.RAbullet,
		head="Malignance Chapeau",neck="Warder's charm +1",ear1="Dedition Earring",ear2="Telos Earring",
        body="Malignance Tabard",hands="Malignance Gloves",ring1="Defending Ring",ring2="Vocane Ring",
        back=gear.tp_jse_back,waist="Carrier's Sash",legs="Malignance Tights",feet="Malignance Boots"}
	
	sets.idle.Magic2 =  {main="Naegling", Sub="Tauret", range= "Death Penalty", ammo=gear.RAbullet,
		head="Malignance Chapeau",neck="Warder's charm +1",ear1="Dedition Earring",ear2="Telos Earring",
        body="Malignance Tabard",hands="Malignance Gloves",ring1="Defending Ring",ring2="Vocane Ring",
        back=gear.tp_jse_back,waist="Carrier's Sash",legs="Malignance Tights",feet="Malignance Boots"}
	
	sets.idle.Dyna =  {main="Rostam", Sub="Tauret", range= "Death Penalty", ammo=gear.RAbullet,
		head="Malignance Chapeau",neck="Warder's charm +1",ear1="Dedition Earring",ear2="Telos Earring",
        body="Malignance Tabard",hands="Malignance Gloves",ring1="Defending Ring",ring2="Vocane Ring",
        back=gear.tp_jse_back,waist="Carrier's Sash",legs="Malignance Tights",feet="Malignance Boots"}
	
	
	
	sets.idle.PDT = {}
		
    sets.idle.Refresh = {}
    
    -- Defense sets
    sets.defense.PDT = {}

    sets.defense.MDT = {}
		
    sets.defense.MEVA = {}

    sets.Kiting = {legs="Carmine Cuisses +1"}
	sets.TreasureHunter = set_combine(sets.TreasureHunter, {})
	sets.DWMax = {waist="Reiki Yotai"}

	-- Weapons sets
	--sets.weapons.Default = {main="Naegling",sub="Nusku Shield",range="Fomalhaut"}
	--sets.weapons.Ranged = {main="Rostam",sub="Nusku Shield",range="Fomalhaut"}
	--sets.weapons.Evisceration = {main="Tauret",sub="Nusku Shield",range="Ataktos"}
	--sets.weapons.DualWeapons = {main="Naegling",sub="Blurred Knife +1",range="Fomalhaut"}
	--sets.weapons.DualSavageWeapons = {main="Naegling",sub="Blurred Knife +1",range="Ataktos"}
	--sets.weapons.DualEvisceration = {main="Tauret",sub="Blurred Knife +1",range="Ataktos"}
	--sets.weapons.Savage = {main="Naegling",sub="Nusku Shield",range="Ataktos"}
	--sets.weapons.DualLeadenRanged = {main="Rostam",sub="Tauret",range="Fomalhaut"}
	--sets.weapons.DualLeadenMelee = {main="Naegling",sub="Atoyac",range="Fomalhaut"}
	--sets.weapons.DualAeolian = {main="Rostam",sub="Tauret",range="Ataktos"}
	--sets.weapons.DualLeadenMeleeAcc = {main="Naegling",sub="Blurred Knife +1",range="Fomalhaut"}
	--sets.weapons.DualRanged = {main="Rostam",sub="Kustawi +1",range="Fomalhaut"}
	sets.weapons.Fomalhaut = {range="Fomalhaut"}
	sets.weapons.DeathPenalty = {range="Death Penalty"}
	sets.weapons.Anarchy = {range="Anarchy +2"}
	sets.weapons.NaeglingRange = {main="Naegling",sub="Nusku Shield",range="Fomalhaut"}
	sets.weapons.DWSwordRange = {main="Naegling",sub="Tauret",range="Fomalhaut"}
	sets.weapons.LanunRNG = {main={ name="Lanun Knife", augments={'Path: A',}},sub="Nusku Shield",range="Fomalhaut"}
	sets.weapons.DWDaggerRNG = {main={ name="Lanun Knife", augments={'Path: A',}},sub="Gleti's Knife",range="Fomalhaut"}
	sets.weapons.TauretRNG = {main="Tauret",sub="Nusku Shield",range="Fomalhaut"}
	sets.weapons.FullAcc = {main={ name="Lanun Knife", augments={'Path: A',}},sub="Kustawi +1",range="Fomalhaut"}
	--sets.weapons.Molybdosis = {main="Naegling",sub="Tauret",range="Molybdosis"}
	
	--sets.weapons.Tauret2 = {main="Tauret",sub="Naegling",range="Fomalhaut"}
	--sets.weapons.OneHandMAB = {main="Naegling",sub="Nusku Shield",range="Molybdosis"}
	--sets.weapons.DualMAB = {main="Naegling",sub="Tauret",range="Molydbosis"}
	--sets.weapons.DualRNG = {main="Lanun Knife",sub="Gleti's Knife",range="Fomalhaut"}
	--sets.weapons.DualLeaden = {main="Naegling",sub="Tauret",range="Fomalhaut"}
	--sets.weapons.Rolls = {main="Lanun Knife",sub="Nusku Shield",range="Compensator"}
	-- Engaged sets

    -- Variations for TP weapon and (optional) offense/defense modes.  Code will fall back on previous
    -- sets if more refined versions aren't defined.
    -- If you create a set with both offense and defense modes, the offense mode should be first.
    -- EG: sets.engaged.Dagger.Accuracy.Evasion
    
    -- Normal melee group
    sets.engaged = {
		head="Malignance Chapeau",neck="Loricate Torque +1",ear1="Dedition Earring",ear2="Telos Earring",
        body="Malignance Tabard",hands="Malignance Gloves",ring1="Epona's Ring",ring2="Petrov Ring",
        back=gear.tp_jse_back,waist="Sailfi Belt +1",legs="Malignance Tights",feet="Malignance Boots"
		}
    
    sets.engaged.Acc = {}
		
    sets.engaged.DT = {}
    
    sets.engaged.Acc.DT = {}

    sets.engaged.DW = {
		head="Malignance Chapeau",neck="Loricate Torque +1",ear1="Cessance Earring",ear2="Suppanomimi",
        body="Malignance Tabard",hands="Malignance Gloves",ring1="Defending Ring",ring2="Petrov Ring",
        back=gear.tp_jse_back,waist="Reiki Yotai",legs="Malignance Tights",feet="Malignance Boots"
		}
    
    sets.engaged.DW.Acc = {}
		
    sets.engaged.DW.DT = {}
    
    sets.engaged.DW.Acc.DT = {}
end

-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
    if player.sub_job == 'WAR' then
        set_macro_page(2, 11)
    elseif player.sub_job == 'DNC' then
		set_macro_page(3, 11)
    elseif player.sub_job == 'NIN' then
        set_macro_page(4, 11)
    elseif player.sub_job == 'DRG' then
        set_macro_page(5, 11)
    else
        set_macro_page(1, 11)
    end
end

function user_job_lockstyle()
	if player.equipment.main == nil or player.equipment.main == 'empty' then
		windower.chat.input('/lockstyleset 010')
	elseif res.items[item_name_to_id(player.equipment.main)].skill == 3 then --Sword in main hand.
		if player.equipment.sub == nil or player.equipment.sub == 'empty' then --Sword/Nothing.
				windower.chat.input('/lockstyleset 010')
		elseif res.items[item_name_to_id(player.equipment.sub)].shield_size then --Sword/Shield
				windower.chat.input('/lockstyleset 010')
		elseif res.items[item_name_to_id(player.equipment.sub)].skill == 3 then --Sword/Sword.
			windower.chat.input('/lockstyleset 010')
		elseif res.items[item_name_to_id(player.equipment.sub)].skill == 2 then --Sword/Dagger.
			windower.chat.input('/lockstyleset 010')
		else
			windower.chat.input('/lockstyleset 010') --Catchall just in case something's weird.
		end
	elseif res.items[item_name_to_id(player.equipment.main)].skill == 2 then --Dagger in main hand.
		if player.equipment.sub == nil or player.equipment.sub == 'empty' then --Dagger/Nothing.
			windower.chat.input('/lockstyleset 010')
		elseif res.items[item_name_to_id(player.equipment.sub)].shield_size then --Dagger/Shield
				windower.chat.input('/lockstyleset 010')
		elseif res.items[item_name_to_id(player.equipment.sub)].skill == 2 then --Dagger/Dagger.
			windower.chat.input('/lockstyleset 010')
		else
			windower.chat.input('/lockstyleset 010') --Catchall just in case something's weird.
		end
	end
end

autows_list = {['Default']='Savage Blade',['Evisceration']='Evisceration',['Savage']='Savage Blade',['Ranged']='Last Stand',['DualWeapons']='Savage Blade',['DualSavageWeapons']='Savage Blade',['DualEvisceration']='Evisceration',['DualLeadenRanged']='Leaden Salute',['DualLeadenMelee']='Leaden Salute',['DualAeolian']='Aeolian Edge',['DualRanged']='Last Stand'}
