function user_job_setup()

    -- Options: Override default values	
	state.OffenseMode:options('Normal','Acc')
    state.HybridMode:options('Tank','DDTank','Normal')
    state.WeaponskillMode:options('Match','Normal', 'Acc')
    state.CastingMode:options('Normal','SIRD','MEVA')
	state.Passive:options('None','AbsorbMP')
    state.PhysicalDefenseMode:options('PDT', 'PDT_HP','PDT_Reraise')
    state.MagicalDefenseMode:options('MDT','MDT_HP','MDT_Reraise')
	state.ResistDefenseMode:options('Status', 'Death', 'Charm', 'Knockback')
	state.IdleMode:options('Normal','Refresh','phalanx','Flee', 'Kite')
	state.Weapons:options('None','BurtgangSrivatsa','BurtgangAegis','BurtgangOchain','NaeglingBlurred','ClubBlurred')
    state.ExtraDefenseMode = M{['description']='Extra Defense Mode','None','MP','Twilight'}
	
	gear.fastcast_jse_back = {name="Rudianos's Mantle",augments={'INT+20','Eva.+20 /Mag. Eva.+20','Mag. Evasion+10','"Fast Cast"+10',}}
	gear.enmity_jse_back = {name="Rudianos's Mantle",augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10',}}

	-- Additional local binds
	send_command('bind !` gs c SubJobEnmity')
	send_command('bind ^backspace input /ja "Shield Bash" <t>')
	send_command('bind @backspace input /ja "Cover" <stpt>')
	send_command('bind !backspace input /ja "Sentinel" <me>')
	send_command('bind @= input /ja "Chivalry" <me>')
	send_command('bind != input /ja "Palisade" <me>')
	send_command('bind ^delete input /ja "Provoke" <stnpc>')
	send_command('bind !delete input /ma "Cure IV" <stal>')
	send_command('bind @delete input /ma "Flash" <stnpc>')
    send_command('bind !f11 gs c cycle ExtraDefenseMode')
	send_command('bind @` gs c cycle RuneElement')
	send_command('bind ^pause gs c toggle AutoRuneMode')
	send_command('bind ^q gs c set IdleMode Kiting')
	send_command('bind !q gs c set IdleMode PDT')
	send_command('bind @f8 gs c toggle AutoTankMode')
	send_command('bind @f10 gs c toggle TankAutoDefense')
	send_command('bind ^@!` gs c cycle SkillchainMode')
	
    select_default_macro_book()
    update_defense_mode()
end

function init_gear_sets()
	
	--------------------------------------
	-- Precast sets
	--------------------------------------
	
    sets.Enmity = {
		ammo="Staunch Tathlum",
		head="Souveran Schaller +1",
		body="Souveran Cuirass +1",
		hands="Souveran Handschuhs +1",
		legs="Founder's Hose",
		feet="Eschite Greaves",
		neck="Moonbeam Necklace",
		waist="Audumbla Sash",
		left_ear="Knightly Earring",
		right_ear="Chev. Earring +2",
		left_ring="Defending Ring",
		right_ring="Moonbeam Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+10 /Mag. Eva.+10','Enmity+10','Phys. dmg. taken-10%',}},
	}
		
    sets.Enmity.SIRD = set_combine(sets.Enmity,{body="Chev. Cuirass +2"})	
	sets.Enmity.MEVA = set_combine(sets.Enmity,{head="Sakpata's Helm", body="Chev. Cuirass +2", hands="Sakpata's Gauntlets", left_ring="Moonbeam Ring", right_ring="Moonbeam Ring", legs="Chevalier's Cuirass +2", feet="Sakpata's Leggings",})	
	sets.Enmity.DT = {}
	
	sets.Enmity.Ability = set_combine(sets.Enmity,{hands="Souveran Handschuhs +1", legs="Souveran Diechlings +1", waist="Creed Baudrier", left_ear="Cryptic Earring", })
	
    -- Precast sets to enhance JAs
    sets.precast.JA['Invincible'] = set_combine(sets.Enmity.Ability,{})
    sets.precast.JA['Holy Circle'] = set_combine(sets.Enmity.Ability,{})
    sets.precast.JA['Sentinel'] = set_combine(sets.Enmity.Ability,{})
    sets.precast.JA['Rampart'] = set_combine(sets.Enmity.Ability,{})
    sets.precast.JA['Fealty'] = set_combine(sets.Enmity.Ability,{})
    sets.precast.JA['Divine Emblem'] = set_combine(sets.Enmity.Ability,{})
    sets.precast.JA['Cover'] = set_combine(sets.Enmity.Ability, {}) 
	sets.precast.JA['Shield Bash'] = set_combine(sets.Enmity.Ability, {hands="Caballarius Gauntlets +2"})		
	sets.precast.JA['Chivalry'] = {}
   
	sets.precast.JA['Invincible'].DT = set_combine(sets.Enmity.DT,{})
    sets.precast.JA['Holy Circle'].DT = set_combine(sets.Enmity.DT,{})
    sets.precast.JA['Sentinel'].DT = set_combine(sets.Enmity.DT,{})
    sets.precast.JA['Rampart'].DT = set_combine(sets.Enmity.DT,{}) 
    sets.precast.JA['Fealty'].DT = set_combine(sets.Enmity.DT,{})
    sets.precast.JA['Divine Emblem'].DT = set_combine(sets.Enmity.DT,{})
    sets.precast.JA['Cover'].DT = set_combine(sets.Enmity.DT, {}) 
	sets.precast.JA['Shield Bash'].DT = set_combine(sets.Enmity.DT, {hands="Caballarius Gauntlets +2"})		
	sets.precast.JA['Chivalry'].DT = {}
	
    -- Runefencer
	sets.precast.JA['Vallation'] = sets.Enmity.Ability
    sets.precast.JA['Pflug'] = sets.Enmity.Ability
    sets.precast.JA['Valiance'] = sets.Enmity.Ability
	
	--Warrior
    sets.precast.JA['Provoke'] = set_combine(sets.Enmity, {})
	sets.precast.JA['Warcry'] = set_combine(sets.Enmity, {})
	sets.precast.JA['Palisade'] = set_combine(sets.Enmity, {})
	sets.precast.JA['Intervene'] = set_combine(sets.Enmity, {})
	sets.precast.JA['Defender'] = set_combine(sets.Enmity, {})
	sets.precast.JA['Berserk'] = set_combine(sets.Enmity, {})
	sets.precast.JA['Aggressor'] = set_combine(sets.Enmity, {})
	
    sets.precast.JA['Provoke'].DT = set_combine(sets.Enmity.DT, {})
	sets.precast.JA['Warcry'].DT = set_combine(sets.Enmity.DT, {})
	sets.precast.JA['Palisade'].DT = set_combine(sets.Enmity.DT, {})
	sets.precast.JA['Intervene'].DT = set_combine(sets.Enmity.DT, {})
	sets.precast.JA['Defender'].DT = set_combine(sets.Enmity.DT, {})
	sets.precast.JA['Berserk'].DT = set_combine(sets.Enmity.DT, {})
	sets.precast.JA['Aggressor'].DT = set_combine(sets.Enmity.DT, {})

    -- Dancer
	sets.precast.Waltz = set_combine(sets.Enmity, {})
	sets.precast.Waltz['Healing Waltz'] = {}
    sets.precast.Step = set_combine(sets.Enmity, {})
	sets.precast.JA['Violent Flourish'] = {}
	sets.precast.JA['Animated Flourish'] = set_combine(sets.Enmity, {})

    
	-- Fast cast sets for spells
    
    sets.precast.FC = {
		ammo="Incantor Stone",
		head="Chev. Armet +2",
		body="Sacro Breastplate",
		hands="Souveran Handschuhs +1",
		legs="Chev. Cuisses +2",
		feet="Sakpata's Leggings",
		neck="Voltsurge Torque",
		waist="Sailfi Belt +1",
		left_ear="Tuisto Earring",
		right_ear="Loquac. Earring",
		left_ring="Defending Ring",
		right_ring="Moonbeam Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+10 /Mag. Eva.+10','Enmity+10','Phys. dmg. taken-10%',}},
	}
		
    sets.precast.FC.DT = {}
		
    sets.precast.FC['Enhancing Magic'] = set_combine(sets.precast.FC, {})
	sets.precast.FC['Enhancing Magic'].DT = set_combine(sets.precast.FC.DT, {})
	
	sets.precast.FC.Cure = set_combine(sets.precast.FC, {})
  
    -- Weaponskill sets
    -- Default set for any weaponskill that isn't any more specifically defined
    sets.precast.WS = {
		ammo="Coiste Bodhar",
		head="Nyame Helm",
		body="Nyame Mail",
		hands="Nyame Gauntlets",
		legs="Nyame Flanchard",
		feet="Nyame Sollerets",
		neck="Fotia Gorget",
		waist="Sailfi Belt +1",
		left_ear="Ishvara Earring",
		right_ear="Moonshade Earring",
		left_ring="Regal Ring",
		right_ring="Cornelia's Ring",
	    back={ name="Rudianos's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Weapon skill damage +10%',}},
	}
		
    sets.precast.WS.DT = {}

    sets.precast.WS.Acc = {}

    -- Specific weaponskill sets.  Uses the base set if an appropriate WSMod version isn't found.
    sets.precast.WS['Requiescat'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Requiescat'].Acc = set_combine(sets.precast.WS.Acc, {})

	sets.precast.WS['Chant du Cygne'] = set_combine(sets.precast.WS, {})
    sets.precast.WS['Chant du Cygne'].Acc = set_combine(sets.precast.WS.Acc, {})

	sets.precast.WS['Savage Blade'] = set_combine(sets.precast.WS, {neck="Rep. Plat. Medal",ear1="Ishvara Earring",ear2="Moonshade Earring"})
    sets.precast.WS['Savage Blade'].Acc = set_combine(sets.precast.WS.Acc, {})
	
    sets.precast.WS['Atonement'] = {
		ammo="Staunch Tathlum",
		head="Souveran Schaller +1",
		body="Souveran Cuirass +1",
		hands="Souveran Handschuhs +1",
		legs="Souveran Diechlings +1",
		feet="Eschite Greaves",
		neck="Unmoving Collar +1",
		waist="Creed Baudrier",
		left_ear="Tuisto Earring",
		right_ear="Cryptic Earring",
		left_ring="EihwaZ Ring",
		right_ring="Moonbeam Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Enmity+10','Chance of successful block +5',}},
	}

	-- Swap to these on Moonshade using WS if at 3000 TP
	sets.MaxTP = {ear1="Ishvara Earring",ear2="Telos Earring",}
	sets.AccMaxTP = {}


	--------------------------------------
	-- Midcast sets
	--------------------------------------

    sets.midcast.FastRecast = {}	
	sets.midcast.FastRecast.DT = {}

    sets.midcast.Flash = set_combine(sets.Enmity, {})
	sets.midcast.Flash.SIRD = set_combine(sets.Enmity.SIRD, {})
    sets.midcast.Flash.MEVA = set_combine(sets.Enmity.MEVA, {})
	
	sets.midcast.Stun = set_combine(sets.Enmity, {})
	sets.midcast.Stun.SIRD = set_combine(sets.Enmity.SIRD, {})
	
	sets.midcast['Blue Magic'] = sets.Enmity
	sets.midcast['Blue Magic'].SIRD = set_combine(sets.Enmity.SIRD, {})
	sets.midcast['Blue Magic'].MEVA = set_combine(sets.Enmity.MEVA, {})
	sets.midcast.Cocoon = set_combine(sets.Enmity.SIRD, {})

    sets.midcast.Cure = {
		ammo="Staunch Tathlum",
		head="Souveran Schaller +1",
		body="Souveran Cuirass +1",
		hands="Souveran Handschuhs +1",
		legs="Founder's Hose",
		feet="Eschite Greaves",
		neck="Moonbeam Necklace",
		waist="Audumbla Sash",
		left_ear="Knightly Earring",
		right_ear="Chev. Earring +2",
		left_ring="Defending Ring",
		right_ring="Moonbeam Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+10 /Mag. Eva.+10','Enmity+10','Phys. dmg. taken-10%',}},
	}
		
    sets.midcast.Cure.SIRD = {body="Chev. Cuirass +2",}
	sets.midcast.Cure.MEVA = set_combine(sets.midcast.Cure, {head="Sakpata's Helm", body="Chev. Cuirass +2", hands="Sakpata's Gauntlets", left_ring="Moonbeam Ring", right_ring="Moonbeam Ring", legs="Chevalier's Cuirass +2", feet="Sakpata's Leggings",})	
		
    sets.midcast.Cure.DT = {}
		
    sets.midcast.Banish = sets.midcast.Cure
	
	sets.midcast.Reprisal = {
		ammo="Staunch Tathlum", --10
		head="Souveran Schaller +1", --20
		body="Souveran Cuirass +1",
		hands="Regal Gauntlets", --10
		legs="Founder's Hose", --30
		feet="Eschite Greaves", --15
		neck="Moonbeam Necklace", --10
		waist="Audumbla Sash", --10
		left_ear="Cryptic Earring",
		right_ear="Chev. Earring +2",
		left_ring="Defending Ring",
		right_ring="Defending Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+10 /Mag. Eva.+10','Enmity+10','Phys. dmg. taken-10%',}},
	}

	--sets.Self_Healing = sets.midcast.Cure
	--sets.Self_Healing.SIRD = {body="Chev. Cuirass +2",}
	--sets.Self_Healing.MEVA = sets.midcast.Cure.MEVA
	--sets.Self_Healing.DT = {}
	--sets.Cure_Received = {}
	--sets.Self_Refresh = {}

    --sets.midcast['Enhancing Magic'] = {}
	sets.midcast['Enhancing Magic'] = sets.midcast.Reprisal		
	sets.midcast['Enhancing Magic'].SIRD = set_combine(sets.midcast['Enhancing Magic'], {body="Chev. Cuirass +2"})
	sets.midcast['Enhancing Magic'].MEVA = set_combine(sets.midcast['Enhancing Magic'], {head="Sakpata's Helm", body="Chev. Cuirass +2", hands="Sakpata's Gauntlets", left_ring="Moonbeam Ring", right_ring="Moonbeam Ring", legs="Chevalier's Cuirass +2", feet="Sakpata's Leggings",})

	sets.midcast.Stoneskin = set_combine(sets.midcast['Enhancing Magic'], {})

    sets.midcast.Protect = set_combine(sets.midcast['Enhancing Magic'], {ring2="Sheltered Ring"})
    sets.midcast.Shell = set_combine(sets.midcast['Enhancing Magic'], {ring2="Sheltered Ring"})
	
	sets.midcast.Phalanx = set_combine(sets.midcast['Enhancing Magic'], {
		main="Sakpata's Sword",
		sub="Priwen",
		ammo="Staunch Tathlum",
		head={ name="Yorium Barbuta", augments={'Phalanx +3',}},
		body={ name="Valorous Mail", augments={'Accuracy+7','DEX+9','Phalanx +5','Mag. Acc.+16 "Mag.Atk.Bns."+16',}},
		hands="Souveran Handschuhs +1",
		legs="Sakpata's Cuisses",
		feet="Souveran Schuhs +1",
		neck="Colossus's Torque",
		waist="Audumbla Sash",
		left_ear="Odnowa Earring +1",
		right_ear="Mimir Earring",
		left_ring="Defending Ring",
		right_ring="Moonbeam Ring",
		back="Weard Mantle",
	})
	sets.midcast.Phalanx.SIRD = set_combine(sets.midcast['Enhancing Magic'].SIRD, {})
	sets.midcast.Phalanx.DT = set_combine(sets.midcast.Phalanx.SIRD, {})	
	sets.Phalanx_Received = {
		main="Sakpata's Sword",
		sub="Priwen",
		head={ name="Yorium Barbuta", augments={'Phalanx +3',}},
		body={ name="Valorous Mail", augments={'Accuracy+7','DEX+9','Phalanx +5','Mag. Acc.+16 "Mag.Atk.Bns."+16',}},
		hands="Souveran Handschuhs +1",
		legs="Sakpata's Cuisses",
		feet="Souveran Schuhs +1",
		back="Weard Mantle",
	}
	--------------------------------------
	-- Idle/resting/defense/etc sets
	--------------------------------------

    sets.resting = {}

    -- Idle sets
    sets.idle = {
		main="Burtgang",
		sub="Srivatsa",
		ammo="Staunch Tathlum",
		head="Chev. Armet +2",
		body="Sakpata's Plate",
		hands="Sakpata's Gauntlets",
		legs="Chev. Cuisses +2",
		feet="Sakpata's Leggings",
		neck="Warder's Charm +1",
		waist="Platinum Moogle Belt",
		left_ear="Tuisto Earring",
		right_ear="Chev. Earring +2",
		left_ring="Shadow Ring",
		right_ring="Warden's Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','Enmity+10','Chance of successful block +5',}},
	}
	
	sets.idle.phalanx = set_combine(sets.idle, {
		main="Sakpata's Sword",
		sub="Priwen",
		head="Yorium Barbuta",
		body={ name="Valorous Mail", augments={'Accuracy+7','DEX+9','Phalanx +5','Mag. Acc.+16 "Mag.Atk.Bns."+16',}},
		hands="Souveran Handschuhs +1",
		legs="Sakpata's Cuisses",
		feet="Souveran Schuhs +1",
		left_ear="Tuisto Earring +1",
		left_ring="Moonbeam Ring",
		right_ring="Moonbeam Ring",
		back="Weard Mantle",
	})
	
    	
   
	sets.idle.Refresh = set_combine(sets.idle, {main="Burtgang", ammo="Homiliary", hands="Regal Gauntlets", neck="Coatl Gorget +1", ring1="Defending Ring"})

	sets.idle.Tank = set_combine(sets.idle, {})
			
	sets.idle.Kite = set_combine(sets.idle, {legs="Carmine Cuisses +1",back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+10 /Mag. Eva.+10','Enmity+10','Phys. dmg. taken-10%',}},})

	sets.idle.Flee = set_combine(sets.idle, {feet="Hippomenes Socks +1",})

	sets.idle.Knock = set_combine(sets.idle, {legs="Dashing Subligar", back="Philidor Mantle", ring2="Vocane Ring"})

	sets.Kiting = {legs="Carmine Cuisses +1"}

	sets.latent_refresh = {}
	sets.latent_refresh_grip = {sub="Oneiros Grip"}
	sets.latent_regen = {}
	sets.DayIdle = {}
	sets.NightIdle = {}

	--------------------------------------
    -- Defense sets
    --------------------------------------
    
    -- Extra defense sets.  Apply these on top of melee or defense sets.
	sets.Knockback = {}
    sets.MP = {}
	sets.passive.AbsorbMP = {}
    sets.MP_Knockback = {}
    sets.Twilight = {head="Twilight Helm", body="Crepuscular Mail"}
	sets.TreasureHunter = set_combine(sets.TreasureHunter, {})
	
	-- Weapons sets
	sets.weapons.BurtgangAegis = {main="Burtgang",sub="Aegis"}
	sets.weapons.BurtgangOchain = {main="Burtgang",sub="Duban"}
	sets.weapons.BurtgangSrivatsa = {main="Burtgang",sub="Srivatsa"}
	
	sets.weapons.SakpataAegis = {main="Sakpata's Sword",sub="Aegis"}
	sets.weapons.SakpataOchain = {main="Sakpata's Sword",sub="Duban"}
	sets.weapons.SakpataSrivatsa = {main="Sakpata's Sword",sub="Srivatsa"}
	
	sets.weapons.ClubBlurred = {main="Beryllium Mace +1",sub="Blurred Shield +1"}
	sets.weapons.NaeglingBlurred = {main="Naegling",sub="Blurred Shield +1"}
	sets.weapons.DualWeapons = {main="Naegling",sub="Beryllium Mace +1"}
    
    
	
	
	sets.defense.PDT = set_combine(sets.idle,{Neck="Unmoving Collar +1"})
	sets.defense.PDT_HP = set_combine(sets.idle,{neck="Unmoving Collar +1", ring1="Moonbeam Ring", Ring2="Moonbeam Ring", ear2="Odnowa Earring +1"})
	sets.defense.PDT_Reraise = set_combine(sets.defense.PDT_HP,{head="Twilight Helm",body="Crepuscular Mail"})
	
	sets.defense.MDT = set_combine(sets.idle,{neck="Warder's Charm +1", ring1="Shadow Ring"})
	sets.defense.MDT_HP = set_combine(sets.idle,{neck="Unmoving Collar +1", ring1="Moonbeam Ring", Ring2="Moonbeam Ring", ear2="Odnowa Earring +1"})
	sets.defense.MDT_Reraise = set_combine(sets.defense.MDT_HP,{head="Twilight Helm",body="Crepuscular Mail"})
	
	sets.defense.Status =  set_combine(sets.idle,{main="Malignance Sword", body="Sakpata's Breastplate", ammo="Staunch Tathlum", Ear2="Hearty Earring"})
	sets.defense.Knockback = set_combine(sets.idle,{legs="Dashing Subligar", back="Philidor Mantle", ring2="Vocane Ring"})
	sets.defense.Death =  set_combine(sets.idle,{ring1="Shadow Ring", ring2="Warden's Ring"})	
	sets.defense.Charm =  set_combine(sets.idle,{main="Malignance Sword", body="Sakpata's Breastplate", Legs="Souveran Diechlings +1", ammo="Staunch Tathlum", Neck="Unmoving Collar +1", Ear2="Hearty Earring", ring1="Defending Ring"})
	
	sets.defense.Block = sets.idle	
	sets.defense.MEVA = sets.idle
    sets.defense.MEVA_HP = sets.idle
    
    
		
	--------------------------------------
	-- Engaged sets
	--------------------------------------
    
	sets.engaged = {
		ammo="Coiste Bodhar",
		head="Chev. Armet +2",
		body="Sakpata's Plate",
		hands="Sakpata's Gauntlets",
		legs="Chev. Cuisses +2",
		feet="Sakpata's Leggings",
		neck="Vim Torque +1",
		waist="Sailfi Belt +1",
		left_ear="Telos Earring",
		right_ear="Cessance Earring",
		left_ring="Moonbeam Ring",
		right_ring="Moonbeam Ring",
		back={ name="Rudianos's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','"Dbl.Atk."+10',}},
	}

    sets.engaged.Acc = {}

    sets.engaged.DW = {}

    sets.engaged.DW.Acc = {}

	sets.engaged.Tank = {
		ammo="Staunch Tathlum",
		head="Chev. Armet +2",
		body="Sakpata's Plate",
		hands="Sakpata's Gauntlets",
		legs="Chev. Cuisses +2",
		feet="Sakpata's Leggings",
		neck="Warder's Charm +1",
		waist="Sailfi Belt +1",
		left_ear="Tuisto Earring",
		right_ear="Chev. Earring +2",
		left_ring="Shadow Ring",
		right_ring="Chirich Ring",
		back={ name="Rudianos's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','"Dbl.Atk."+10',}},
	}
		
	sets.engaged.DDTank = {
		ammo="Coiste Bodhar",
		head="Sakpata's Helm",
		body="Sakpata's Plate",
		hands="Sakpata's Gauntlets",
		legs="Sakpata's Cuisses",
		feet="Sakpata's Leggings",
		neck="Vim Torque +1",
		waist="Sailfi Belt +1",
		left_ear="Telos Earring",
		right_ear="Cessance Earring",
		left_ring="Moonbeam Ring",
		right_ring="Moonbeam Ring",
		back={ name="Rudianos's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','"Dbl.Atk."+10',}},
	}
		
	sets.engaged.Acc.DDTank = {}
		
	sets.engaged.NoShellTank = {}
		
    sets.engaged.Reraise = set_combine(sets.engaged.Tank, sets.Reraise)
    sets.engaged.Acc.Reraise = set_combine(sets.engaged.Acc.Tank, sets.Reraise)
		
	--------------------------------------
	-- Custom buff sets
	--------------------------------------
	--sets.buff.Doom = set_combine(sets.buff.Doom, {})
	sets.buff.Doom = {
        neck="Nicander's Necklace", --20
        ring1="Blenmot's Ring",
        ring2="Blenmot's Ring",
        }
	sets.buff.Sleep = {neck="Vim Torque +1"}
    sets.buff.Cover = {}
end

-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
    -- Default macro set/book
    if player.sub_job == 'NIN' then
        set_macro_page(1, 10)
    elseif player.sub_job == 'RUN' then
        set_macro_page(1, 10)
    elseif player.sub_job == 'RDM' then
        set_macro_page(1, 10)
    elseif player.sub_job == 'BLU' then
        set_macro_page(1, 10)
    elseif player.sub_job == 'DNC' then
        set_macro_page(1, 10)
    else
        set_macro_page(1, 10) --War/Etc
    end
end

function user_job_lockstyle()
	windower.chat.input('/lockstyleset 06')
end

autows_list = {['None']='Atonement',['SakpataAegis']='Atonement',['SakpataSrivatsa']='Atonement',['NaeglingBlurred']='Savage Blade',
     ['ClubBlurred']='Realmrazer',['SakpataOchain']='Atonement'}