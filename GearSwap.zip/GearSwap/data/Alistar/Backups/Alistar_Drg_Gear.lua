-- Setup vars that are user-dependent.  Can override this function in a sidecar file.
function user_job_setup()
	-- Options: Override default values
    --state.OffenseMode:options('Normal','SomeAcc','Acc','FullAcc','Fodder')
	state.OffenseMode:options('Normal','DT')
    state.WeaponskillMode:options('Normal','Critbase')
    state.HybridMode:options('Normal')
    state.PhysicalDefenseMode:options('PDT', 'PDTReraise')
    state.MagicalDefenseMode:options('MDT', 'MDTReraise')
	state.ResistDefenseMode:options('MEVA')
	state.IdleMode:options('Normal', 'PDT','Refresh','Reraise')
    state.ExtraMeleeMode = M{['description']='Extra Melee Mode','None'}
	state.Weapons:options('Trishula','ShiningOne', 'Naegling', 'Club', 'Staff')
	state.Passive = M{['description'] = 'Passive Mode','None','MP','Twilight'}

    select_default_macro_book()
	
	-- Additional local binds
	send_command('bind ^` input /ja "Hasso" <me>')
	send_command('bind !` input /ja "Seigan" <me>')
	send_command('bind ^f11 gs c cycle MagicalDefenseMode')
	send_command('bind @f7 gs c toggle AutoJumpMode')
	send_command('bind @` gs c cycle SkillchainMode')
end

-- Define sets and vars used by this job file.
function init_gear_sets()
	--------------------------------------
	-- Start defining the sets
	--------------------------------------
	
	-- Precast Sets
	-- Precast sets to enhance JAs
	sets.precast.JA.Angon = {ammo="Angon",hands="Wyrm Finger Gauntlets +2"} --hands="Ptero. Fin. G. +1"
	sets.precast.JA.Jump = {}
	sets.precast.JA['Ancient Circle'] = {legs="Drachen Brais"} --legs="Vishap Brais"
	sets.precast.JA['High Jump'] = {}
	sets.precast.JA['Soul Jump'] = {legs="Peltast's Cuissots+2"}
	sets.precast.JA['Spirit Jump'] = {legs="Peltast's Cuissots +2"}
	sets.precast.JA['Super Jump'] = {}
	sets.precast.JA['Spirit Link'] = {} --head="Vishap Armet",hands="Lnc. Vmbrc. +2"
	sets.precast.JA['Call Wyvern'] = {} --body="Ptero. Mail +1"
	sets.precast.JA['Deep Breathing'] = {} --hands="Ptero. Armet +1"
	sets.precast.JA['Spirit Surge'] = {} --body="Ptero. Mail +1"
	sets.precast.JA['Steady Wing'] = {}
	
	-- Breath sets
	sets.precast.JA['Restoring Breath'] = {back="Brigantia's Mantle"}
	sets.precast.JA['Smiting Breath'] = {back="Brigantia's Mantle"}
	sets.HealingBreath = {back="Brigantia's Mantle"}
	--sets.SmitingBreath = {back="Brigantia's Mantle"}

	-- Fast cast sets for spells
	
	sets.precast.FC = {}
	
	-- Waltz set (chr and vit)
	sets.precast.Waltz = {}
		
	-- Don't need any special gear for Healing Waltz.
	sets.precast.Waltz['Healing Waltz'] = {}

	sets.midcast.Cure = {}
	
	sets.Self_Healing = {}
	sets.Cure_Received = {}
	sets.Self_Refresh = {}
	
	-- Midcast Sets
	sets.midcast.FastRecast = {}
		
	-- Put HP+ gear and the AF head to make healing breath trigger more easily with this set.
	sets.midcast.HB_Trigger = set_combine(sets.midcast.FastRecast, {head="Vishap Armet +1"})
	
	-- Weaponskill sets

	-- Default set for any weaponskill that isn't any more specifically defined
	
	sets.precast.WS = {
		ammo="Knobkierrie",
		head="Nyame Helm",
		body="Nyame Mail",
		hands="Nyame Gauntlets",
		legs="Nyame Flanchard",
		feet="Nyame Sollerets",
		neck="Fotia Gorget",
		waist="Fotia Belt",
		left_ear="Moonshade Earring",
		right_ear="Thrud Earring",
		left_ring="Epaminondas's Ring",
		right_ring="Cornelia's Ring",
		back={ name="Brigantia's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Weapon skill damage +10%',}},
	}
	sets.precast.WS.Critbase = set_combine(sets.precast.WS, {
		head="Gleti's Mask",
		body="Gleti's Cuirass",
		hands="Gleti's Gauntlets",
		legs="Gleti's Breeches",
		feet="Gleti's Boots",
		neck="Dragoon's Collar +2",
		waist="Fotia Belt",
		left_ear="Moonshade Earring",
		right_ear="Thrud Earring",
		left_ring="Niqmaddu Ring",
		right_ring="Cornelia's Ring",
		back={ name="Brigantia's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Weapon skill damage +10%',}},
	})
	
	
	-- Specific weaponskill sets.  Uses the base set if an appropriate WSMod version isn't found.
	sets.precast.WS['Savage Blade'] = set_combine(sets.precast.WS, {
		neck="Dragoon's Collar +2",
		waist="Sailfi Belt +1",
		right_ear="Peltast's Earring +1",
	})
	sets.precast.WS['Savage Blade'].Critbase = set_combine(sets.precast.WS.Critbase, {})
	

	sets.precast.WS['Drakesbane'] = set_combine(sets.precast.WS, {
		head="Gleti's Mask",
		body="Gleti's Cuirass",
		hands="Gleti's Gauntlets",
		legs="Gleti's Breeches",
		feet="Gleti's Boots",
		neck="Dragoon's Collar +2",
		waist="Sailfi Belt +1",
		left_ear="Moonshade Earring",
		right_ear="Thrud Earring",
		left_ring="Regal Ring",
		right_ring="Cornelia's Ring",
		back={ name="Brigantia's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Weapon skill damage +10%',}},
	
	})
	sets.precast.WS['Drakesbane'].Critbase = set_combine(sets.precast.WS.Critbase, {})
	

	sets.precast.WS['Camlann\'s Torment'] = set_combine(sets.precast.WS, {
		body="Gleti's Cuirass",
		legs="Gleti's Breeches",
		left_ring="Niqmaddu Ring",
		back={ name="Brigantia's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Weapon skill damage +10%',}},
	})
	sets.precast.WS['Camlann\'s Torment'].Critbase = set_combine(sets.precast.WS.Critbase, {})
	
	sets.precast.WS['Stardiver'] = set_combine(sets.precast.WS, {
		left_ear="Moonshade Earring",
		right_ear="Thrud Earring",
		left_ring="Regal Ring",
		right_ring="Cornelia's Ring",
		back={ name="Brigantia's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Weapon skill damage +10%',}},
	})
	sets.precast.WS['Stardiver'].Critbase = set_combine(sets.precast.WS.Critbase, {})
	
	
	sets.precast.WS['Impulse Drive'] = set_combine(sets.precast.WS, {
		body="Gleti's Cuirass",
		neck="Dragoon's Collar +2",
		waist="Sailfi Belt +1",
		left_ear="Moonshade Earring",
		right_ear="Thrud Earring",
		left_ring="Regal Ring",
		right_ring="Begrudging Ring",
		back={ name="Brigantia's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Weapon skill damage +10%',}},
	
	})
	sets.precast.WS['Impulse Drive'].Critbase = set_combine(sets.precast.WS.Critbase, {})
	
	
	sets.precast.WS['Retribution'] = set_combine(sets.precast.WS, {
		ammo="Knobkierrie",
		head="Nyame Helm",
		body="Nyame Mail",
		hands="Nyame Gauntlets",
		legs="Nyame Flanchard",
		feet="Nyame Sollerets",
		neck="Dragoon's Collar +2",
		waist="Sailfi Belt +1",
		left_ear="Moonshade Earring",
		left_ear="Moonshade Earring",
		right_ear="Thrud Earring",
		left_ring="Niqmaddu Ring",
		back={ name="Brigantia's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Weapon skill damage +10%',}},
	})
	sets.precast.WS['Retribution'].Critbase = set_combine(sets.precast.WS.Critbase, {})
	
	
	sets.precast.WS['Cataclysm'] = set_combine(sets.precast.WS, {
		head="Pixie Hairpin +1",
		waist="Fotia Belt",
		left_ear="Moonshade Earring",
		right_ear="Friomisi Earring",
		right_ring="Cornelia's Ring",
		left_ring="Archon Ring",
		back={ name="Brigantia's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Weapon skill damage +10%',}},
	})
	sets.precast.WS['Cataclysm'].Critbase = set_combine(sets.precast.WS['Cataclysm'], {})
	
	
	sets.precast.WS['Judgment'] = set_combine(sets.precast.WS, {
		neck="Dragoon's Collar +2",
		waist="Sailfi Belt +1",
		back={ name="Brigantia's Mantle", augments={'STR+20','Accuracy+20 Attack+20','Weapon skill damage +10%',}},
	})
	sets.precast.WS['Judgment'].Critbase = set_combine(sets.precast.WS['Judgment'], {})
	
	-- Sets to return to when not performing an action.
	
	-- Resting sets
	sets.resting = {}

	-- Idle sets
	sets.idle = {
		ammo="Staunch Tathlum",
		head="Nyame Helm",
		body="Sacro Breastplate",
		hands="Nyame Gauntlets",
		legs="Peltast's Cuissots +2",
		feet="Nyame Sollerets",
		neck="Dragoon's Collar +2",
		waist="Carrier's Sash",
		left_ear="Hearty Earring",
		right_ear="Peltast's Earring +1",
		left_ring="Defending Ring",
		right_ring="Vocane Ring",
		back={ name="Brigantia's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','"Dbl.Atk."+10','Phys. dmg. taken-10%',}},
	}
		
	sets.idle.Refresh = {}

	sets.idle.Weak = set_combine(sets.idle, {head="Twilight Helm",body="Twilight Mail"})
		
	sets.idle.Reraise = set_combine(sets.idle, {head="Twilight Helm",body="Twilight Mail"})
	
	-- Defense sets
	sets.defense.PDT = {}
		
	sets.defense.PDTReraise = set_combine(sets.defense.PDT, {head="Twilight Helm",body="Twilight Mail"})

	sets.defense.MDT = {}
		
	sets.defense.MDTReraise = set_combine(sets.defense.MDT, {head="Twilight Helm",body="Twilight Mail"})
		
	sets.defense.MEVA = {}

	sets.Kiting = {legs="Carmine Cuisses +1"}
	sets.Reraise = {head="Twilight Helm",body="Crepuscular Mail"}
	sets.buff.Doom = set_combine(sets.buff.Doom, {neck="Nicander's Necklace",left_ring="Blenmot's ring",right_ring="Blenmot's Ring"})
	sets.buff.Sleep = {head="Vim Torque +1"}
	
    -- Extra defense sets.  Apply these on top of melee or defense sets.
    sets.passive.MP = {ear2="Ethereal Earring",waist="Flume Belt +1"}
    sets.passive.Twilight = {head="Twilight Helm", body="Twilight Mail"}
	sets.TreasureHunter = set_combine(sets.TreasureHunter, {})
	
	-- Weapons sets
	sets.weapons.Trishula = {main="Trishula",sub="Utu Grip"}
	sets.weapons.ShiningOne = {main="Shining One", sub="Utu Grip"}
	sets.weapons.Naegling = {main="Naegling", sub="Regis"}
	sets.weapons.Staff = {main="Malignance Pole", sub="Utu Grip"}
	sets.weapons.Club = {main="Mafic Cudgel", sub="Regis"}
	
	-- Swap to these on Moonshade using WS if at 3000 TP
	sets.MaxTP = {}
	sets.AccMaxTP = {}
	sets.AccDayMaxTPWSEars = {}
	sets.DayMaxTPWSEars = {}
	sets.AccDayWSEars = {}
	sets.DayWSEars = {}
	
	-- Engaged sets

	-- Variations for TP weapon and (optional) offense/defense modes.  Code will fall back on previous
	-- sets if more refined versions aren't defined.
	-- If you create a set with both offense and defense modes, the offense mode should be first.
	-- EG: sets.engaged.Dagger.Accuracy.Evasion
	
	-- Normal melee group

	sets.engaged = {
		ammo="Coiste Bodhar",
		head="Nyame Helm",
		body="Nyame Mail",
		hands="Gleti's Gauntlets",
		legs="Nyame Flanchard",
		feet="Nyame Sollerets",
		neck="Vim Torque +1",
		waist="Sailfi Belt +1",
		left_ear="Sherida Earring",
		right_ear="Sroda Earring",
		left_ring="Niqmaddu Ring",
		right_ring="Moonbeam Ring",
		back={ name="Brigantia's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','"Dbl.Atk."+10','Phys. dmg. taken-10%',}},
	}
    
	sets.engaged.DT = {
		ammo="Coiste Bodhar",
		head="Nyame Helm",
		body="Nyame Mail",
		hands="Nyame Gauntlets",
		legs="Nyame Flanchard",
		feet="Nyame Sollerets",
		neck="Dragoon's Collar +2",
		waist="Sailfi Belt +1",
		left_ear="Sherida Earring",
		right_ear="Sroda Earring",
		left_ring="Niqmaddu Ring",
		right_ring="Moonbeam Ring",
		back={ name="Brigantia's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','"Dbl.Atk."+10','Phys. dmg. taken-10%',}},
	}
	sets.engaged.MDT = {}
	sets.engaged.Sword = {}
	sets.engaged.SomeAcc = {}
	sets.engaged.Acc = {}
    sets.engaged.FullAcc = {}
    sets.engaged.Fodder = {}

    sets.engaged.AM = {}
    sets.engaged.AM.SomeAcc = {}
	sets.engaged.AM.Acc = {}
    sets.engaged.AM.FullAcc = {}
    sets.engaged.AM.Fodder = {}
	
    sets.engaged.PDT = {}
    sets.engaged.SomeAcc.PDT = {}
	sets.engaged.Acc.PDT = {}
    sets.engaged.FullAcc.PDT = {}
    sets.engaged.Fodder.PDT = {}
	
    sets.engaged.AM.PDT = {}
    sets.engaged.AM.SomeAcc.PDT = {}
	sets.engaged.AM.Acc.PDT = {}
    sets.engaged.AM.FullAcc.PDT = {}
    sets.engaged.AM.Fodder.PDT = {}
		
	--[[ Melee sets for in Adoulin, which has an extra 2% Haste from Ionis.
	
    sets.engaged.Adoulin = {}
    sets.engaged.Adoulin.SomeAcc = {}
	sets.engaged.Adoulin.Acc = {}
    sets.engaged.Adoulin.FullAcc = {}
    sets.engaged.Adoulin.Fodder = {}

    sets.engaged.Adoulin.AM = {}
    sets.engaged.Adoulin.AM.SomeAcc = {}
	sets.engaged.Adoulin.AM.Acc = {}
    sets.engaged.Adoulin.AM.FullAcc = {}
    sets.engaged.Adoulin.AM.Fodder = {}
	
    sets.engaged.Adoulin.PDT = {}
    sets.engaged.Adoulin.SomeAcc.PDT = {}
	sets.engaged.Adoulin.Acc.PDT = {}
    sets.engaged.Adoulin.FullAcc.PDT = {}
    sets.engaged.Adoulin.Fodder.PDT = {}
	
    sets.engaged.Adoulin.AM.PDT = {}
    sets.engaged.Adoulin.AM.SomeAcc.PDT = {}
	sets.engaged.Adoulin.AM.Acc.PDT = {}
    sets.engaged.Adoulin.AM.FullAcc.PDT = {}
    sets.engaged.Adoulin.AM.Fodder.PDT = {}
	]]

end

-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
    -- Default macro set/book
    if player.sub_job == 'WAR' then
        set_macro_page(2, 2)
    elseif player.sub_job == 'SAM' then
        set_macro_page(1, 2)
    elseif player.sub_job == 'BLU' then
        set_macro_page(3, 2)
    else
        set_macro_page(5, 2
		)
    end
end

function user_job_lockstyle()
	windower.chat.input('/lockstyleset 06')
end

autows_list = {['Trishula']="Stardiver",['ShiningOne']='Impulse Drive',['Naegling']="Savage Blade",['Club']='Judgment',['Staff']='Cataclysm'}