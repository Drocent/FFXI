-- Setup vars that are user-dependent.  Can override this function in a sidecar file.
function user_job_setup()
    state.OffenseMode:options('Normal')
    state.CastingMode:options('Normal','Resistant','Proc','OccultAcumen','9k')
    state.IdleMode:options('Normal','PDT','Fish')
	state.HybridMode:options('Normal','PDT')
	state.Weapons:options('None','Akademos','Khatvanga','Musa')

	gear.nuke_jse_back = {name="Lugh's Cape",augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','"Mag.Atk.Bns."+10'}}
	
		-- Additional local binds
	send_command('bind ^` gs c cycle ElementalMode')
	send_command('bind !` gs c scholar power')
	send_command('bind @` gs c cycle MagicBurstMode')
	send_command('bind ^q gs c weapons Khatvanga;gs c set CastingMode OccultAcumen')
	send_command('bind !q gs c weapons default;gs c reset CastingMode')
	send_command('bind @f10 gs c cycle RecoverMode')
	send_command('bind @f8 gs c toggle AutoNukeMode')
	send_command('bind !pause gs c toggle AutoSubMode') --Automatically uses sublimation and Myrkr.
	send_command('bind @^` input /ja "Parsimony" <me>')
	send_command('bind ^backspace input /ma "Stun" <t>')
	send_command('bind !backspace gs c scholar speed')
	send_command('bind @backspace gs c scholar aoe')
	send_command('bind ^= input /ja "Dark Arts" <me>')
	send_command('bind != input /ja "Light Arts" <me>')
	send_command('bind ^\\\\ input /ma "Protect V" <t>')
	send_command('bind @\\\\ input /ma "Shell V" <t>')
	send_command('bind !\\\\ input /ma "Reraise III" <me>')
	
    select_default_macro_book()
end

-- Define sets and vars used by this job file.
function init_gear_sets()

    --------------------------------------
    -- Start defining the sets
    --------------------------------------

    -- Precast Sets

    -- Precast sets to enhance JAs

    sets.precast.JA['Tabula Rasa'] = {legs="Peda. Pants +1"}
	sets.precast.JA['Enlightenment'] = {} --body="Peda. Gown +1"

    -- Fast cast sets for spells

    sets.precast.FC = {
		main="Musa",
		sub="Ajja Grip",
		ammo="Incantor Stone",
		head="Merlinic Hood",
		body="Merlinic Jubbah",
		hands="Gende. Gages +1",
		legs="Lengo Pants",
		feet="Peda. Loafers",
		neck="Voltsurge Torque",
		waist="Embla Sash",
		left_ear="Malignance Earring",
		right_ear="Loquac. Earring",
		left_ring="Kishar Ring",
		right_ring="Prolix Ring",
		back={ name="Lugh's Cape", augments={'Mag. Acc+20 /Mag. Dmg.+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	}
		
	sets.precast.FC.Arts = {}

    sets.precast.FC['Enhancing Magic'] = set_combine(sets.precast.FC, {})

    sets.precast.FC['Elemental Magic'] = set_combine(sets.precast.FC, {})

    sets.precast.FC.Cure = set_combine(sets.precast.FC, {})

    sets.precast.FC.Curaga = sets.precast.FC.Cure

    sets.precast.FC.Impact = set_combine(sets.precast.FC['Elemental Magic'], {head=empty,body="Twilight Cloak"})
	sets.precast.FC.Dispelga = set_combine(sets.precast.FC, {main="Daybreak",sub="Genmei Shield"})

    -- Weaponskill sets
    -- Default set for any weaponskill that isn't any more specifically defined
    sets.precast.WS = {
		main="Mpaca's Staff",
		sub="Ajja Grip",
		ammo="Oshasha's Treatise",
		head="Pixie Hairpin +1",
		body={ name="Nyame Mail", augments={'Path: B',}},
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Fotia Gorget",
		waist="Hachirin-no-Obi",
		left_ear="Malignance Earring",
		right_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		left_ring="Cornelia's Ring",
		right_ring="Freke Ring",
		back={ name="Lugh's Cape", augments={'Mag. Acc+20 /Mag. Dmg.+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	}
	
	sets.precast.WS['Cataclysm'] = {
		main="Mpaca's Staff",
		sub="Ajja Grip",
		ammo="Oshasha's Treatise",
		head="Pixie Hairpin +1",
		body={ name="Nyame Mail", augments={'Path: B',}},
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Fotia Gorget",
		waist="Hachirin-no-Obi",
		left_ear="Malignance Earring",
		right_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		left_ring="Cornelia's Ring",
		right_ring="Archon Ring",
		back={ name="Lugh's Cape", augments={'Mag. Acc+20 /Mag. Dmg.+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	}
    -- Midcast Sets

	sets.TreasureHunter = set_combine(sets.TreasureHunter, {})
	
	-- Gear that converts elemental damage done to recover MP.	
	sets.RecoverMP = {}
	
	-- Gear for specific elemental nukes.
	sets.element.Dark = {head="Pixie Hairpin +1",ring2="Archon Ring"}

    sets.midcast.FastRecast = {}
		
    sets.midcast.Cure = {
		main="Daybreak",
		sub="Genmei Shield",
		ammo="Staunch Tathlum",
		head="Vanya Hood",
		body="Arbatel Gown +2",
		hands="Chironic Gloves",
		legs="Acad. Pants +1",
		feet="Vanya Clogs",
		neck="Colossus's Torque",
		waist="Hachirin-no-Obi",
		left_ear="Etiolation Earring",
		right_ear="Lugalbanda Earring",
		left_ring="Ephedra Ring",
		right_ring="Ephedra Ring",
		back="Twilight Cape",
	}
		
    sets.midcast.LightWeatherCure = {}
		
    sets.midcast.LightDayCure = {}

    sets.midcast.Curaga = sets.midcast.Cure

	sets.Self_Healing = {}
	sets.Cure_Received = {}
	sets.Self_Refresh = {}
	
	sets.midcast.Cursna = {
		main="Gada",
		sub="Genmei Shield",
		ammo="Staunch Tathlum",
		head="Arbatel Bonnet +3",
		body="Arbatel Gown +2",
		hands="Arbatel Bracers +3",
		legs="Acad. Pants +1",
		feet={ name="Vanya Clogs", augments={'Healing magic skill +20','"Cure" spellcasting time -7%','Magic dmg. taken -3',}},
		neck="Malison Medallion",
		waist="Hachirin-no-Obi",
		left_ear="Etiolation Earring",
		right_ear="Lugalbanda Earring",
		left_ring="Ephedra Ring",
		right_ring="Ephedra Ring",
		back="Oretan. Cape +1",
	}
		
	sets.midcast.StatusRemoval = set_combine(sets.midcast.FastRecast, {})

	sets.midcast['Enhancing Magic'] = {
	main="Musa",
    sub="Ajja Grip",
    ammo="Staunch Tathlum",
    head="Telchine Cap",
    body="Telchine Chas.",
    hands="Arbatel Bracers +3",
    legs="Telchine Braconi",
    feet="Telchine Pigaches",
    neck="Colossus's Torque",
    waist="Embla Sash",
    left_ear="Mimir Earring",
    right_ear="Arbatel Earring +1",
    left_ring="Stikini Ring",
    right_ring="Stikini Ring",
    back={ name="Lugh's Cape", augments={'Mag. Acc+20 /Mag. Dmg.+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	}

    sets.midcast.Regen = set_combine(sets.midcast['Enhancing Magic'], {main="Musa",sub="Ajja Grip",head="Arbatel Bonnet +3",back="Bookworm's Cape"})

    sets.midcast.Stoneskin = set_combine(sets.midcast['Enhancing Magic'], {})
	
	sets.midcast.Refresh = set_combine(sets.midcast['Enhancing Magic'], {})
	
	sets.midcast.Aquaveil = set_combine(sets.midcast['Enhancing Magic'], {})
	
	sets.midcast.BarElement = set_combine(sets.midcast['Enhancing Magic'], {})

    sets.midcast.Storm = set_combine(sets.midcast['Enhancing Magic'], {feet="Peda. Loafers"})

    sets.midcast.Protect = set_combine(sets.midcast['Enhancing Magic'], {ring2="Sheltered Ring"})
    sets.midcast.Protectra = sets.midcast.Protect

    sets.midcast.Shell = set_combine(sets.midcast['Enhancing Magic'], {ring2="Sheltered Ring"})
    sets.midcast.Shellra = sets.midcast.Shell


    -- Custom spell classes

	sets.midcast['Enfeebling Magic'] = {
		main="Daybreak",
		sub="Ammurapi Shield",
		ammo="Staunch Tathlum",
		head="Arbatel Bonnet +3",
		body="Arbatel Gown +2",
		hands="Arbatel Bracers +3",
		legs="Arbatel Pants +2",
		feet="Arbatel Loafers +3",
		neck="Null Loop",
		waist="Null Belt",
		left_ear="Malignance Earring",
		right_ear="Arbatel Earring +1",
		left_ring="Kishar Ring",
		right_ring="Stikini Ring",
		back="Null Shawl",
	}
	
	sets.midcast['Enfeebling Magic'].Resistant = {}
		
    sets.midcast.ElementalEnfeeble = set_combine(sets.midcast['Enfeebling Magic'], {})
    sets.midcast.ElementalEnfeeble.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant, {})
	
	sets.midcast.IntEnfeebles = set_combine(sets.midcast['Enfeebling Magic'], {})
	sets.midcast.IntEnfeebles.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant, {})

	sets.midcast.MndEnfeebles = set_combine(sets.midcast['Enfeebling Magic'], {})
	sets.midcast.MndEnfeebles.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant, {})
	
	sets.midcast.Dia = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast.Diaga = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Dia II'] = sets.midcast['Enfeebling Magic']
	sets.midcast.Bio = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Bio II'] = sets.midcast['Enfeebling Magic']
	
	sets.midcast['Divine Magic'] = set_combine(sets.midcast['Enfeebling Magic'], {main="Daybreak", sub="Ammurapi Shield"})

    sets.midcast['Dark Magic'] = {
		main="Bunzi's Rod",
		sub="Ammurapi Shield",
		ammo="Staunch Tathlum",
		head="Pixie Hairpin +1",
		body="Merlinic Jubbah",
		hands="Arbatel Bracers +3",
		legs="Arbatel Pants +2",
		feet="Arbatel Loafers +3",
		neck="Argute Stole +1",
		waist="Hachirin-no-Obi",
		left_ear="Malignance Earring",
		right_ear="Arbatel Earring +1",
		left_ring="Locus Ring",
		right_ring="Mujin Band",
		back={ name="Lugh's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','Magic Damage +10','"Mag.Atk.Bns."+10',}},
	}

    sets.midcast.Kaustra = {
		main="Bunzi's Rod",
		sub="Ammurapi Shield",
		ammo="Staunch Tathlum",
		head="Arbatel Bonnet +3",
		body="Arbatel Gown +2",
		hands="Arbatel Bracers +3",
		legs="Merlinic Shalwar",
		feet="Arbatel Loafers +3",
		neck="Argute Stole +1",
		waist="Hachirin-no-Obi",
		left_ear="Malignance Earring",
		right_ear="Arbatel Earring +1",
		left_ring="Freke Ring",
		right_ring="Archon Ring",
		back={ name="Lugh's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','Magic Damage +10','"Mag.Atk.Bns."+10',}},
	}
		
    sets.midcast.Kaustra.Resistant = {}

    sets.midcast.Drain = {
		main="Bunzi's Rod",
		sub="Ammurapi Shield",
		ammo="Staunch Tathlum",
		head="Pixie Hairpin +1",
		body="Merlinic Jubbah",
		hands="Arbatel Bracers +3",
		legs="Arbatel Pants +2",
		feet="Arbatel Loafers +3",
		neck="Argute Stole +1",
		waist="Hachirin-no-Obi",
		left_ear="Malignance Earring",
		right_ear="Arbatel Earring +1",
		left_ring="Locus Ring",
		right_ring="Mujin Band",
		back={ name="Lugh's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','Magic Damage +10','"Mag.Atk.Bns."+10',}},
	}
		
    sets.midcast.Drain.Resistant = {}

    sets.midcast.Aspir = sets.midcast.Drain
	sets.midcast.Aspir.Resistant = sets.midcast.Drain.Resistant

    sets.midcast.Stun = {
		main="Daybreak",
		sub="Ammurapi Shield",
		ammo="Incantor Stone",
		head="Arbatel Bonnet +3",
		body="Arbatel Gown +2",
		hands="Arbatel Bracers +3",
		legs="Arbatel Pants +2",
		feet="Arbatel Loafers +3",
		neck="Argute Stole +1",
		waist="Eschan Stone",
		left_ear="Malignance Earring",
		right_ear="Arbatel Earring +1",
		left_ring="Stikini Ring",
		right_ring="Stikini Ring",
		back={ name="Lugh's Cape", augments={'Mag. Acc+20 /Mag. Dmg.+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	}

    sets.midcast.Stun.Resistant = {}

    -- Elemental Magic sets are default for handling low-tier nukes.
    sets.midcast['Elemental Magic'] = {
		main="Bunzi's Rod",
		sub="Ammurapi Shield",
		ammo="Incantor Stone",
		head="Arbatel Bonnet +3",
		body="Arbatel Gown +2",
		hands="Arbatel Bracers +3",
		legs="Merlinic Shalwar",
		feet="Arbatel Loafers +3",
		neck="Argute Stole +1",
		waist="Hachirin-no-Obi",
		left_ear="Malignance Earring",
		right_ear="Arbatel Earring +1",
		left_ring="Freke Ring",
		right_ring="Mujin Band",
		back={ name="Lugh's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','Magic Damage +10','"Mag.Atk.Bns."+10',}},
	}
		
    sets.midcast['Elemental Magic'].Resistant = {}
		
    sets.midcast['Elemental Magic']['9k'] = {}
		
    sets.midcast['Elemental Magic'].Proc = {
		main="Musa",
		sub="Ajja Grip",
		ammo="Homiliary",
		head="Nyame Helm",
		body="Nyame Mail",
		hands="Nyame Gauntlets",
		legs="Nyame Flanchard",
		feet="Nyame Sollerets",
		neck="Loricate Torque +1",
		waist="Carrier's Sash",
		left_ear="Etiolation Earring",
		right_ear="Lugalbanda Earring",
		left_ring="Defending Ring",
		right_ring="Vocane Ring",
		back={ name="Lugh's Cape", augments={'Mag. Acc+20 /Mag. Dmg.+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	}
		
    sets.midcast['Elemental Magic'].OccultAcumen = {}
		
	-- Gear for Magic Burst mode.
    sets.MagicBurst = {
		main="Bunzi's Rod",
		sub="Ammurapi Shield",
		ammo="Incantor Stone",
		head="Arbatel Bonnet +3",
		body="Arbatel Gown +2",
		hands="Arbatel Bracers +3",
		legs="Merlinic Shalwar",
		feet="Arbatel Loafers +3",
		neck="Argute Stole +1",
		waist="Hachirin-no-Obi",
		left_ear="Malignance Earring",
		right_ear="Arbatel Earring +1",
		left_ring="Freke Ring",
		right_ring="Mujin Band",
		back={ name="Lugh's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','Magic Damage +10','"Mag.Atk.Bns."+10',}},
	}

    sets.HelixBurst = {
		main="Bunzi's Rod",
		sub="Ammurapi Shield",
		ammo="Incantor Stone",
		head="Arbatel Bonnet +3",
		body="Arbatel Gown +2",
		hands="Arbatel Bracers +3",
		legs="Merlinic Shalwar",
		feet="Arbatel Loafers +3",
		neck="Argute Stole +1",
		waist="Hachirin-no-Obi",
		left_ear="Malignance Earring",
		right_ear="Arbatel Earring +1",
		left_ring="Freke Ring",
		right_ring="Mujin Band",
		back={ name="Lugh's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','Magic Damage +10','"Mag.Atk.Bns."+10',}},
	}
		
    sets.ResistantHelixBurst = {}
		
    -- Custom refinements for certain nuke tiers
	sets.midcast['Elemental Magic'].HighTierNuke = {
		main="Bunzi's Rod",
		sub="Ammurapi Shield",
		ammo="Incantor Stone",
		head="Arbatel Bonnet +3",
		body="Arbatel Gown +2",
		hands="Arbatel Bracers +3",
		legs="Merlinic Shalwar",
		feet="Arbatel Loafers +3",
		neck="Argute Stole +1",
		waist="Hachirin-no-Obi",
		left_ear="Malignance Earring",
		right_ear="Arbatel Earring +1",
		left_ring="Freke Ring",
		right_ring="Mujin Band",
		back={ name="Lugh's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','Magic Damage +10','"Mag.Atk.Bns."+10',}},
	}
		
	sets.midcast['Elemental Magic'].HighTierNuke.Resistant = {}

	sets.midcast.Helix = {
		main="Bunzi's Rod",
		sub="Ammurapi Shield",
		ammo="Incantor Stone",
		head="Arbatel Bonnet +3",
		body="Arbatel Gown +2",
		hands="Arbatel Bracers +3",
		legs="Merlinic Shalwar",
		feet="Arbatel Loafers +3",
		neck="Argute Stole +1",
		waist="Hachirin-no-Obi",
		left_ear="Malignance Earring",
		right_ear="Arbatel Earring +1",
		left_ring="Freke Ring",
		right_ring="Mujin Band",
		back={ name="Lugh's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','Magic Damage +10','"Mag.Atk.Bns."+10',}},
	}
	
	sets.midcast.Helix.Resistant = {}
		
	sets.midcast.Helix.Proc = {
		main="Musa",
		sub="Ajja Grip",
		ammo="Homiliary",
		head="Nyame Helm",
		body="Nyame Mail",
		hands="Nyame Gauntlets",
		legs="Nyame Flanchard",
		feet="Nyame Sollerets",
		neck="Loricate Torque +1",
		waist="Carrier's Sash",
		left_ear="Etiolation Earring",
		right_ear="Lugalbanda Earring",
		left_ring="Defending Ring",
		right_ring="Vocane Ring",
		back={ name="Lugh's Cape", augments={'Mag. Acc+20 /Mag. Dmg.+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	}

	sets.midcast.Impact = {
	
		main="Bunzi's Rod",
		sub="Ammurapi Shield",
		ammo="Incantor Stone",
		head=empty,
		body="Twilight Cloak",
		hands="Arbatel Bracers +3",
		legs="Arbatel Pants +2",
		feet="Arbatel Loafers +3",
		neck={ name="Argute Stole +1", augments={'Path: A',}},
		waist="Hachirin-no-Obi",
		left_ear="Malignance Earring",
		right_ear={ name="Arbatel Earring +1", augments={'System: 1 ID: 1676 Val: 0','Mag. Acc.+11','Enmity-1',}},
		left_ring="Stikini Ring",
		right_ring="Stikini Ring",
		back={ name="Lugh's Cape", augments={'INT+20','Mag. Acc+20 /Mag. Dmg.+20','Magic Damage +10','"Mag.Atk.Bns."+10',}},
	}
		
    sets.midcast.Impact.OccultAcumen = set_combine(sets.midcast['Elemental Magic'].OccultAcumen, {})
		
    -- Sets to return to when not performing an action.

     -- Resting sets
    sets.resting = {}

    -- Idle sets (default idle set not needed since the other three are defined, but leaving for testing purposes)

    sets.idle = {
		main="Daybreak",
		sub="Genmei Shield",
		--main="Mpaca's Staff",
		--sub="Ajja Grip",
		ammo="Homiliary",
		head="Null Masque",
		body="Arbatel Gown +2",
		hands="Chironic Gloves",
		legs="Assiduity Pants +1",
		feet="Chironic Slippers",
		neck="Loricate Torque +1",
		waist="Carrier's Sash",
		left_ear="Etiolation Earring",
		right_ear="Lugalbanda Earring",
		left_ring="Defending Ring",
		right_ring="Vocane Ring",
		back={ name="Lugh's Cape", augments={'Mag. Acc+20 /Mag. Dmg.+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	}

    sets.idle.PDT = {}
		
	sets.idle.Hippo = set_combine(sets.idle.PDT, {})

    sets.idle.Weak = {
		main="Daybreak",
		sub="Genmei Shield",
		ammo="Homiliary",
		head="Befouled Crown",
		body="Arbatel Gown +2",
		hands="Chironic Gloves",
		legs="Assiduity Pants +1",
		feet="Chironic Slippers",
		neck="Loricate Torque +1",
		waist="Carrier's Sash",
		left_ear="Etiolation Earring",
		right_ear="Lugalbanda Earring",
		left_ring="Defending Ring",
		right_ring="Vocane Ring",
		back={ name="Lugh's Cape", augments={'Mag. Acc+20 /Mag. Dmg.+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	}
	
sets.idle.Fish = {
    range="Ebisu Fishing Rod",
    ammo="Fly Lure",
    body="Fsh. Tunica",
    hands="Fsh. Gloves",
    legs="Fisherman's Hose",
    feet="Fisherman's Boots",
    neck="Fisher's Torque",
    left_ring="Puffin Ring",
    right_ring="Noddy Ring",
}
	
    -- Defense sets

    sets.defense.PDT = {}

    sets.defense.MDT = {}
		
    sets.defense.MEVA = {}
		
    sets.Kiting = {feet="Herald's Gaiters"}
    sets.latent_refresh = {waist="Fucho-no-obi"}
	sets.latent_refresh_grip = {sub="Oneiros Grip"}
	sets.TPEat = {neck="Chrys. Torque"}
	sets.DayIdle = {}
	sets.NightIdle = {}

    -- Engaged sets

    -- Variations for TP weapon and (optional) offense/defense modes.  Code will fall back on previous
    -- sets if more refined versions aren't defined.
    -- If you create a set with both offense and defense modes, the offense mode should be first.
    -- EG: sets.engaged.Dagger.Accuracy.Evasion

    -- Normal melee group
    sets.engaged = {
		main="Mpaca's Staff",
		sub="Ajja Grip",
		ammo="Homiliary",
		head="Arbatel Bonnet +3",
		body="Arbatel Gown +2",
		hands="Arbatel Bracers +3",
		legs="Arbatel Pants +2",
		feet="Arbatel Loafers +3",
		neck={ name="Loricate Torque +1", augments={'Path: A',}},
		waist="Grunfeld Rope",
		left_ear="Telos Earring",
		right_ear={ name="Arbatel Earring +1", augments={'System: 1 ID: 1676 Val: 0','Mag. Acc.+14','Enmity-4',}},
		left_ring="Defending Ring",
		right_ring="Vocane Ring",
		back={ name="Lugh's Cape", augments={'Mag. Acc+20 /Mag. Dmg.+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	}
		
	sets.engaged.PDT = {main="Malignance Pole", sub="Oneiros Grip",ammo="Staunch Tathlum +1",
        head="Gende. Caubeen +1",neck="Loricate Torque +1",ear1="Etiolation Earring",ear2="Ethereal Earring",
        body="Vrikodara Jupon",hands="Gende. Gages +1",ring1="Defending Ring",ring2="Dark Ring",
        back="Umbra Cape",waist="Carrier's Sash",legs="Nyame Flanchard",feet=gear.chironic_refresh_feet}

    -- Buff sets: Gear that needs to be worn to actively enhance a current player buff.
    sets.buff['Ebullience'] = {head="Arbatel Bonnet +3"}
    sets.buff['Rapture'] = {head="Arbatel Bonnet +3"}
    sets.buff['Perpetuance'] = {hands="Arbatel Bracers +3"}
     sets.buff['Immanence'] = {
		main="Malignance Pole",
		sub="Ajja Grip",
		ammo="Per. Lucky Egg",
		head="Wh. Rarab Cap +1",
		body={ name="Telchine Chas.", augments={'Enh. Mag. eff. dur. +10',}},
		hands={ name="Telchine Gloves", augments={'"Cure" potency +5%',}},
		legs={ name="Telchine Braconi", augments={'Enh. Mag. eff. dur. +10',}},
		feet={ name="Telchine Pigaches", augments={'Enh. Mag. eff. dur. +8',}},
		neck={ name="Loricate Torque +1", augments={'Path: A',}},
		waist="Chaac Belt",
		left_ear="Etiolation Earring",
		right_ear="Lugalbanda Earring",
		left_ring="Defending Ring",
		right_ring="Vocane Ring",
		back="Swith Cape",
	 }
	--sets.buff['Immanence'] = {hands="Arbatel Bracers +3"}
    sets.buff['Penury'] = {legs="Arbatel Pants +2"}
    sets.buff['Parsimony'] = {legs="Arbatel Pants +2"}
    sets.buff['Celerity'] = {feet="Peda. Loafers"}
    sets.buff['Alacrity'] = {feet="Peda. Loafers"}
    sets.buff['Klimaform'] = {feet="Arbatel Loafers +3"}
	
	sets.HPDown = {head="Pixie Hairpin +1",ear1="Mendicant's Earring",ear2="Evans Earring",
		body="Zendik Robe",hands="Hieros Mittens",ring1="Mephitas's Ring +1",ring2="Mephitas's Ring",
		back="Swith Cape +1",waist="Carrier's Sash",legs="Shedir Seraweels",feet=""}
		
    sets.HPCure = {main="Daybreak",sub="Sors Shield",range=empty,ammo="Hasty Pinion +1",
        head="Gende. Caubeen +1",neck="Unmoving Collar +1",ear1="Gifted Earring",ear2="Mendi. Earring",
        body="Kaykaus Bliaut",hands="Kaykaus Cuffs",ring1="Gelatinous Ring +1",ring2="Meridian Ring",
        back="Moonlight Cape",waist="Luminary Sash",legs="Carmine Cuisses +1",feet="Kaykaus Boots"}
	
	sets.buff.Doom = set_combine(sets.buff.Doom, {})
	sets.buff['Light Arts'] = {} --legs="Academic's Pants +3"
	sets.buff['Dark Arts'] = {} --body="Academic's Gown +3"

    sets.buff.Sublimation = {waist="Embla Sash"}
    sets.buff.DTSublimation = {waist="Embla Sash"}
	
	-- Weapons sets
	sets.weapons.Akademos = {main="Akademos",sub="Enki Strap"}
	sets.weapons.Khatvanga = {main="Khatvanga",sub="Bloodrain Strap"}
	sets.weapons.Musa = {main="Musa",sub="Oneiros Grip"}
end

-- Select default macro book on initial load or subjob change.
-- Default macro set/book
function select_default_macro_book()
	if player.sub_job == 'RDM' then
		set_macro_page(1, 5)
	elseif player.sub_job == 'BLM' then
		set_macro_page(1, 5)
	elseif player.sub_job == 'WHM' then
		set_macro_page(1, 5)
	else
		set_macro_page(1, 5)
	end
end

function user_job_lockstyle()
	windower.chat.input('/lockstyleset 02')
end