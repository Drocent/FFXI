-------------------------------------------------------------------------------------------------------------------
-- Setup functions for this job.  Generally should not be modified.
-------------------------------------------------------------------------------------------------------------------

-- Initialization function for this job file.
function get_sets()
    mote_include_version = 2

    -- Load and initialize the include file.
    include('Mote-Include.lua')
end

-- Setup vars that are user-independent.  state.Buff vars initialized here will automatically be tracked.
function job_setup()
    state.Buff.Sentinel = buffactive.sentinel or false
    state.Buff.Cover = buffactive.cover or false
    state.Buff.Doom = buffactive.Doom or false
end

-------------------------------------------------------------------------------------------------------------------
-- User setup functions for this job.  Recommend that these be overridden in a sidecar file.
-------------------------------------------------------------------------------------------------------------------

-- Setup vars that are user-dependent.  Can override this function in a sidecar file.
function user_setup()
    state.OffenseMode:options('Normal', 'HybridTank','GreatSword', 'Shield', 'Ochain', 'MagicEvasion', 'Resist', 'ResistCharm')
    state.HybridMode:options('Normal', 'PDT', 'Reraise')
    state.WeaponskillMode:options('Normal', 'Acc')
    state.CastingMode:options('Normal', 'Resistant')
    state.PhysicalDefenseMode:options('PDT', 'HP', 'Reraise','Doom','TH','Annul')
    state.MagicalDefenseMode:options('MDT', 'Reraise', 'Resist', 'ResistCharm','ResistTerror','ResistStun','ResistSlow','Test')
	state.IdleMode:options('Idle','Phalanx','Pulling','Duban','Lilith','DT','MagicEvasion','Annul')
    
    state.ExtraDefenseMode = M{['description']='Extra Defense Mode', 'None', 'MP', 'Knockback', 'MP_Knockback'}
    state.EquipShield = M(false, 'Equip Shield w/Defense')

    update_defense_mode()
    	
    send_command('bind ^f11 gs c cycle MagicalDefenseMode')
    send_command('bind !f11 gs c cycle ExtraDefenseMode')
    send_command('bind @f10 gs c toggle EquipShield')
    send_command('bind @f11 gs c toggle EquipShield')
	
	send_command('bind ^w gs c cycle weaponlock')
	
	send_command('bind ^- input /ma "Cure IV" <a10>')
	send_command('bind ^= input /ma "Cure IV" <a20>')	
	--send_command('bind ^= input /ma "Cure IV" <a10>')	
	--send_command('bind ^- input /ma "Divine Emblem" <me>')
	--send_command('bind ^= input /ma "Holy Circle" <me>')
	
	send_command('bind ^` input /ja "Fealty" <me>') --Alt` Fealty
	send_command('bind !` input /ja "Chivalry" <me>') -- Alt-` Chivalry
	
	windower.send_command('bind !q input //send Europea /follow Dekar') --FOLLOW COMMAND FOLLOW COMMAND FOLLOW COMMAND FOLLOW COMMAND FOLLOW COMMAND 
	windower.send_command('bind !a input //send Zinthor /follow Dekar') --FOLLOW COMMAND FOLLOW COMMAND FOLLOW COMMAND FOLLOW COMMAND FOLLOW COMMAND
	windower.send_command('lua l gearinfo')
	windower.send_command('lua l equipviewer')
	windower.send_command('lua l partybuffs')
	windower.send_command('lua l Superwarp')
	windower.send_command('lua l DParty')
	windower.send_command('lua l Skillchains')	
	
	
	send_command('bind f1 input //send Europea //gs c WMAG R5')
	send_command('bind f2 input //send Europea //gs c WMAG AC4')
	send_command('bind f3 input //send Europea //gs c WMAG PHA')
	send_command('bind f4 input //send Europea //gs c WMAG STN')
	
	--send_command('bind ^[ input //send Europea //gs c WMAG ERS')
    --send_command('bind ^] input //send Europea //gs c WMAG PAR')
	--send_command('bind ^\\\\ input //send Europea //gs c WMAG SIL')
	
	--send_command('bind ^[ input /ws "Torcleaver" <t>')
    --send_command('bind ^] input /ws "Resolution" <t>')
	--send_command('bind ^\\\\ input /ws "Atonement" <t>')	

	send_command('bind ^[ input //send Europea /ma "Paralyna" Dekar')
    send_command('bind ^] input //send Europea /ma "Silena" Dekar')	
	send_command('bind ^\\ input //send Europea /ma "Aurorastorm" Dekar')
	send_command('bind ^; input //send Europea /ma Erase Dekar')
	send_command('bind ^\' input //send Europea /ma XXXX Dekar')
	
	--send_command('bind ^[ input //send Europea /ma "Cure IV" Dekar')
    --send_command('bind ^] input //send Europea /ma "Refresh" Dekar')
	--send_command('bind ^\\\\ input //send Europea /ma "Aurorastorm II" Dekar')

    select_default_macro_book()
end

function user_unload()
    send_command('unbind ^f11')
    send_command('unbind !f11')
    send_command('unbind @f10')
    send_command('unbind @f11')
	send_command('unbind ^-')
	send_command('unbind ^=')
	send_command('unbind ^[')
    send_command('unbind ^]')	
	send_command('unbind ^\\\\')
	send_command('unbind ^;')
	send_command('unbind ^\'')
	send_command('unbind ^`')
	send_command('unbind !`')
	send_command('unbind ^w')
end


-- Define sets and vars used by this job file.
function init_gear_sets()
    --------------------------------------
    -- Precast sets
    --------------------------------------
    
    -- Precast sets to enhance JAs
    sets.precast.JA['Invincible'] = {
		ammo="Sapience Orb",
		head={ name="Loess Barbuta +1", augments={'Path: A',}},
		body={ name="Souv. Cuirass +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		legs="Caballarius Breeches +3",
		feet="Chevalier's Sabatons +3",
		neck="Moonbeam Necklace",
		waist="Creed Baudrier",
		left_ear="Friomisi Earring",
		right_ear="Cryptic Earring",
		left_ring="Defending Ring",
		right_ring="Petrov Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}},	
	}
	
	sets.precast.JA['Vallation'] = {
		ammo="Sapience Orb",
		head={ name="Loess Barbuta +1", augments={'Path: A',}},
		body={ name="Souv. Cuirass +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		legs="Caballarius Breeches +3",
		feet="Chevalier's Sabatons +3",
		neck="Moonbeam Necklace",
		waist="Creed Baudrier",
		left_ear="Friomisi Earring",
		right_ear="Cryptic Earring",
		left_ring="Defending Ring",
		right_ring="Petrov Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}},	
	}
	
	sets.precast.JA['Valiance'] = {
		ammo="Sapience Orb",
		head={ name="Loess Barbuta +1", augments={'Path: A',}},
		body={ name="Souv. Cuirass +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		legs="Caballarius Breeches +3",
		feet="Chevalier's Sabatons +3",
		neck="Moonbeam Necklace",
		waist="Creed Baudrier",
		left_ear="Friomisi Earring",
		right_ear="Cryptic Earring",
		left_ring="Defending Ring",
		right_ring="Petrov Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}},	
	}
	
    sets.precast.JA['Holy Circle'] = {feet="Reverence Leggings +3"}
	
    sets.precast.JA['Shield Bash'] = {
		ammo="Sapience Orb",
		head={ name="Loess Barbuta +1", augments={'Path: A',}},
		body={ name="Cab. Surcoat +3", augments={'Enhances "Fealty" effect',}},
		hands={ name="Cab. Gauntlets +3", augments={'Enhances "Chivalry" effect',}},
		legs={ name="Cab. Breeches +3", augments={'Enhances "Invincible" effect',}},
		feet={ name="Cab. Leggings +3", augments={'Enhances "Guardian" effect',}},
		neck={ name="Unmoving Collar +1", augments={'Path: A',}},
		waist="Creed Baudrier",
		right_ear="Etiolation Earring",
		left_ear="Cryptic Earring",
		left_ring="Defending Ring",
		right_ring="Petrov Ring",
		back="Moonlight Cape",
	}
	
    sets.precast.JA['Sentinel'] = {
		ammo="Sapience Orb",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body={ name="Souv. Cuirass +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		legs={ name="Souv. Diechlings +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		feet="Caballarius Leggings +3",
		neck="Moonbeam Necklace",
		waist="Creed Baudrier",
		left_ear="Friomisi Earring",
		right_ear="Cryptic Earring",
		left_ring="Defending Ring",
		right_ring="Petrov Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}},	
	}
	
    sets.precast.JA['Rampart'] = {		
		ammo="Sapience Orb",
		head="Caballarius Coronet +3",
		body={ name="Souv. Cuirass +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		legs={ name="Souv. Diechlings +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		feet={ name="Souveran Schuhs +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		neck="Moonbeam Necklace",
		waist="Creed Baudrier",
		left_ear="Friomisi Earring",
		right_ear="Cryptic Earring",
		left_ring="Defending Ring",
		right_ring="Petrov Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}},	
	}
	
	sets.precast.JA['Palisade'] = {		
		ammo="Sapience Orb",
		head="Caballarius Coronet +3",
		body={ name="Souv. Cuirass +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		legs={ name="Souv. Diechlings +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		feet={ name="Souveran Schuhs +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		neck="Moonbeam Necklace",
		waist="Creed Baudrier",
		left_ear="Friomisi Earring",
		right_ear="Cryptic Earring",
		left_ring="Defending Ring",
		right_ring="Petrov Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}},	
	}
	
    sets.precast.JA['Fealty'] = {body="Caballarius Surcoat +3"}	
    sets.precast.JA['Divine Emblem'] = {feet="Chevalier's Sabatons +3"}	
    sets.precast.JA['Cover'] = {head="Reverence Coronet +2", body="Caballarius Surcoat +3",}

    -- add mnd for Chivalry
    sets.precast.JA['Chivalry'] = {hands="Caballarius Gauntlets +3"}
    

    -- Waltz set (chr and vit)
    sets.precast.Waltz = {}        
    -- Don't need any special gear for Healing Waltz.
    sets.precast.Waltz['Healing Waltz'] = {}    
    sets.precast.Step = {}
    sets.precast.Flourish1 = {}

    -- Fast cast sets for spells
    
    sets.precast.FC = {
		ammo="Sapience Orb", --2 FC
		head={ name="Carmine Mask", augments={'Accuracy+15','Mag. Acc.+10','"Fast Cast"+3',}}, --12 FC
		body="Reverence Surcoat +3", --10
		hands="Leyline Gloves", --8 FC
		legs={ name="Souv. Diechlings +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}}, -- NONE
		feet="Chevalier's Sabatons +3", --13 FC
		neck="Voltsurge Torque", --4 FC
		waist="Plat. Mog. Belt", --NONE		
		right_ear="Etiolation Earring", --1 FC
		left_ear={ name="Nourish. Earring +1", augments={'Path: A',}}, --4 CCT
		left_ring="Kishar Ring", --4 FC
		right_ring="Prolix Ring", --2 FC
		back={ name="Rudianos's Mantle", augments={'HP+60','HP+20','"Fast Cast"+10','Phys. dmg. taken-10%',}}, --10 FC
	} 			--66 FC + 4 CCT (70 FC for Cures)

    sets.precast.FC['Enhancing Magic'] = set_combine(sets.precast.FC, {waist="Siegel Sash"}) -- 52 FC + 8 Enhancing FC (60 FC for Enhancing magic)

       
    -- Weaponskill sets
    -- Default set for any weaponskill that isn't any more specifically defined
    sets.precast.WS = {
		ammo="Oshasha's Treatise",
		head="Nyame Helm",
		body="Nyame Mail",
		hands="Nyame Gauntlets",
		legs="Nyame Flanchard",
		feet="Nyame Sollerets",
		neck="Fotia Gorget",
		waist="Fotia Belt",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Brutal Earring",
		right_ring="Moonlight Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}},
}

    sets.precast.WS.Acc = {}

    -- Specific weaponskill sets.  Uses the base set if an appropriate WSMod version isn't found.
	
    sets.precast.WS['Requiescat'] = {
		ammo={ name="Coiste Bodhar", augments={'Path: A',}},
		head={ name="Sakpata's Helm", augments={'Path: A',}},
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands={ name="Sakpata's Gauntlets", augments={'Path: A',}},
		legs={ name="Sakpata's Cuisses", augments={'Path: A',}},
		feet={ name="Sakpata's Leggings", augments={'Path: A',}},
		neck="Fotia Gorget",
		waist="Fotia Belt",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Brutal Earring",
		left_ring="Regal Ring",
		right_ring={ name="Metamor. Ring +1", augments={'Path: A',}},
		back={ name="Rudianos's Mantle", augments={'HP+60','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Damage taken-5%',}},
	}
	
	
    sets.precast.WS['Requiescat'].Acc = set_combine(sets.precast.WS.Acc, {ring1=""})

    sets.precast.WS['Chant du Cygne'] = {
		ammo={ name="Coiste Bodhar", augments={'Path: A',}},
		head={ name="Valorous Mask", augments={'"Dbl.Atk."+3','Crit.hit rate+5','Weapon skill damage +6%','Accuracy+13 Attack+13','Mag. Acc.+17 "Mag.Atk.Bns."+17',}},
		body="Hjarrandi Breast.",
		hands="Flam. Manopolas +2",
		legs={ name="Sakpata's Cuisses", augments={'Path: A',}},
		feet={ name="Sakpata's Leggings", augments={'Path: A',}},
		neck="Fotia Gorget",
		waist="Fotia Belt",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Brutal Earring",
		left_ring="Begrudging Ring",
		right_ring="Hetairoi Ring",
		back={ name="Rudianos's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','DEX+10','Crit.hit rate+10','Parrying rate+5%',}},
	}

    sets.precast.WS['Chant du Cygne'].Acc = set_combine(sets.precast.WS.Acc, {})

    sets.precast.WS['Sanguine Blade'] = {
		ammo="Ghastly Tathlum +1",
		head="Pixie Hairpin +1",
		body="Nyame Mail",
		hands="Nyame Gauntlets",
		legs="Nyame Flanchard",
		feet="Nyame Sollerets",
		neck="Sibyl Scarf",
		--waist="Hachirin-no-Obi",
		waist="Orpheus's Sash",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Friomisi Earring",
		left_ring="Metamorph Ring +1",
		right_ring="Archon Ring",
		back={ name="Rudianos's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}},
	}
	
	sets.precast.WS['Cataclysm'] = {
		ammo="Ghastly Tathlum +1",
		head="Pixie Hairpin +1",
		body="Nyame Mail",
		hands="Nyame Gauntlets",
		legs="Nyame Flanchard",
		feet="Nyame Sollerets",
		neck="Sibyl Scarf",
		--waist="Hachirin-no-Obi",
		waist="Orpheus's Sash",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Friomisi Earring",
		left_ring="Metamorph Ring +1",
		right_ring="Archon Ring",
		back={ name="Rudianos's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}},
	}
	
	sets.precast.WS['Aeolian Edge'] = {
		ammo={ name="Ghastly Tathlum +1", augments={'Path: A',}},
		head={ name="Nyame Helm", augments={'Path: B',}},
		body={ name="Nyame Mail", augments={'Path: B',}},
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Sibyl Scarf",
		--waist="Hachirin-no-Obi",
		waist="Orpheus's Sash",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Friomisi Earring",
		left_ring="Regal Ring",
		right_ring={ name="Metamor. Ring +1", augments={'Path: A',}},
		back={ name="Rudianos's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}},
	}
    
    sets.precast.WS['Atonement'] = {
		ammo="Staunch Tathlum +1",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body={ name="Souv. Cuirass +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		legs={ name="Souv. Diechlings +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		feet={ name="Souveran Schuhs +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		neck="Fotia Gorget",
		waist="Fotia Belt",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Cryptic Earring",
		left_ring="Defending Ring",
		right_ring="Petrov Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Phys. dmg. taken-10%',}},
	}
	
	sets.precast.WS['Savage Blade'] = {
		ammo="Coiste Bodhar",
		head={ name="Nyame Helm", augments={'Path: B',}},
		body={ name="Nyame Mail", augments={'Path: B',}},
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Rep. Plat. Medal",
		waist="Sailfi Belt +1",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Ishvara Earring",
		left_ring="Regal Ring",
		right_ring="Metamorph Ring +1",
		back={ name="Rudianos's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}},
	}
	
	sets.precast.WS['Knights of Round'] = {
		ammo="Coiste Bodhar",
		head={ name="Nyame Helm", augments={'Path: B',}},
		body={ name="Nyame Mail", augments={'Path: B',}},
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Rep. Plat. Medal",
		waist="Sailfi Belt +1",
		left_ear="Telos Earring",
		right_ear="Ishvara Earring",
		left_ring="Regal Ring",
		right_ring="Metamorph Ring +1",
		back={ name="Rudianos's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}},
	}
	
	sets.precast.WS['Scourge'] = {
		ammo="Oshasha's Treatise",
		head={ name="Nyame Helm", augments={'Path: B',}},
		body={ name="Nyame Mail", augments={'Path: B',}},
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Rep. Plat. Medal",
		waist="Sailfi Belt +1",
		left_ear="Telos Earring",
		right_ear="Ishvara Earring",
		left_ring="Regal Ring",
		right_ring="Metamorph Ring +1",
		back={ name="Rudianos's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}},
	}
	
	sets.precast.WS['Torcleaver'] = {
		ammo="Oshasha's Treatise",
		head={ name="Nyame Helm", augments={'Path: B',}},
		body={ name="Nyame Mail", augments={'Path: B',}},
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Rep. Plat. Medal",
		waist="Sailfi Belt +1",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Ishvara Earring",
		left_ring="Regal Ring",
		right_ring="Gelatinous Ring +1",
		back={ name="Rudianos's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}},
	}
	
	sets.precast.WS['Resolution'] = {
		ammo="Coiste Bodhar",
		head="Sakpata's Helm",
		body="Sakpata's Plate",
		hands="Sakpata's Gauntlets",
		legs="Sakpata's Cuisses",
		feet="Sakpata's Leggings",
		neck="Fotia Gorget",
		waist="Fotia Belt",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Brutal Earring",
		left_ring="Regal Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Damage taken-5%',}},
	}
	
	sets.precast.WS['Shockwave'] = {
		ammo="Pemphredo Tathlum",
		head={ name="Nyame Helm", augments={'Path: B',}},
		body={ name="Nyame Mail", augments={'Path: B',}},
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Sanctity Necklace",
		waist="Eschan Stone",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Digni. Earring",
		left_ring="Moonlight Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}},
	}
	
	sets.precast.WS['Black Halo'] = {
		ammo="Coiste Bodhar",
		head={ name="Nyame Helm", augments={'Path: B',}},
		body={ name="Nyame Mail", augments={'Path: B',}},
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Rep. Plat. Medal",
		waist="Sailfi Belt +1",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Ishvara Earring",
		left_ring="Rufescent Ring",
		right_ring="Metamorph Ring +1",
		back={ name="Rudianos's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}},
	}
	
	sets.precast.WS['Judgment'] = {
		ammo="Coiste Bodhar",
		head={ name="Nyame Helm", augments={'Path: B',}},
		body={ name="Nyame Mail", augments={'Path: B',}},
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Rep. Plat. Medal",
		waist="Sailfi Belt +1",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Ishvara Earring",
		left_ring="Rufescent Ring",
		right_ring="Metamorph Ring +1",
		back={ name="Rudianos's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}},
	}
	
	sets.precast.WS['Hexa Strike'] = {
		ammo="Coiste Bodhar",
		head={ name="Valorous Mask", augments={'"Dbl.Atk."+3','Crit.hit rate+5','Weapon skill damage +6%','Accuracy+13 Attack+13','Mag. Acc.+17 "Mag.Atk.Bns."+17',}},
		body="Hjarrandi Breast.",
		hands="Flam. Manopolas +2",
		legs="Sakpata's Cuisses",
		feet="Sakpata's Leggings",
		neck="Fotia Gorget",
		waist="Fotia Belt",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Brutal Earring",
		left_ring="Begrudging Ring",
		right_ring="Metamorph Ring +1",
		back={ name="Rudianos's Mantle", augments={'HP+60','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Damage taken-5%',}},
	}
	
	sets.precast.WS['Realmrazer'] = {
		ammo="Coiste Bodhar",
		head={ name="Nyame Helm", augments={'Path: B',}},
		body={ name="Nyame Mail", augments={'Path: B',}},
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Fotia Gorget",
		waist="Fotia Belt",
		left_ear={ name="Moonshade Earring", augments={'Accuracy+4','TP Bonus +250',}},
		right_ear="Ishvara Earring",
		left_ring="Rufescent Ring",
		right_ring="Metamorph Ring +1",
		back={ name="Rudianos's Mantle", augments={'STR+20','Accuracy+20 Attack+20','STR+10','Weapon skill damage +10%',}},
	}
	
	
    
    --------------------------------------
    -- Midcast sets
    --------------------------------------

    sets.midcast.FastRecast = {
        head="Reverence Coronet +1",
    }	
        
    sets.midcast.Enmity = {
		ammo="Sapience Orb",
		head={ name="Loess Barbuta +1", augments={'Path: A',}},
		body={ name="Souv. Cuirass +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		legs={ name="Souv. Diechlings +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		feet="Chev. Sabatons +3",
		neck={ name="Unmoving Collar +1", augments={'Path: A',}},
		waist="Creed Baudrier",
		left_ear="Friomisi Earring",
		right_ear="Cryptic Earring",
		left_ring="Apeile Ring",
		right_ring="Apeile Ring +1",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}},
	}

	sets.midcast.Provoke = set_combine(sets.midcast.Enmity, {})

	sets.midcast.SIRD = {
		ammo="Staunch Tathlum +1", --11
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}}, --20
		body="Chevalier's Cuirass +3", --20
		hands="Regal Gauntlets", --10
		legs={ name="Founder's Hose", augments={'MND+10','Mag. Acc.+15','Attack+15','Breath dmg. taken -5%',}}, --30
		feet={ name="Odyssean Greaves", augments={'Attack+14','"Fast Cast"+5','VIT+8','Accuracy+5',}}, --20
		neck="Moonbeam necklace", --10
		left_ear={ name="Nourish. Earring +1", augments={'Path: A',}}, --1
	} --122% SIRD with CAPPED MERITS!!
	
	 sets.midcast.Cure = {
		ammo="Staunch Tathlum +1",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands={ name="Macabre Gaunt. +1", augments={'Path: A',}},
		legs={ name="Founder's Hose", augments={'MND+10','Mag. Acc.+15','Attack+15','Breath dmg. taken -5%',}},
		feet={ name="Odyssean Greaves", augments={'Accuracy+16','"Cure" potency +5%','Attack+9',}},
		neck="Sacro Gorget",
		waist="Audumbla Sash",
		left_ear={ name="Nourish. Earring +1", augments={'Path: A',}},
		right_ear="Chevalier's Earring +1",
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back="Moonlight Cape",
	}

    sets.midcast.Flash = set_combine(sets.midcast.SIRD, {
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body="Reverence Surcoat +3",
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		feet="Chevalier's Sabatons +3",
		waist="Audumbla Sash",
		right_ear="Magnetic Earring",
		left_ear={ name="Nourish. Earring +1", augments={'Path: A',}},
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','HP+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	})
	
	sets.midcast.Foil = set_combine(sets.midcast.SIRD, {
		-- head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		-- body="Chevalier's Cuirass +3",
		-- hands="Souveran handschuhs +1",
		-- feet="Chevalier's Sabatons +3",
		-- waist="Audumbla Sash",
		-- right_ear="Etiolation Earring",
		-- left_ear="Cryptic Earring",
		-- left_ring="Defending Ring",
		-- right_ring="Moonlight Ring",
		-- back={ name="Rudianos's Mantle", augments={'HP+60','HP+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},	
		ammo="Staunch Tathlum +1",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body="Rev. Surcoat +3",
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		legs={ name="Founder's Hose", augments={'MND+10','Mag. Acc.+15','Attack+15','Breath dmg. taken -5%',}},
		feet="Chev. Sabatons +3",
		neck="Moonbeam Necklace",   --(FOR DYNAMIS JEUNO ONLY)
		waist="Audumbla Sash",
		left_ear={ name="Nourish. Earring +1", augments={'Path: A',}},
		right_ear="Magnetic Earring",
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','HP+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	})
	
	sets.midcast.Raise = set_combine(sets.midcast.SIRD, {
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body="Reverence Surcoat +3",
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		waist="Sailfi belt +1",
		right_ear="Etiolation Earring",
		left_ear={ name="Nourish. Earring +1", augments={'Path: A',}},
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','HP+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	})
	
	 sets.midcast['Holy II']  = {
		ammo="Pemphredo Tathlum",
		head="Nyame Helm",
		body="Nyame Mail",
		hands="Nyame Gauntlets",
		legs="Nyame Flanchard",
		feet="Nyame Sollerets",
		neck="Sanctity Necklace",
		waist="Eschan Stone",
		left_ear="Friomisi Earring",
		right_ear="Hecate's Earring",
		left_ring="Stikini Ring +1",
		right_ring="Stikini Ring +1",
		back="Moonlight Cape",
	}
	
	 sets.midcast['Holy']  = {
		ammo="Pemphredo Tathlum",
		head="Nyame Helm",
		body="Nyame Mail",
		hands="Nyame Gauntlets",
		legs="Nyame Flanchard",
		feet="Nyame Sollerets",
		neck="Sanctity Necklace",
		waist="Eschan Stone",
		left_ear="Friomisi Earring",
		right_ear="Hecate's Earring",
		left_ring="Stikini Ring +1",
		right_ring="Stikini Ring +1",
		back="Moonlight Cape",
	}
    
    sets.midcast.Stun = sets.midcast.Flash
	
	sets.midcast['Banishga'] = set_combine(sets.midcast.SIRD, {
		ammo="Staunch Tathlum +1",
		hands="Chevalier's Gauntlets +3",
		legs={ name="Founder's Hose", augments={'MND+10','Mag. Acc.+15','Attack+15','Breath dmg. taken -5%',}},
		feet="Sakpata's Leggings",
		neck="Moonbeam Necklace",
		waist="Tempus Fugit",
		left_ear={ name="Nourish. Earring +1", augments={'Path: A',}},
		right_ear="Etiolation Earring",
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','HP+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},	
	})
	
	sets.midcast.Banish = {
		ammo="Staunch Tathlum +1",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body="Chev. Cuirass +3",
		hands="Chev. Gauntlets +3",
		legs="Chev. Cuisses +3",
		feet={ name="Odyssean Greaves", augments={'Attack+14','"Fast Cast"+5','VIT+8','Accuracy+5',}},
		neck="Moonbeam Necklace",
		waist="Audumbla Sash",
		left_ear="Digni. Earring",
		right_ear={ name="Nourish. Earring +1", augments={'Path: A',}},
		left_ring="Defending Ring",
		right_ring="Stikini Ring +1",
		back="Moonlight Cape",	
	}	
	
	
    
   ---------------------------------------------------------------------------------------------------------------BLU SPELLS
		
	sets.midcast['Sheep Song'] = {
		ammo="Staunch Tathlum +1",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body={ name="Souv. Cuirass +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		hands="Chevalier's Gauntlets +3",
		legs={ name="Founder's Hose", augments={'MND+10','Mag. Acc.+15','Attack+15','Breath dmg. taken -5%',}},
		feet={ name="Odyssean Greaves", augments={'Attack+14','"Fast Cast"+5','VIT+8','Accuracy+5',}},
		neck="Moonbeam Necklace",
		waist="Sailfi Belt +1",
		left_ear="Friomisi Earring",
		right_ear={ name="Nourish. Earring +1", augments={'Path: A',}},
		left_ring="Defending Ring",
		right_ring="Petrov Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Phys. dmg. taken-10%',}},
	}		

	sets.midcast['Geist Wall'] = sets.midcast['Sheep Song']	
	
	sets.midcast['Jettatura'] = sets.midcast['Sheep Song']	
	
	sets.midcast['Blank Gaze'] = sets.midcast['Sheep Song']	
	
	sets.midcast['Frightful Roar'] = {
		ammo="Staunch Tathlum +1",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body="Chev. Cuirass +3",
		hands="Chev. Gauntlets +3",
		legs="Chev. Cuisses +3",
		feet={ name="Odyssean Greaves", augments={'Attack+14','"Fast Cast"+5','VIT+8','Accuracy+5',}},
		neck="Moonbeam Necklace",
		waist="Audumbla Sash",
		left_ear="Digni. Earring",
		right_ear={ name="Nourish. Earring +1", augments={'Path: A',}},
		left_ring="Defending Ring",
		right_ring="Stikini Ring +1",
		back="Moonlight Cape",
	}
	
	sets.midcast['Cocoon'] = {
		ammo="Staunch Tathlum +1",
		head="Chev. Armet +3",
		body="Chev. Cuirass +3",
		hands="Chev. Gauntlets +3",
		legs={ name="Founder's Hose", augments={'MND+10','Mag. Acc.+15','Attack+15','Breath dmg. taken -5%',}},
		feet={ name="Odyssean Greaves", augments={'Attack+14','"Fast Cast"+5','VIT+8','Accuracy+5',}},
		neck="Moonbeam Necklace",
		waist="Audumbla Sash",
		left_ear="Cryptic Earring",
		right_ear="Etiolation Earring",
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back="Moonlight Cape",
	}
	
	---------------------------------------------------------------------------------------------------------------BLU SPELLS
		

    sets.midcast['Enhancing Magic'] = {
		ammo="Staunch Tathlum +1",
		head="Chev. Armet +3",
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands="Regal Gauntlets",
		legs={ name="Founder's Hose", augments={'MND+10','Mag. Acc.+15','Attack+15','Breath dmg. taken -5%',}},
		feet={ name="Odyssean Greaves", augments={'Attack+14','"Fast Cast"+5','VIT+8','Accuracy+5',}},
		neck="Moonbeam Necklace",
		waist="Audumbla Sash",
		left_ear="Andoaa Earring",
		right_ear={ name="Nourish. Earring +1", augments={'Path: A',}},
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back="Moonlight Cape",
	}
	
	sets.midcast['Regen II'] = {
		ammo="Staunch Tathlum +1",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body="Shabti Cuirass",
		hands="Regal Gauntlets",
		legs={ name="Founder's Hose", augments={'MND+10','Mag. Acc.+15','Attack+15','Breath dmg. taken -5%',}},
		feet="Sakpata's Leggings",
		neck="Sacro Gorget",
		waist="Audumbla Sash",
		left_ear="Magnetic Earring",
		right_ear={ name="Nourish. Earring +1", augments={'Path: A',}},
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back="Moonlight Cape",	
	}
	
	sets.midcast['Crusade'] = sets.midcast['Enhancing Magic']

	sets.midcast.Stoneskin = {
		ammo="Staunch Tathlum +1",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands="Sakpata's Gauntlets",
		legs={ name="Founder's Hose", augments={'MND+10','Mag. Acc.+15','Attack+15','Breath dmg. taken -5%',}},
		feet={ name="Odyssean Greaves", augments={'Attack+14','"Fast Cast"+5','VIT+8','Accuracy+5',}},
		neck="Moonbeam Necklace",
		waist="Siegel Sash",
		left_ear="Earthcry Earring",
		right_ear={ name="Nourish. Earring +1", augments={'Path: A',}},
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back="Moonlight Cape",
	}	
			
	sets.midcast.Reprisal = {
		ammo="Staunch Tathlum +1",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body="Rev. Surcoat +3",
		hands="Regal Gauntlets",
		legs={ name="Founder's Hose", augments={'MND+10','Mag. Acc.+15','Attack+15','Breath dmg. taken -5%',}},
		feet={ name="Odyssean Greaves", augments={'Attack+14','"Fast Cast"+5','VIT+8','Accuracy+5',}},
		neck={ name="Loricate Torque +1", augments={'Path: A',}},
		waist="Tempus Fugit",
		left_ear="Cryptic Earring",
		right_ear="Etiolation Earring",
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','HP+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
	}
    
    sets.midcast.Protect = {
		ammo="Staunch Tathlum +1",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands="Regal Gauntlets",
		legs={ name="Founder's Hose", augments={'MND+10','Mag. Acc.+15','Attack+15','Breath dmg. taken -5%',}},
		feet={ name="Sakpata's Leggings", augments={'Path: A',}},
		neck="Moonbeam Necklace",
		waist="Audumbla Sash",
		left_ear={ name="Nourish. Earring +1", augments={'Path: A',}},
		right_ear="Etiolation Earring",
		left_ring="Defending Ring",
		right_ring="Sheltered Ring",
		back="Moonlight Cape",
	}		

	sets.midcast['Shell'] = sets.midcast['Protect']

	
	sets.midcast['Poisona'] = {
		ammo="Staunch Tathlum +1",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands={ name="Sakpata's Gauntlets", augments={'Path: A',}},
		legs={ name="Founder's Hose", augments={'MND+10','Mag. Acc.+15','Attack+15','Breath dmg. taken -5%',}},
		feet={ name="Odyssean Greaves", augments={'Attack+14','"Fast Cast"+5','VIT+8','Accuracy+5',}},
		neck="Voltsurge Torque",
		waist="Audumbla Sash",
		left_ear="Magnetic Earring",
		right_ear="Etiolation Earring",
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back="Moonlight Cape",
	}

	sets.midcast['Paralyna'] = sets.midcast['Poisona']	
	sets.midcast['Blindna'] = sets.midcast['Poisona']		
	sets.midcast['Silena'] = sets.midcast['Poisona']		
	sets.midcast['Stona'] = sets.midcast['Poisona']		
	sets.midcast['Viruna'] = sets.midcast['Poisona']	
	sets.midcast['Cursna'] = sets.midcast['Poisona']		
	sets.midcast['Erase'] = sets.midcast['Poisona']
	
	sets.midcast.Enlight = {
		ammo="Staunch Tathlum +1",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body="Rev. Surcoat +3",
		hands="Regal Gauntlets",
		legs={ name="Founder's Hose", augments={'MND+10','Mag. Acc.+15','Attack+15','Breath dmg. taken -5%',}},
		feet={ name="Sakpata's Leggings", augments={'Path: A',}},
		neck="Moonbeam Necklace",
		waist="Audumbla Sash",
		left_ear={ name="Nourish. Earring +1", augments={'Path: A',}},
		right_ear="Etiolation Earring",
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Damage taken-5%',}},
	}

    sets.midcast["Enlight II"] = sets.midcast.Enlight
	
	sets.midcast.Phalanx = {
		--main="Sakpata's Sword",
		--sub={ name="Priwen", augments={'HP+50','Mag. Evasion+50','Damage Taken -3%',}},
		ammo="Staunch Tathlum +1",
		head={ name="Valorous Mask", augments={'"Avatar perpetuation cost" -1','"Mag.Atk.Bns."+4','Phalanx +5',}},
		body={ name="Odyss. Chestplate", augments={'VIT+5','"Dual Wield"+1','Phalanx +5',}},
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		legs="Sakpata's Cuisses",
		feet={ name="Souveran Schuhs +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		neck="Loricate Torque +1",
		waist="Audumbla Sash",
		right_ear="Etiolation Earring",
		left_ear="Cryptic Earring",
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back={ name="Weard Mantle", augments={'VIT+2','Phalanx +5',}},
	} --37 Phalanx received
    
    --------------------------------------
    -- Idle/resting/defense/etc sets
    --------------------------------------

    sets.Reraise = {
		head="Twilight Helm",
		body="Twilight Mail",
	}
    
    sets.resting = {
		ammo="Homiliary",		
		waist="Fucho-no-Obi",
		left_ring="Stikini Ring +1",
		right_ring="Stikini Ring +1",
	}
    

    -- Idle sets
    sets.idle = {
		-- ammo="Homiliary",
		-- head="Nyame Helm",
		-- body="Nyame Mail",
		-- hands="Regal Gauntlets",
		-- legs="Nyame Flanchard",
		-- feet="Nyame Sollerets",				--First Regen Set
		-- neck="Elite Royal Collar",
		-- waist="Carrier's Sash",
		-- right_ear="Etiolation Earring",
		-- left_ear="Cryptic Earring",
		-- left_ring="Gurebu-Ogurebu's Ring",
		-- right_ring="Shneddick Ring",
		-- back="Moonlight Cape",
		ammo="Homiliary",
		head="Chev. Armet +3",
		body="Sacro Breastplate",
		hands="Regal Gauntlets",
		legs="Chev. Cuisses +3",
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Elite Royal Collar",
		waist="Carrier's Sash",
		left_ear="Cryptic Earring",
		right_ear="Etiolation Earring",
		left_ring="Gurebu's Ring",
		right_ring="Shneddick Ring",
		back="Moonlight Cape",
	}
	
	sets.idle.Phalanx = {
		ammo="Staunch Tathlum +1",
		head={ name="Valorous Mask", augments={'"Avatar perpetuation cost" -1','"Mag.Atk.Bns."+4','Phalanx +5',}},
		body={ name="Odyss. Chestplate", augments={'VIT+5','"Dual Wield"+1','Phalanx +5',}},
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		legs="Sakpata's Cuisses",
		feet={ name="Souveran Schuhs +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		neck="Null Loop",
		waist="Plat. Mog. Belt",
		right_ear="Chevalier's Earring +1",
		left_ear="Cryptic Earring",
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back={ name="Weard Mantle", augments={'VIT+2','Phalanx +5',}},
	}
	
	 sets.idle.MagicEvasion = {
		ammo="Staunch Tathlum +1",
		head={ name="Nyame Helm", augments={'Path: B',}},
		body="Sakpata's Breastplate",
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Warder's Charm +1",
		waist="Carrier's Sash",
		left_ear={ name="Odnowa Earring +1", augments={'Path: A',}},
		right_ear="Etiolation Earring",
		left_ring="Shadow Ring",
		right_ring="Gurebu's Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Occ. inc. resist. to stat. ailments+10',}},
	}
	
	sets.idle.Lilith = {
		ammo="Staunch Tathlum +1",
		head="Nyame Helm",
		body="Nyame Mail",
		hands="Nyame Gauntlets",
		legs="Nyame Flanchard",
		feet="Nyame Sollerets",
		neck="Warder's Charm +1",
		waist="Carrier's Sash",
		right_ear="Etiolation Earring",
		left_ear="Cryptic Earring",
		left_ring="Shadow Ring",
		right_ring="Shneddick Ring",
		back="Moonlight Cape",
		-- ammo="Staunch Tathlum +1",
		-- head="Chev. Armet +3",
		-- body={ name="Nyame Mail", augments={'Path: B',}},
		-- hands="Chev. Gauntlets +3",
		-- legs="Dashing Subligar",
		-- feet={ name="Nyame Sollerets", augments={'Path: B',}},
		-- neck="Warder's Charm +1",
		-- waist="Carrier's Sash",
		-- left_ear={ name="Odnowa Earring +1", augments={'Path: A',}},
		-- right_ear={ name="Chev. Earring +1", augments={'System: 1 ID: 1676 Val: 0','Accuracy+11','Mag. Acc.+11','Damage taken-3%',}},
		-- left_ring="Shadow Ring",
		-- right_ring="Shneddick Ring",
		-- back="Philidor Mantle",
	}
	
	sets.idle.Annul = {		
		ammo="Shadow Sachet",
		head="Chev. Armet +3",
		body="Chev. Cuirass +3",
		hands="Chev. Gauntlets +3",
		legs="Chev. Cuisses +3",
		feet="Chev. Sabatons +3",
		neck="Warder's Charm +1",
		waist="Carrier's Sash",
		left_ear={ name="Odnowa Earring +1", augments={'Path: A',}},
		right_ear="Chevalier's Earring +1",
		left_ring="Shadow Ring",
		right_ring="Archon Ring",
		back="Shadow Mantle",
	}
	
	sets.idle.AnnulCrit = {		
		ammo="Eluder's Sachet",
		head="Chev. Armet +3",
		body="Chev. Cuirass +3",
		hands="Chev. Gauntlets +3",
		legs="Chev. Cuisses +3",
		feet="Chev. Sabatons +3",
		neck="Warder's Charm +1",
		waist="Carrier's Sash",
		left_ear={ name="Odnowa Earring +1", augments={'Path: A',}},
		right_ear={ name="Chev. Earring +1", augments={'System: 1 ID: 1676 Val: 0','Accuracy+11','Mag. Acc.+11','Damage taken-3%',}},
		left_ring="Shadow Ring",
		right_ring="Fortified Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','"Cure" potency +10%','Phys. dmg. taken-10%',}},
	}
	
	sets.idle.DT = {		
		ammo="Eluder's Sachet",
		head="Chev. Armet +3",
		body={ name="Nyame Mail", augments={'Path: B',}},
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Warder's Charm +1",
		waist="Carrier's Sash",
		left_ear={ name="Odnowa Earring +1", augments={'Path: A',}},
		right_ear={ name="Chev. Earring +1", augments={'System: 1 ID: 1676 Val: 0','Accuracy+11','Mag. Acc.+11','Damage taken-3%',}},
		left_ring="Shadow Ring",
		right_ring="Fortified Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}},
	}
	
	
	sets.idle.Pulling = {
		-- ammo="Staunch Tathlum +1",
		-- head={ name="Nyame Helm", augments={'Path: B',}},
		-- body={ name="Sakpata's Plate", augments={'Path: A',}},
		-- hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		-- legs="Chev. Cuisses +3",
		-- feet={ name="Nyame Sollerets", augments={'Path: B',}},		
		-- neck="Warder's Charm +1",									
		-- waist="Carrier's Sash",											--Original "Pulling" set; the "Flee" set is the one being used now.
		-- left_ear="Hearty Earring",										--Resist! All +77 w/RUN and MalignanceSword; Capped Resist! Bind, Gravity, Stun, Petrify, Sleep, Charm
		-- right_ear={ name="Arete del Luna +1", augments={'Path: A',}},
		-- left_ring="Gurebu's Ring",
		-- right_ring="Shneddick Ring",
		-- back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Occ. inc. resist. to stat. ailments+10',}},
		ammo="Staunch Tathlum +1",
		head={ name="Nyame Helm", augments={'Path: B',}},
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands="Chev. Gauntlets +3",
		legs="Chev. Cuisses +3",
		feet="Hippo. Socks +1",
		neck="Warder's Charm +1",
		waist="Carrier's Sash",
		left_ear="Hearty Earring",
		right_ear={ name="Arete del Luna +1", augments={'Path: A',}},
		left_ring="Gurebu's Ring",
		right_ring="Shneddick Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Occ. inc. resist. to stat. ailments+10',}},		
	} --Resist! All +77 w/RUN and MalignanceSword; Capped Resist! Bind, Gravity, Stun, Petrify, Sleep, Charm
	
	-- sets.idle.Flee = {
		-- ammo="Staunch Tathlum +1",
		-- head={ name="Nyame Helm", augments={'Path: B',}},
		-- body={ name="Sakpata's Plate", augments={'Path: A',}},
		-- hands="Chev. Gauntlets +3",
		-- legs="Chev. Cuisses +3",
		-- feet="Hippo. Socks +1",
		-- neck="Warder's Charm +1",
		-- waist="Carrier's Sash",
		-- left_ear="Hearty Earring",
		-- right_ear={ name="Arete del Luna +1", augments={'Path: A',}},
		-- left_ring="Gurebu's Ring",
		-- right_ring="Shneddick Ring",
		-- back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Occ. inc. resist. to stat. ailments+10',}},
	-- } --Resist! All +77 w/RUN and MalignanceSword; Capped Resist! Bind, Gravity, Stun, Petrify, Sleep, Charm

	sets.idle.Duban = {		
		ammo="Staunch Tathlum +1",
		head="Chev. Armet +3",
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands="Chev. Gauntlets +3",
		legs="Chev. Cuisses +3",
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Warder's Charm +1",
		waist="Carrier's Sash",
		left_ear="Hearty Earring",
		right_ear={ name="Arete del Luna +1", augments={'Path: A',}},
		left_ring="Gurebu's Ring",
		right_ring="Shneddick Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Occ. inc. resist. to stat. ailments+10',}},
	}


    --sets.idle.Town = sets.idle
    
    --sets.idle.Weak = {}
    
    --sets.idle.Weak.Reraise = set_combine(sets.idle.Weak, sets.Reraise)
    
    --sets.Kiting = {legs="Carmine Cuisses +1"}

    sets.latent_refresh = {waist="Fucho-no-obi"}


    --------------------------------------
    -- Defense sets
    --------------------------------------
    
    -- Extra defense sets.  Apply these on top of melee or defense sets.
    sets.Knockback = {
		legs="Dashing Subligar",
		back="Philidor Mantle",
		ring1="Defending Ring",
	}
	
    sets.MP = {
		--waist="Flume Belt +1",
		head="Chevalier's Armet +3",
		feet="Reverence Leggings +3",
		
	}
	
    sets.MP_Knockback = {
		legs="Dashing Subligar",
		feet="Reverence Leggings +3",
		back="Philidor Mantle",		
	}
    
    -- If EquipShield toggle is on (Win+F10 or Win+F11), equip the weapon/shield combos here
    -- when activating or changing defense mode:
    sets.PhysicalShield = {
		--main="",
		--sub="Srivatsa" Annuls Damage +5%; Different term than Shadow Ring.
		--sub="Ochain" 25% damage taken to MP upon successful block. (non iLevel)
	}	--I keep these empty because I prefer to manually change my main/sub.
	
    sets.MagicalShield = {
		--main="",
		--sub="Aegis"	-- -50 MDTII; (non iLevel)
		--sub="Adamas"	--20 Resist! All; (non iLevel)
		--sub="Duban"	--10 Resist! All; -15 MDTII
		--sub="Priwen" 	--50 Meva
	}	--I keep these empty because I prefer to manually change my main/sub.

    -- Basic defense sets.
        
    sets.defense.PDT = {
		ammo="Eluder's Sachet",
		head="Chevalier's Armet +3",
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands="Sakpata's Gauntlets",
		legs="Sakpata's Cuisses",
		feet="Rev. Leggings +3",
		neck="Combatant's Torque",
		waist="Sailfi Belt +1",
		right_ear="Chevalier's Earring +1",
		left_ear="Foresti Earring",
		left_ring="Fortified Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}},
	}
		
    sets.defense.HP = {
		ammo="Homiliary",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body={ name="Souv. Cuirass +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		legs={ name="Souv. Diechlings +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		feet={ name="Souveran Schuhs +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		neck="Unmoving Collar +1",
		waist="Plat. Mog. Belt",
		right_ear="Etiolation Earring",
		left_ear="Cryptic Earring",
		left_ring="Moonlight Ring",
		right_ring="Moonlight Ring",
		back="Moonlight Cape",
	}
		
    sets.defense.Reraise = {
		ammo="Staunch Tathlum +1",
		head="Twilight Helm",
		body="Twilight Mail",
		hands={ name="Sakpata's Gauntlets", augments={'Path: A',}},
		legs={ name="Sakpata's Cuisses", augments={'Path: A',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Warder's Charm +1",
		waist="Carrier's Sash",
		left_ear="Cryptic Earring",
		right_ear="Etiolation Earring",
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back="Moonlight Cape",
	}
	
	sets.defense.Doom = {
		ammo="Staunch Tathlum +1",
		head="Chevalier's Armet +3",
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Sakpata's Cuisses", augments={'Path: A',}},
		feet={ name="Nyame Sollerets", augments={'Path: B',}},
		neck="Nicander's Necklace",
		waist="Gishdubar Sash",
		left_ear="Cryptic Earring",
		right_ear="Etiolation Earring",
		left_ring="Purity Ring",
		right_ring="Blenmot's Ring +1",
		back="Moonlight Cape",
	}
		
    sets.defense.ResistCharm = {
		ammo="Staunch Tathlum +1", --11
		head="Volte Cap", --10
		--body="Volte Jupon", --20
		body="Sakpata's Breastplate", --13
		hands="Macabre Gauntlets +1", --10
		legs={ name="Souv. Diechlings +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}}, --20
		feet="Volte Boots", --10
		neck="Unmoving Collar +1", --9
		waist="Audumbla Sash", --0
		left_ear="Hearty Earring", --5
		right_ear={ name="Arete del Luna +1", augments={'Path: A',}}, --15
		left_ring="Defending Ring",
		right_ring="Gurebu-Ogurebu's Ring", --20		
		back="Solemnity Cape", --15
	} 	--138 Resist Charm (69% Resist on NMs)  With Sakpata Breastplate but no MalignanceSword &  Wuji Ring.
		--145 Resist Charm (72.5% Resist on NMs)  With Volte Jupon but no MalignanceSword & Wuji Ring.	
		-- +29 /RUN and Pflug (+14.5% on NMs)
		-- +10 MalignanceSword OR Duban (+5% on NMs)
	
	sets.defense.Resist = {
		ammo="Staunch Tathlum +1",
		head="Volte Cap",
		body="Volte Jupon",
		hands="Macabre Gauntlets +1",
		legs="Volte Hose",
		feet="Volte Boots",
		neck="Null Loop",
		waist="Audumbla Sash",
		left_ear="Hearty Earring",
		right_ear="Chevalier's Earring +1",
		left_ring="Defending Ring",
		--right_ring="Moonlight Ring",
		right_ring="Gurebu-Ogurebu's Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Occ. inc. resist. to stat. ailments+10',}},
	} --136 Resist All with MalignanceSword/Adamas (65.5% on NMs)
	
	sets.defense.ResistStun = {
		ammo="Staunch Tathlum +1",
		head="Chev. Armet +3",
		body="Onca Suit",
		hands=empty,
		legs=empty,
		feet=empty,	
		neck="Warder's Charm +1",
		waist="Plat. Mog. Belt",
		left_ear={ name="Arete del Luna +1", augments={'Path: A',}},
		right_ear={ name="Chev. Earring +1", augments={'System: 1 ID: 1676 Val: 0','Accuracy+11','Mag. Acc.+11','Damage taken-3%',}},
		left_ring="Defending Ring",
		right_ring="Gurebu's Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Occ. inc. resist. to stat. ailments+10',}},
	} --170 Resist Stun with MalignanceSword/Tenacity (85% Resist on NMs)
	
	sets.defense.ResistTerror = {
		--main="Sagasinger", +50 Resist Terror
		-- ammo="Homiliary",
		-- head="Sakpata's Helm",
		-- body={ name="Sakpata's Plate", augments={'Path: A',}},
		-- hands="Sakpata's Gauntlets",
		-- legs="Sakpata's Cuisses",
		feet={ name="Founder's Greaves", augments={'VIT+10','Accuracy+15','"Mag.Atk.Bns."+15','Mag. Evasion+15',}}, -- +30 Resist Terror
		-- neck="Moonbeam Necklace",
		-- waist="Carrier's Sash",
		-- right_ear="Etiolation Earring",
		-- left_ear="Cryptic Earring",
		-- left_ring="Defending Ring",
		-- right_ring="Gurebu's Ring",
		-- back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}},
	} --80 Resist Terror with Sagasinger/FoundersGreaves (80% Resist on NMs)
	
	sets.defense.TH = {
		ammo="Per. Lucky Egg",
		head={ name="Nyame Helm", augments={'Path: B',}},
		body="Volte Jupon",
		hands={ name="Nyame Gauntlets", augments={'Path: B',}},
		legs={ name="Nyame Flanchard", augments={'Path: B',}},
		feet="Volte Boots",
		neck="Null Loop",
		waist="Carrier's Sash",
		left_ear="Cryptic Earring",
		right_ear="Etiolation Earring",
		left_ring="Defending Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}},
	}
		
    -- To cap MDT with Shell IV (52/256), need 76/256 in gear.
    -- Shellra V can provide 75/256, which would need another 53/256 in gear.
	
    sets.defense.MDT = {
		-- head={ name="Sakpata's Helm", augments={'Path: A',}},   						--Version 1
		-- body={ name="Sakpata's Plate", augments={'Path: A',}},
		-- hands={ name="Sakpata's Gauntlets", augments={'Path: A',}},
		-- legs={ name="Sakpata's Cuisses", augments={'Path: A',}},
		-- feet={ name="Sakpata's Leggings", augments={'Path: A',}},
		-- neck="Warder's Charm +1",
		-- waist={ name="Sailfi Belt +1", augments={'Path: A',}},
		-- left_ear="Cryptic Earring",
		-- right_ear={ name="Chev. Earring +1", augments={'System: 1 ID: 1676 Val: 0','Accuracy+11','Mag. Acc.+11','Damage taken-3%',}},
		-- left_ring="Shadow Ring",
		-- right_ring="Wuji Ring",
		-- back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Occ. inc. resist. to stat. ailments+10',}}, --Version 1
		-- ammo="Shadow Sachet", 														--Version 2
		-- head={ name="Sakpata's Helm", augments={'Path: A',}},
		-- body={ name="Sakpata's Plate", augments={'Path: A',}},
		-- hands={ name="Sakpata's Gauntlets", augments={'Path: A',}},
		-- legs={ name="Sakpata's Cuisses", augments={'Path: A',}},
		-- feet={ name="Sakpata's Leggings", augments={'Path: A',}},
		-- neck="Warder's Charm +1",
		-- waist={ name="Sailfi Belt +1", augments={'Path: A',}},
		-- left_ear={ name="Arete del Luna +1", augments={'Path: A',}},
		-- right_ear={ name="Chev. Earring +1", augments={'System: 1 ID: 1676 Val: 0','Accuracy+11','Mag. Acc.+11','Damage taken-3%',}},
		-- left_ring="Shadow Ring",
		-- right_ring="Gurebu's Ring",
		-- back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Occ. inc. resist. to stat. ailments+10',}}, --Version 2
		ammo="Flame Sachet",
		head={ name="Sakpata's Helm", augments={'Path: A',}},
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands={ name="Sakpata's Gauntlets", augments={'Path: A',}},
		legs="Chev. Cuisses +3",
		feet={ name="Sakpata's Leggings", augments={'Path: A',}},
		neck="Warder's Charm +1",
		waist={ name="Sailfi Belt +1", augments={'Path: A',}},
		left_ear={ name="Odnowa Earring +1", augments={'Path: A',}},
		right_ear={ name="Chev. Earring +1", augments={'System: 1 ID: 1676 Val: 0','Accuracy+11','Mag. Acc.+11','Damage taken-3%',}},
		left_ring="Shadow Ring",
		right_ring="Gurebu's Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}}, --v25 Kalunga
	}
	
	
	-- sets.defense.MagicEvasion = {
		-- ammo="Staunch Tathlum +1",
		-- head={ name="Sakpata's Helm", augments={'Path: A',}},
		-- body={ name="Sakpata's Plate", augments={'Path: A',}},
		-- hands={ name="Sakpata's Gauntlets", augments={'Path: A',}},
		-- legs={ name="Sakpata's Cuisses", augments={'Path: A',}},
		-- feet={ name="Sakpata's Leggings", augments={'Path: A',}},
		-- neck="Warder's Charm +1",
		-- waist={ name="Sailfi Belt +1", augments={'Path: A',}},
		-- left_ear="Cryptic Earring",
		-- right_ear="Etiolation Earring",
		-- right_ring="Gurebu's Ring",
		-- left_ring="Wuji Ring",
		-- back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Occ. inc. resist. to stat. ailments+10',}},
	-- }
	
	 sets.defense.Test = {
		 ammo="Homiliary",
		head="Twilight Helm",
		body="Hjarrandi Breast.",
		hands="Regal Gauntlets",
		legs="Sulev. Cuisses +2",
		feet="Sulev. Leggings +2",
		neck="Elite Royal Collar",
		waist="Audumbla Sash",
		left_ear="Infused Earring",
		right_ear={ name="Chev. Earring +1", augments={'System: 1 ID: 1676 Val: 0','Accuracy+11','Mag. Acc.+11','Damage taken-3%',}},
		left_ring="Icecrack Ring",
		right_ring="Defending Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','HP+20','"Fast Cast"+10','Phys. dmg. taken-10%',}},
		-- ammo="Aqua Sachet",
		-- head={ name="Sakpata's Helm", augments={'Path: A',}},
		-- body={ name="Sakpata's Plate", augments={'Path: A',}},
		-- hands={ name="Sakpata's Gauntlets", augments={'Path: A',}},
		-- legs={ name="Sakpata's Cuisses", augments={'Path: A',}},
		-- feet={ name="Sakpata's Leggings", augments={'Path: A',}},
		-- neck="Warder's Charm +1",
		-- waist={ name="Sailfi Belt +1", augments={'Path: A',}},
		-- left_ear="Infused Earring",
		-- right_ear={ name="Chev. Earring +1", augments={'System: 1 ID: 1676 Val: 0','Accuracy+11','Mag. Acc.+11','Damage taken-3%',}},
		-- left_ring="Gurebu's Ring",
		-- right_ring="Shneddick Ring",
		-- back={ name="Rudianos's Mantle", augments={'HP+60','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Damage taken-5%',}},
	}
	
	sets.defense.ResistSlow = {
		ammo="Staunch Tathlum +1",
		head="Arke Zuchetto",
		body="Dagon Breast.",
		hands={ name="Macabre Gaunt. +1", augments={'Path: A',}},
		legs="Volte Hose",
		feet="Volte Boots",
		neck="Null Loop",
		waist={ name="Sailfi Belt +1", augments={'Path: A',}},
		left_ear="Hearty Earring",
		right_ear={ name="Chev. Earring +1", augments={'System: 1 ID: 1676 Val: 0','Accuracy+11','Mag. Acc.+11','Damage taken-3%',}},
		left_ring="Defending Ring",
		right_ring="Gurebu's Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Occ. inc. resist. to stat. ailments+10',}},
	}
	
	sets.defense.Annul = {		
		ammo="Shadow Sachet",
		head="Chev. Armet +3",
		body="Chev. Cuirass +3",
		hands="Chev. Gauntlets +3",
		legs="Chev. Cuisses +3",
		feet="Chev. Sabatons +3",
		neck="Warder's Charm +1",
		waist="Carrier's Sash",
		left_ear={ name="Odnowa Earring +1", augments={'Path: A',}},
		right_ear="Chevalier's Earring +1",
		left_ring="Shadow Ring",
		right_ring="Archon Ring",
		back="Shadow Mantle",
	}
	

    -------------------------------------------------------------------------------------------------------------------------------------------------
    -- Engaged sets																												ENGAGED SETS
    -------------------------------------------------------------------------------------------------------------------------------------------------
    
    sets.engaged = {
		ammo="Coiste Bodhar",
		head="Hjarrandi Helm",
		body="Hjarrandi Breast.",
		hands="Sakpata's Gauntlets",
		legs="Volte Tights",
		feet="Flam. Gambieras +2",
		neck="Combatant's Torque",
		waist="Sailfi Belt +1",
		left_ear="Telos Earring",
		right_ear="Brutal Earring",
		left_ring="Moonlight Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Damage taken-5%',}},
}

    sets.engaged.Acc = {
		ammo="Staunch Tathlum +1",
		head="Flam. Zucchetto +2",
		body="Chevalier's Cuirass +3",
		hands="Sakpata's Gauntlets",
		legs="Chevalier's Cuisses +3",
		feet="Flamma Gambieras +2",
		neck="Combatant's Torque",
		waist="Sailfi Belt +1",
		left_ear="Telos Earring",
		right_ear="Brutal Earring",
		left_ring="Moonlight Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Damage taken-5%',}},
	}

    sets.engaged.Shield = {
		ammo="Eluder's Sachet",
		head="Chevalier's Armet +3",
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands="Sakpata's Gauntlets",
		legs="Sakpata's Cuisses",
		feet="Rev. Leggings +3",
		neck="Combatant's Torque",
		waist="Sailfi Belt +1",
		right_ear="Chevalier's Earring +1",
		left_ear="Foresti Earring",
		left_ring="Fortified Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}},
	}
	
	sets.engaged.Ochain = {
		ammo="Eluder's Sachet",
		head="Chev. Armet +3",
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands="Chev. Gauntlets +3",
		legs="Chev. Cuisses +3",
		feet="Rev. Leggings +3",
		neck="Combatant's Torque",
		waist={ name="Sailfi Belt +1", augments={'Path: A',}},
		left_ear="Foresti Earring",
		right_ear={ name="Chev. Earring +1", augments={'System: 1 ID: 1676 Val: 0','Accuracy+11','Mag. Acc.+11','Damage taken-3%',}},
		left_ring="Fortified Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}},
	}

    sets.engaged.Tank = {
		ammo="Staunch Tathlum +1",
		head={ name="Souv. Schaller +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		body={ name="Souv. Cuirass +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		hands={ name="Souv. Handsch. +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		legs={ name="Souv. Diechlings +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		feet={ name="Souveran Schuhs +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}},
		neck="Moonbeam Necklace",
		waist={ name="Sailfi Belt +1", augments={'Path: A',}},
		left_ear="Cryptic Earring",
		right_ear="Etiolation Earring",
		left_ring="Moonlight Ring",
		right_ring="Moonlight Ring",
		back="Shadow Mantle",
	}
	
	sets.engaged.HybridTank = {
		ammo="Coiste Bodhar",
		head="Sakpata's Helm",
		body="Sakpata's Plate",
		hands="Sakpata's Gauntlets",
		legs="Sakpata's Cuisses",
		feet="Sakpata's Leggings",
		neck="Combatant's Torque",
		waist="Sailfi Belt +1",
		left_ear="Telos Earring",
		right_ear="Brutal Earring",
		left_ring="Moonlight Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Damage taken-5%',}},	
	}	
	
	sets.engaged.GreatSword = {
		ammo={ name="Coiste Bodhar", augments={'Path: A',}},
		head={ name="Sakpata's Helm", augments={'Path: A',}},
		body="Hjarrandi Breast.",
		hands={ name="Sakpata's Gauntlets", augments={'Path: A',}},
		legs={ name="Sakpata's Cuisses", augments={'Path: A',}},
		feet={ name="Sakpata's Leggings", augments={'Path: A',}},
		neck="Vim Torque +1",
		waist={ name="Sailfi Belt +1", augments={'Path: A',}},
		left_ear="Telos Earring",
		right_ear="Brutal Earring",
		left_ring="Moonlight Ring",
		right_ring="Moonlight Ring",
		back={ name="Rudianos's Mantle", augments={'DEX+20','Accuracy+20 Attack+20','DEX+10','Crit.hit rate+10','Parrying rate+5%',}},
	}	
	
	sets.engaged.MagicEvasion = {
		-- ammo="Staunch Tathlum +1", --Kalunga v25
		-- left_ear="Odnowa Earring +1", --Kalunga v25
		-- right_ear="Chevalier's Earring +1", --Kalunga v25
		-- right_ring="Gurebu's Ring", --Kalunga v25
		-- back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Chance of successful block +5',}}, --Kalunga v25
		ammo="Homiliary",
		left_ear="Telos Earring", 
		right_ear="Brutal Earring", 
		right_ring="Wuji Ring",	
		back={ name="Rudianos's Mantle", augments={'HP+60','Accuracy+20 Attack+20','Accuracy+10','"Dbl.Atk."+10','Damage taken-5%',}},	
		head="Sakpata's Helm",
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands="Sakpata's Gauntlets",
		legs="Sakpata's Cuisses",
		feet="Sakpata's Leggings",
		neck="Warder's Charm +1",
		waist="Sailfi belt +1",		
		left_ring="Shadow Ring",		
	}
	
	sets.engaged.Resist = {
		ammo="Staunch Tathlum +1",
		head="Chevalier's Armet +3",
		body={ name="Sakpata's Plate", augments={'Path: A',}},
		hands={ name="Macabre Gaunt. +1", augments={'Path: A',}},
		legs="Volte Hose",
		feet="Volte Boots",
		neck="Null Loop",
		waist={ name="Sailfi Belt +1", augments={'Path: A',}},
		left_ear="Telos Earring",
		right_ear="Brutal Earring",
		left_ring="Defending Ring",
		right_ring="Gurebu's Ring",
		back={ name="Rudianos's Mantle", augments={'HP+60','Eva.+20 /Mag. Eva.+20','HP+20','Enmity+10','Occ. inc. resist. to stat. ailments+10',}},
	} --This set is 83 w/o weapons. You need /RUN OR MalignanceSword to cap. 
	
	sets.engaged.ResistCharm = {
		ammo="Staunch Tathlum +1", --11
		head="Arke Zuchetto", --5
		body="Volte Jupon", --20
		hands="Macabre Gauntlets +1", --10
		legs={ name="Souv. Diechlings +1", augments={'HP+105','Enmity+9','Potency of "Cure" effect received +15%',}}, --20
		feet="Volte Boots", --10
		neck="Unmoving Collar +1", --9
		waist="Audumbla Sash",
		left_ear="Hearty Earring", --5
		right_ear={ name="Arete del Luna +1", augments={'Path: A',}}, --15
		left_ring="Defending Ring",
		right_ring="Gurebu-Ogurebu's Ring", --20
		--right_ring="Wuji Ring", --15? Edit: go back and do more testing on ice elementals in sky.
		back="Solemnity Cape", --15
	} 	--140 Resist Charm (70% Resist on NMs) (169 (84% on NMs) w/RUN (+9) and Pflug (+20))
		--Equip MalignanceSword to get 179(cap)


    -- sets.engaged.PDT = set_combine(sets.engaged, {body="Caballarius Surcoat",neck="Twilight Torque",ring1="Defending Ring"})
    -- sets.engaged.Acc.PDT = set_combine(sets.engaged.Acc, {body="Caballarius Surcoat",neck="Twilight Torque",ring1="Defending Ring"})
    -- sets.engaged.Reraise = set_combine(sets.engaged, sets.Reraise)
    -- sets.engaged.Acc.Reraise = set_combine(sets.engaged.Acc, sets.Reraise)

    -- sets.engaged.DW.PDT = set_combine(sets.engaged.DW, {body="Reverence Surcoat +3",neck="Twilight Torque",ring1="Defending Ring"})
    -- sets.engaged.DW.Acc.PDT = set_combine(sets.engaged.DW.Acc, {body="Reverence Surcoat +3",neck="Twilight Torque",ring1="Defending Ring"})
    -- sets.engaged.DW.Reraise = set_combine(sets.engaged.DW, sets.Reraise)
    -- sets.engaged.DW.Acc.Reraise = set_combine(sets.engaged.DW.Acc, sets.Reraise)


    --------------------------------------
    -- Custom buff sets
    --------------------------------------

    sets.buff.Doom = {
		neck="Nicander's Necklace",
		ring2="Purity Ring",
		waist="Gishdubar Sash",
	}
	
    sets.buff.Cover = {head="Reverence Coronet +2", body="Caballarius Surcoat +3"}
end


-------------------------------------------------------------------------------------------------------------------
-- Job-specific hooks for standard casting events.
-------------------------------------------------------------------------------------------------------------------

function job_midcast(spell, action, spellMap, eventArgs)
    -- If DefenseMode is active, apply that gear over midcast
    -- choices.  Precast is allowed through for fast cast on
    -- spells, but we want to return to def gear before there's
    -- time for anything to hit us.
    -- Exclude Job Abilities from this restriction, as we probably want
    -- the enhanced effect of whatever item of gear applies to them,
    -- and only one item should be swapped out.
    if state.DefenseMode.value ~= 'None' and spell.type ~= 'JobAbility' then
        handle_equipping_gear(player.status)
        eventArgs.handled = true
    end
end

-------------------------------------------------------------------------------------------------------------------
-- Job-specific hooks for non-casting events.
-------------------------------------------------------------------------------------------------------------------

-- Called when the player's status changes.
function job_state_change(field, new_value, old_value)
    classes.CustomDefenseGroups:clear()
    classes.CustomDefenseGroups:append(state.ExtraDefenseMode.current)
    if state.EquipShield.value == true then
        classes.CustomDefenseGroups:append(state.DefenseMode.current .. 'Shield')
    end

    classes.CustomMeleeGroups:clear()
    classes.CustomMeleeGroups:append(state.ExtraDefenseMode.current)
end

function job_buff_change(buff,gain)
    if buff == "doom" then
        if gain then
            send_command('@input /p Doomed.')
    end
    end
end

-------------------------------------------------------------------------------------------------------------------
-- User code that supplements standard library decisions.
-------------------------------------------------------------------------------------------------------------------

-- Called by the 'update' self-command, for common needs.
-- Set eventArgs.handled to true if we don't want automatic equipping of gear.
function job_update(cmdParams, eventArgs)
    update_defense_mode()
end

-- Modify the default idle set after it was constructed.
function customize_idle_set(idleSet)
    if player.mpp < 51 then
        idleSet = set_combine(idleSet, sets.latent_refresh)
    end
    if state.Buff.Doom then
        idleSet = set_combine(idleSet, sets.buff.Doom)
    end
    
    return idleSet
end

-- Modify the default melee set after it was constructed.

function customize_defense_set(defenseSet)
    if state.ExtraDefenseMode.value ~= 'None' then
        defenseSet = set_combine(defenseSet, sets[state.ExtraDefenseMode.value])
    end
    
    if state.EquipShield.value == true then
        defenseSet = set_combine(defenseSet, sets[state.DefenseMode.current .. 'Shield'])
    end
    
    if state.Buff.Doom then
        defenseSet = set_combine(defenseSet, sets.buff.Doom)
    end
    
    return defenseSet
end


function display_current_job_state(eventArgs)
    local msg = 'Melee'
    
    if state.CombatForm.has_value then
        msg = msg .. ' (' .. state.CombatForm.value .. ')'
    end
    
    msg = msg .. ': '
    
    msg = msg .. state.OffenseMode.value
    if state.HybridMode.value ~= 'Normal' then
        msg = msg .. '/' .. state.HybridMode.value
    end
    msg = msg .. ', WS: ' .. state.WeaponskillMode.value
    
    if state.DefenseMode.value ~= 'None' then
        msg = msg .. ', Defense: ' .. state.DefenseMode.value .. ' (' .. state[state.DefenseMode.value .. 'DefenseMode'].value .. ')'
    end

    if state.ExtraDefenseMode.value ~= 'None' then
        msg = msg .. ', Extra: ' .. state.ExtraDefenseMode.value
    end
    
    if state.EquipShield.value == true then
        msg = msg .. ', Force Equip Shield'
    end
    
    if state.Kiting.value == true then
        msg = msg .. ', Kiting'
    end

    if state.PCTargetMode.value ~= 'default' then
        msg = msg .. ', Target PC: '..state.PCTargetMode.value
    end

    if state.SelectNPCTargets.value == true then
        msg = msg .. ', Target NPCs'
    end

    add_to_chat(122, msg)

    eventArgs.handled = true
end

-------------------------------------------------------------------------------------------------------------------
-- Utility functions specific to this job.
-------------------------------------------------------------------------------------------------------------------

function update_defense_mode()
    if player.equipment.main == 'Kheshig Blade' and not classes.CustomDefenseGroups:contains('Kheshig Blade') then
        classes.CustomDefenseGroups:append('Kheshig Blade')
    end
    
    if player.sub_job == 'NIN' or player.sub_job == 'DNC' then
        if player.equipment.sub and not player.equipment.sub:contains('Shield') and
           player.equipment.sub ~= 'Aegis' and player.equipment.sub ~= 'Ochain' then
            state.CombatForm:set('DW')
        else
            state.CombatForm:reset()
        end
    end
end


-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
    -- Default macro set/book
    if player.sub_job == 'DNC' then
        set_macro_page(3, 3)
    elseif player.sub_job == 'NIN' then
        set_macro_page(3, 3)
    elseif player.sub_job == 'RDM' then
        set_macro_page(3 , 3)
    else
        set_macro_page(3, 3)
    end
end